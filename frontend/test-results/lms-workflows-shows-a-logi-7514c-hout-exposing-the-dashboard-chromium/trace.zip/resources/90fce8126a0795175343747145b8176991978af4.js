import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/EditMeetingForm.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/EditMeetingForm.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
// Convert API datetime into the browser's local time.
function toLocalDateTime(value) {
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) {
		return "";
	}
	const pad = (number) => String(number).padStart(2, "0");
	return `${date.getFullYear()}-` + `${pad(date.getMonth() + 1)}-` + `${pad(date.getDate())}T` + `${pad(date.getHours())}:` + `${pad(date.getMinutes())}`;
}
export default function EditMeetingForm({ meeting, token, onUpdated, onCancel }) {
	_s();
	const [title, setTitle] = useState(meeting.title);
	const [description, setDescription] = useState(meeting.description || "");
	const [startsAt, setStartsAt] = useState(toLocalDateTime(meeting.starts_at));
	const [endsAt, setEndsAt] = useState(toLocalDateTime(meeting.ends_at));
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState("");
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		const start = new Date(startsAt);
		const end = new Date(endsAt);
		if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start) {
			setError("End time must be later than start time.");
			return;
		}
		if (!title.trim()) {
			setError("Meeting title is required.");
			return;
		}
		setLoading(true);
		try {
			const response = await fetch(`/api/meetings/${meeting.id}`, {
				method: "PUT",
				headers: {
					Authorization: `Bearer ${token}`,
					"Content-Type": "application/json"
				},
				body: JSON.stringify({
					title: title.trim(),
					description: description.trim() || null,
					starts_at: start.toISOString(),
					ends_at: end.toISOString()
				})
			});
			if (!response.ok) {
				const data = await response.json().catch(() => null);
				throw new Error(typeof data?.detail === "string" ? data.detail : `Failed to update meeting (${response.status}).`);
			}
			await onUpdated();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to update meeting.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "edit-meeting-form",
		children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Edit Online Class" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 131,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			children: [
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: `title-${meeting.id}`,
					children: "Meeting Title"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					id: `title-${meeting.id}`,
					value: title,
					onChange: (e) => setTitle(e.target.value),
					maxLength: 200,
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 137,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: `description-${meeting.id}`,
					children: "Description"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 145,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("textarea", {
					id: `description-${meeting.id}`,
					value: description,
					onChange: (e) => setDescription(e.target.value),
					rows: 3
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 148,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: `start-${meeting.id}`,
					children: "Start Date and Time"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 157,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					id: `start-${meeting.id}`,
					type: "datetime-local",
					value: startsAt,
					onChange: (e) => setStartsAt(e.target.value),
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 160,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: `end-${meeting.id}`,
					children: "End Date and Time"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 168,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					id: `end-${meeting.id}`,
					type: "datetime-local",
					value: endsAt,
					onChange: (e) => setEndsAt(e.target.value),
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 171,
					columnNumber: 9
				}, this),
				error && /* @__PURE__ */ _jsxDEV("p", {
					className: "error",
					role: "alert",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 180,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "meeting-actions",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						disabled: loading,
						children: loading ? "Saving..." : "Save Changes"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 186,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "btn-secondary",
						onClick: onCancel,
						disabled: loading,
						children: "Close Editor"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 190,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 185,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 133,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 130,
		columnNumber: 5
	}, this);
}
_s(EditMeetingForm, "rJfLCFVuvXKZRCs4Ybvxr+ewGdA=");
_c = EditMeetingForm;
var _c;
$RefreshReg$(_c, "EditMeetingForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/EditMeetingForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/EditMeetingForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/EditMeetingForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/EditMeetingForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxnQkFBZ0M7Ozs7O0FBa0J6QyxTQUFTLGdCQUFnQixPQUF1QjtDQUM5QyxNQUFNLE9BQU8sSUFBSSxLQUFLLEtBQUs7Q0FFM0IsSUFBSSxPQUFPLE1BQU0sS0FBSyxRQUFRLENBQUMsR0FBRztFQUNoQyxPQUFPO0NBQ1Q7Q0FFQSxNQUFNLE9BQU8sV0FDWCxPQUFPLE1BQU0sQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0NBRWhDLE9BQ0UsR0FBRyxLQUFLLFlBQVksRUFBRSxLQUN0QixHQUFHLElBQUksS0FBSyxTQUFTLElBQUksQ0FBQyxFQUFFLEtBQzVCLEdBQUcsSUFBSSxLQUFLLFFBQVEsQ0FBQyxFQUFFLEtBQ3ZCLEdBQUcsSUFBSSxLQUFLLFNBQVMsQ0FBQyxFQUFFLEtBQ3hCLEdBQUcsSUFBSSxLQUFLLFdBQVcsQ0FBQztBQUU1QjtBQUVBLGVBQWUsU0FBUyxnQkFBZ0IsRUFDdEMsU0FDQSxPQUNBLFdBQ0EsWUFDUTs7Q0FDUixNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsUUFBUSxLQUFLO0NBRWhELE1BQU0sQ0FBQyxhQUFhLGtCQUFrQixTQUNwQyxRQUFRLGVBQWUsRUFDekI7Q0FFQSxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQzlCLGdCQUFnQixRQUFRLFNBQVMsQ0FDbkM7Q0FFQSxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQzFCLGdCQUFnQixRQUFRLE9BQU8sQ0FDakM7Q0FFQSxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUVyQyxlQUFlLGFBQ2IsT0FDQTtFQUNBLE1BQU0sZUFBZTtFQUNyQixTQUFTLEVBQUU7RUFFWCxNQUFNLFFBQVEsSUFBSSxLQUFLLFFBQVE7RUFDL0IsTUFBTSxNQUFNLElBQUksS0FBSyxNQUFNO0VBRTNCLElBQ0UsQ0FBQyxPQUFPLFNBQVMsTUFBTSxRQUFRLENBQUMsS0FDaEMsQ0FBQyxPQUFPLFNBQVMsSUFBSSxRQUFRLENBQUMsS0FDOUIsT0FBTyxPQUNQO0dBQ0EsU0FBUyx5Q0FBeUM7R0FDbEQ7RUFDRjtFQUVBLElBQUksQ0FBQyxNQUFNLEtBQUssR0FBRztHQUNqQixTQUFTLDRCQUE0QjtHQUNyQztFQUNGO0VBRUEsV0FBVyxJQUFJO0VBRWYsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQ3JCLGlCQUFpQixRQUFRLE1BQ3pCO0lBQ0UsUUFBUTtJQUNSLFNBQVM7S0FDUCxlQUFlLFVBQVU7S0FDekIsZ0JBQWdCO0lBQ2xCO0lBQ0EsTUFBTSxLQUFLLFVBQVU7S0FDbkIsT0FBTyxNQUFNLEtBQUs7S0FDbEIsYUFBYSxZQUFZLEtBQUssS0FBSztLQUNuQyxXQUFXLE1BQU0sWUFBWTtLQUM3QixTQUFTLElBQUksWUFBWTtJQUMzQixDQUFDO0dBQ0gsQ0FDRjtHQUVBLElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsTUFBTSxPQUFPLE1BQU0sU0FDaEIsS0FBSyxDQUFDLENBQ04sWUFBWSxJQUFJO0lBRW5CLE1BQU0sSUFBSSxNQUNSLE9BQU8sTUFBTSxXQUFXLFdBQ3BCLEtBQUssU0FDTCw2QkFBNkIsU0FBUyxPQUFPLEdBQ25EO0dBQ0Y7R0FFQSxNQUFNLFVBQVU7RUFDbEIsU0FBUyxLQUFLO0dBQ1osU0FDRSxlQUFlLFFBQ1gsSUFBSSxVQUNKLDJCQUNOO0VBQ0YsVUFBVTtHQUNSLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLG9CQUFxQjs7OztZQUV6Qix3QkFBQyxRQUFEO0dBQU0sVUFBVTthQUFoQjtJQUNFLHdCQUFDLFNBQUQ7S0FBTyxTQUFTLFNBQVMsUUFBUTtlQUFNO0lBRWhDOzs7OztJQUNQLHdCQUFDLFNBQUQ7S0FDRSxJQUFJLFNBQVMsUUFBUTtLQUNyQixPQUFPO0tBQ1AsV0FBVyxNQUFNLFNBQVMsRUFBRSxPQUFPLEtBQUs7S0FDeEMsV0FBVztLQUNYO0lBQ0Q7Ozs7O0lBRUQsd0JBQUMsU0FBRDtLQUFPLFNBQVMsZUFBZSxRQUFRO2VBQU07SUFFdEM7Ozs7O0lBQ1Asd0JBQUMsWUFBRDtLQUNFLElBQUksZUFBZSxRQUFRO0tBQzNCLE9BQU87S0FDUCxXQUFXLE1BQ1QsZUFBZSxFQUFFLE9BQU8sS0FBSztLQUUvQixNQUFNO0lBQ1A7Ozs7O0lBRUQsd0JBQUMsU0FBRDtLQUFPLFNBQVMsU0FBUyxRQUFRO2VBQU07SUFFaEM7Ozs7O0lBQ1Asd0JBQUMsU0FBRDtLQUNFLElBQUksU0FBUyxRQUFRO0tBQ3JCLE1BQUs7S0FDTCxPQUFPO0tBQ1AsV0FBVyxNQUFNLFlBQVksRUFBRSxPQUFPLEtBQUs7S0FDM0M7SUFDRDs7Ozs7SUFFRCx3QkFBQyxTQUFEO0tBQU8sU0FBUyxPQUFPLFFBQVE7ZUFBTTtJQUU5Qjs7Ozs7SUFDUCx3QkFBQyxTQUFEO0tBQ0UsSUFBSSxPQUFPLFFBQVE7S0FDbkIsTUFBSztLQUNMLE9BQU87S0FDUCxXQUFXLE1BQU0sVUFBVSxFQUFFLE9BQU8sS0FBSztLQUN6QztJQUNEOzs7OztJQUVBLFNBQ0Msd0JBQUMsS0FBRDtLQUFHLFdBQVU7S0FBUSxNQUFLO2VBQ3ZCO0lBQ0E7Ozs7O0lBR0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFVBQUQ7TUFBUSxNQUFLO01BQVMsVUFBVTtnQkFDN0IsVUFBVSxjQUFjO0tBQ25COzs7O2VBRVIsd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxXQUFVO01BQ1YsU0FBUztNQUNULFVBQVU7Z0JBQ1g7S0FFTzs7OzthQUNMOzs7Ozs7R0FDRDs7Ozs7VUFDSDs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRWRpdE1lZXRpbmdGb3JtLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IHsgdXNlU3RhdGUsIHR5cGUgRm9ybUV2ZW50IH0gZnJvbSAncmVhY3QnXHJcblxyXG50eXBlIE1lZXRpbmcgPSB7XHJcbiAgaWQ6IG51bWJlclxyXG4gIHRpdGxlOiBzdHJpbmdcclxuICBkZXNjcmlwdGlvbjogc3RyaW5nIHwgbnVsbFxyXG4gIHN0YXJ0c19hdDogc3RyaW5nXHJcbiAgZW5kc19hdDogc3RyaW5nXHJcbn1cclxuXHJcbnR5cGUgUHJvcHMgPSB7XHJcbiAgbWVldGluZzogTWVldGluZ1xyXG4gIHRva2VuOiBzdHJpbmdcclxuICBvblVwZGF0ZWQ6ICgpID0+IHZvaWQgfCBQcm9taXNlPHZvaWQ+XHJcbiAgb25DYW5jZWw6ICgpID0+IHZvaWRcclxufVxyXG5cclxuLy8gQ29udmVydCBBUEkgZGF0ZXRpbWUgaW50byB0aGUgYnJvd3NlcidzIGxvY2FsIHRpbWUuXHJcbmZ1bmN0aW9uIHRvTG9jYWxEYXRlVGltZSh2YWx1ZTogc3RyaW5nKTogc3RyaW5nIHtcclxuICBjb25zdCBkYXRlID0gbmV3IERhdGUodmFsdWUpXHJcblxyXG4gIGlmIChOdW1iZXIuaXNOYU4oZGF0ZS5nZXRUaW1lKCkpKSB7XHJcbiAgICByZXR1cm4gJydcclxuICB9XHJcblxyXG4gIGNvbnN0IHBhZCA9IChudW1iZXI6IG51bWJlcikgPT5cclxuICAgIFN0cmluZyhudW1iZXIpLnBhZFN0YXJ0KDIsICcwJylcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIGAke2RhdGUuZ2V0RnVsbFllYXIoKX0tYCArXHJcbiAgICBgJHtwYWQoZGF0ZS5nZXRNb250aCgpICsgMSl9LWAgK1xyXG4gICAgYCR7cGFkKGRhdGUuZ2V0RGF0ZSgpKX1UYCArXHJcbiAgICBgJHtwYWQoZGF0ZS5nZXRIb3VycygpKX06YCArXHJcbiAgICBgJHtwYWQoZGF0ZS5nZXRNaW51dGVzKCkpfWBcclxuICApXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEVkaXRNZWV0aW5nRm9ybSh7XHJcbiAgbWVldGluZyxcclxuICB0b2tlbixcclxuICBvblVwZGF0ZWQsXHJcbiAgb25DYW5jZWwsXHJcbn06IFByb3BzKSB7XHJcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZShtZWV0aW5nLnRpdGxlKVxyXG5cclxuICBjb25zdCBbZGVzY3JpcHRpb24sIHNldERlc2NyaXB0aW9uXSA9IHVzZVN0YXRlKFxyXG4gICAgbWVldGluZy5kZXNjcmlwdGlvbiB8fCAnJ1xyXG4gIClcclxuXHJcbiAgY29uc3QgW3N0YXJ0c0F0LCBzZXRTdGFydHNBdF0gPSB1c2VTdGF0ZShcclxuICAgIHRvTG9jYWxEYXRlVGltZShtZWV0aW5nLnN0YXJ0c19hdClcclxuICApXHJcblxyXG4gIGNvbnN0IFtlbmRzQXQsIHNldEVuZHNBdF0gPSB1c2VTdGF0ZShcclxuICAgIHRvTG9jYWxEYXRlVGltZShtZWV0aW5nLmVuZHNfYXQpXHJcbiAgKVxyXG5cclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoXHJcbiAgICBldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD5cclxuICApIHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgIHNldEVycm9yKCcnKVxyXG5cclxuICAgIGNvbnN0IHN0YXJ0ID0gbmV3IERhdGUoc3RhcnRzQXQpXHJcbiAgICBjb25zdCBlbmQgPSBuZXcgRGF0ZShlbmRzQXQpXHJcblxyXG4gICAgaWYgKFxyXG4gICAgICAhTnVtYmVyLmlzRmluaXRlKHN0YXJ0LmdldFRpbWUoKSkgfHxcclxuICAgICAgIU51bWJlci5pc0Zpbml0ZShlbmQuZ2V0VGltZSgpKSB8fFxyXG4gICAgICBlbmQgPD0gc3RhcnRcclxuICAgICkge1xyXG4gICAgICBzZXRFcnJvcignRW5kIHRpbWUgbXVzdCBiZSBsYXRlciB0aGFuIHN0YXJ0IHRpbWUuJylcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCF0aXRsZS50cmltKCkpIHtcclxuICAgICAgc2V0RXJyb3IoJ01lZXRpbmcgdGl0bGUgaXMgcmVxdWlyZWQuJylcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcblxyXG4gICAgc2V0TG9hZGluZyh0cnVlKVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgYC9hcGkvbWVldGluZ3MvJHttZWV0aW5nLmlkfWAsXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgbWV0aG9kOiAnUFVUJyxcclxuICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAsXHJcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICB0aXRsZTogdGl0bGUudHJpbSgpLFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24udHJpbSgpIHx8IG51bGwsXHJcbiAgICAgICAgICAgIHN0YXJ0c19hdDogc3RhcnQudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgICAgZW5kc19hdDogZW5kLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgICB9KSxcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuXHJcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2VcclxuICAgICAgICAgIC5qc29uKClcclxuICAgICAgICAgIC5jYXRjaCgoKSA9PiBudWxsKVxyXG5cclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXHJcbiAgICAgICAgICB0eXBlb2YgZGF0YT8uZGV0YWlsID09PSAnc3RyaW5nJ1xyXG4gICAgICAgICAgICA/IGRhdGEuZGV0YWlsXHJcbiAgICAgICAgICAgIDogYEZhaWxlZCB0byB1cGRhdGUgbWVldGluZyAoJHtyZXNwb25zZS5zdGF0dXN9KS5gXHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcblxyXG4gICAgICBhd2FpdCBvblVwZGF0ZWQoKVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldEVycm9yKFxyXG4gICAgICAgIGVyciBpbnN0YW5jZW9mIEVycm9yXHJcbiAgICAgICAgICA/IGVyci5tZXNzYWdlXHJcbiAgICAgICAgICA6ICdVbmFibGUgdG8gdXBkYXRlIG1lZXRpbmcuJ1xyXG4gICAgICApXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZWRpdC1tZWV0aW5nLWZvcm1cIj5cclxuICAgICAgPGgzPkVkaXQgT25saW5lIENsYXNzPC9oMz5cclxuXHJcbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxyXG4gICAgICAgIDxsYWJlbCBodG1sRm9yPXtgdGl0bGUtJHttZWV0aW5nLmlkfWB9PlxyXG4gICAgICAgICAgTWVldGluZyBUaXRsZVxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICBpZD17YHRpdGxlLSR7bWVldGluZy5pZH1gfVxyXG4gICAgICAgICAgdmFsdWU9e3RpdGxlfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUaXRsZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICBtYXhMZW5ndGg9ezIwMH1cclxuICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgLz5cclxuXHJcbiAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2BkZXNjcmlwdGlvbi0ke21lZXRpbmcuaWR9YH0+XHJcbiAgICAgICAgICBEZXNjcmlwdGlvblxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICBpZD17YGRlc2NyaXB0aW9uLSR7bWVldGluZy5pZH1gfVxyXG4gICAgICAgICAgdmFsdWU9e2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PlxyXG4gICAgICAgICAgICBzZXREZXNjcmlwdGlvbihlLnRhcmdldC52YWx1ZSlcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHJvd3M9ezN9XHJcbiAgICAgICAgLz5cclxuXHJcbiAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2BzdGFydC0ke21lZXRpbmcuaWR9YH0+XHJcbiAgICAgICAgICBTdGFydCBEYXRlIGFuZCBUaW1lXHJcbiAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIGlkPXtgc3RhcnQtJHttZWV0aW5nLmlkfWB9XHJcbiAgICAgICAgICB0eXBlPVwiZGF0ZXRpbWUtbG9jYWxcIlxyXG4gICAgICAgICAgdmFsdWU9e3N0YXJ0c0F0fVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdGFydHNBdChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgIC8+XHJcblxyXG4gICAgICAgIDxsYWJlbCBodG1sRm9yPXtgZW5kLSR7bWVldGluZy5pZH1gfT5cclxuICAgICAgICAgIEVuZCBEYXRlIGFuZCBUaW1lXHJcbiAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIGlkPXtgZW5kLSR7bWVldGluZy5pZH1gfVxyXG4gICAgICAgICAgdHlwZT1cImRhdGV0aW1lLWxvY2FsXCJcclxuICAgICAgICAgIHZhbHVlPXtlbmRzQXR9XHJcbiAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEVuZHNBdChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgIC8+XHJcblxyXG4gICAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgICA8cCBjbGFzc05hbWU9XCJlcnJvclwiIHJvbGU9XCJhbGVydFwiPlxyXG4gICAgICAgICAgICB7ZXJyb3J9XHJcbiAgICAgICAgICA8L3A+XHJcbiAgICAgICAgKX1cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtZWV0aW5nLWFjdGlvbnNcIj5cclxuICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXtsb2FkaW5nfT5cclxuICAgICAgICAgICAge2xvYWRpbmcgPyAnU2F2aW5nLi4uJyA6ICdTYXZlIENoYW5nZXMnfVxyXG4gICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2FuY2VsfVxyXG4gICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgQ2xvc2UgRWRpdG9yXHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgPC9mb3JtPlxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcbiJdfQ==