import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ScheduleMeetingForm.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/ScheduleMeetingForm.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
export default function ScheduleMeetingForm({ courseId, token, onCreated }) {
	_s();
	const [title, setTitle] = useState("");
	const [description, setDescription] = useState("");
	const [startsAt, setStartsAt] = useState("");
	const [endsAt, setEndsAt] = useState("");
	const [loading, setLoading] = useState(false);
	const [message, setMessage] = useState("");
	const [error, setError] = useState("");
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		setMessage("");
		const start = new Date(startsAt);
		const end = new Date(endsAt);
		if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime()) || end <= start) {
			setError("End time must be later than start time.");
			return;
		}
		setLoading(true);
		try {
			const response = await fetch(`/api/meetings/courses/${courseId}`, {
				method: "POST",
				headers: {
					Authorization: `Bearer ${token}`,
					"Content-Type": "application/json"
				},
				body: JSON.stringify({
					title: title.trim(),
					description: description.trim() || null,
					starts_at: start.toISOString(),
					ends_at: end.toISOString()
				})
			});
			if (!response.ok) {
				const data = await response.json().catch(() => null);
				throw new Error(typeof data?.detail === "string" ? data.detail : `Failed to schedule meeting (${response.status}).`);
			}
			setTitle("");
			setDescription("");
			setStartsAt("");
			setEndsAt("");
			setMessage("Meeting scheduled successfully.");
			await onCreated();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to schedule meeting.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "panel",
		children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Schedule Online Class" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("form", {
			onSubmit: handleSubmit,
			children: [
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "meeting-title",
					children: "Meeting Title"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 93,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					id: "meeting-title",
					value: title,
					onChange: (e) => setTitle(e.target.value),
					placeholder: "e.g. Software Engineering Lecture",
					maxLength: 200,
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 94,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "meeting-description",
					children: "Description"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 103,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("textarea", {
					id: "meeting-description",
					value: description,
					onChange: (e) => setDescription(e.target.value),
					placeholder: "Lecture topics and instructions",
					rows: 4
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 106,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "meeting-start",
					children: "Start Date and Time"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 114,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					id: "meeting-start",
					type: "datetime-local",
					value: startsAt,
					onChange: (e) => setStartsAt(e.target.value),
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 115,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("label", {
					htmlFor: "meeting-end",
					children: "End Date and Time"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 123,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("input", {
					id: "meeting-end",
					type: "datetime-local",
					value: endsAt,
					onChange: (e) => setEndsAt(e.target.value),
					required: true
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 124,
					columnNumber: 9
				}, this),
				error && /* @__PURE__ */ _jsxDEV("p", {
					className: "error",
					role: "alert",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 19
				}, this),
				message && /* @__PURE__ */ _jsxDEV("p", {
					className: "success-message",
					role: "status",
					children: message
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 135,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: loading,
					children: loading ? "Scheduling..." : "Schedule Class"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 140,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 92,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 89,
		columnNumber: 5
	}, this);
}
_s(ScheduleMeetingForm, "RTcu9vzlODVKjro/nfFtyJhPqCo=");
_c = ScheduleMeetingForm;
var _c;
$RefreshReg$(_c, "ScheduleMeetingForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ScheduleMeetingForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/ScheduleMeetingForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/ScheduleMeetingForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/ScheduleMeetingForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxnQkFBZ0M7Ozs7QUFRekMsZUFBZSxTQUFTLG9CQUFvQixFQUMxQyxVQUNBLE9BQ0EsYUFDUTs7Q0FDUixNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBUyxFQUFFO0NBQzNDLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxFQUFFO0NBQ3ZDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLO0NBQzVDLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxFQUFFO0NBQ3pDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBRXJDLGVBQWUsYUFBYSxPQUFtQztFQUM3RCxNQUFNLGVBQWU7RUFDckIsU0FBUyxFQUFFO0VBQ1gsV0FBVyxFQUFFO0VBRWIsTUFBTSxRQUFRLElBQUksS0FBSyxRQUFRO0VBQy9CLE1BQU0sTUFBTSxJQUFJLEtBQUssTUFBTTtFQUUzQixJQUNFLENBQUMsT0FBTyxTQUFTLE1BQU0sUUFBUSxDQUFDLEtBQ2hDLENBQUMsT0FBTyxTQUFTLElBQUksUUFBUSxDQUFDLEtBQzlCLE9BQU8sT0FDUDtHQUNBLFNBQVMseUNBQXlDO0dBQ2xEO0VBQ0Y7RUFFQSxXQUFXLElBQUk7RUFFZixJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sTUFDckIseUJBQXlCLFlBQ3pCO0lBQ0UsUUFBUTtJQUNSLFNBQVM7S0FDUCxlQUFlLFVBQVU7S0FDekIsZ0JBQWdCO0lBQ2xCO0lBQ0EsTUFBTSxLQUFLLFVBQVU7S0FDbkIsT0FBTyxNQUFNLEtBQUs7S0FDbEIsYUFBYSxZQUFZLEtBQUssS0FBSztLQUNuQyxXQUFXLE1BQU0sWUFBWTtLQUM3QixTQUFTLElBQUksWUFBWTtJQUMzQixDQUFDO0dBQ0gsQ0FDRjtHQUVBLElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQyxZQUFZLElBQUk7SUFFbkQsTUFBTSxJQUFJLE1BQ1IsT0FBTyxNQUFNLFdBQVcsV0FDcEIsS0FBSyxTQUNMLCtCQUErQixTQUFTLE9BQU8sR0FDckQ7R0FDRjtHQUVBLFNBQVMsRUFBRTtHQUNYLGVBQWUsRUFBRTtHQUNqQixZQUFZLEVBQUU7R0FDZCxVQUFVLEVBQUU7R0FDWixXQUFXLGlDQUFpQztHQUU1QyxNQUFNLFVBQVU7RUFDbEIsU0FBUyxLQUFLO0dBQ1osU0FDRSxlQUFlLFFBQ1gsSUFBSSxVQUNKLDZCQUNOO0VBQ0YsVUFBVTtHQUNSLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQixDQUNFLHdCQUFDLE1BQUQsWUFBSSx3QkFBeUI7Ozs7WUFFN0Isd0JBQUMsUUFBRDtHQUFNLFVBQVU7YUFBaEI7SUFDRSx3QkFBQyxTQUFEO0tBQU8sU0FBUTtlQUFnQjtJQUFvQjs7Ozs7SUFDbkQsd0JBQUMsU0FBRDtLQUNFLElBQUc7S0FDSCxPQUFPO0tBQ1AsV0FBVyxNQUFNLFNBQVMsRUFBRSxPQUFPLEtBQUs7S0FDeEMsYUFBWTtLQUNaLFdBQVc7S0FDWDtJQUNEOzs7OztJQUVELHdCQUFDLFNBQUQ7S0FBTyxTQUFRO2VBQXNCO0lBRTlCOzs7OztJQUNQLHdCQUFDLFlBQUQ7S0FDRSxJQUFHO0tBQ0gsT0FBTztLQUNQLFdBQVcsTUFBTSxlQUFlLEVBQUUsT0FBTyxLQUFLO0tBQzlDLGFBQVk7S0FDWixNQUFNO0lBQ1A7Ozs7O0lBRUQsd0JBQUMsU0FBRDtLQUFPLFNBQVE7ZUFBZ0I7SUFBMEI7Ozs7O0lBQ3pELHdCQUFDLFNBQUQ7S0FDRSxJQUFHO0tBQ0gsTUFBSztLQUNMLE9BQU87S0FDUCxXQUFXLE1BQU0sWUFBWSxFQUFFLE9BQU8sS0FBSztLQUMzQztJQUNEOzs7OztJQUVELHdCQUFDLFNBQUQ7S0FBTyxTQUFRO2VBQWM7SUFBd0I7Ozs7O0lBQ3JELHdCQUFDLFNBQUQ7S0FDRSxJQUFHO0tBQ0gsTUFBSztLQUNMLE9BQU87S0FDUCxXQUFXLE1BQU0sVUFBVSxFQUFFLE9BQU8sS0FBSztLQUN6QztJQUNEOzs7OztJQUVBLFNBQVMsd0JBQUMsS0FBRDtLQUFHLFdBQVU7S0FBUSxNQUFLO2VBQVM7SUFBUzs7Ozs7SUFFckQsV0FDQyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtLQUFrQixNQUFLO2VBQ2pDO0lBQ0E7Ozs7O0lBR0wsd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxVQUFVO2VBQzdCLFVBQVUsa0JBQWtCO0lBQ3ZCOzs7OztHQUNKOzs7OztVQUNDOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJTY2hlZHVsZU1lZXRpbmdGb3JtLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IHsgdXNlU3RhdGUsIHR5cGUgRm9ybUV2ZW50IH0gZnJvbSAncmVhY3QnXHJcblxyXG50eXBlIFByb3BzID0ge1xyXG4gIGNvdXJzZUlkOiBudW1iZXJcclxuICB0b2tlbjogc3RyaW5nXHJcbiAgb25DcmVhdGVkOiAoKSA9PiB2b2lkIHwgUHJvbWlzZTx2b2lkPlxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBTY2hlZHVsZU1lZXRpbmdGb3JtKHtcclxuICBjb3Vyc2VJZCxcclxuICB0b2tlbixcclxuICBvbkNyZWF0ZWQsXHJcbn06IFByb3BzKSB7XHJcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbZGVzY3JpcHRpb24sIHNldERlc2NyaXB0aW9uXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtzdGFydHNBdCwgc2V0U3RhcnRzQXRdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW2VuZHNBdCwgc2V0RW5kc0F0XSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpXHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pIHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgIHNldEVycm9yKCcnKVxyXG4gICAgc2V0TWVzc2FnZSgnJylcclxuXHJcbiAgICBjb25zdCBzdGFydCA9IG5ldyBEYXRlKHN0YXJ0c0F0KVxyXG4gICAgY29uc3QgZW5kID0gbmV3IERhdGUoZW5kc0F0KVxyXG5cclxuICAgIGlmIChcclxuICAgICAgIU51bWJlci5pc0Zpbml0ZShzdGFydC5nZXRUaW1lKCkpIHx8XHJcbiAgICAgICFOdW1iZXIuaXNGaW5pdGUoZW5kLmdldFRpbWUoKSkgfHxcclxuICAgICAgZW5kIDw9IHN0YXJ0XHJcbiAgICApIHtcclxuICAgICAgc2V0RXJyb3IoJ0VuZCB0aW1lIG11c3QgYmUgbGF0ZXIgdGhhbiBzdGFydCB0aW1lLicpXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG5cclxuICAgIHNldExvYWRpbmcodHJ1ZSlcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgIGAvYXBpL21lZXRpbmdzL2NvdXJzZXMvJHtjb3Vyc2VJZH1gLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCxcclxuICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgIHRpdGxlOiB0aXRsZS50cmltKCksXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBkZXNjcmlwdGlvbi50cmltKCkgfHwgbnVsbCxcclxuICAgICAgICAgICAgc3RhcnRzX2F0OiBzdGFydC50b0lTT1N0cmluZygpLFxyXG4gICAgICAgICAgICBlbmRzX2F0OiBlbmQudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgIH0pLFxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG5cclxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCkuY2F0Y2goKCkgPT4gbnVsbClcclxuXHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICAgICAgdHlwZW9mIGRhdGE/LmRldGFpbCA9PT0gJ3N0cmluZydcclxuICAgICAgICAgICAgPyBkYXRhLmRldGFpbFxyXG4gICAgICAgICAgICA6IGBGYWlsZWQgdG8gc2NoZWR1bGUgbWVldGluZyAoJHtyZXNwb25zZS5zdGF0dXN9KS5gXHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRUaXRsZSgnJylcclxuICAgICAgc2V0RGVzY3JpcHRpb24oJycpXHJcbiAgICAgIHNldFN0YXJ0c0F0KCcnKVxyXG4gICAgICBzZXRFbmRzQXQoJycpXHJcbiAgICAgIHNldE1lc3NhZ2UoJ01lZXRpbmcgc2NoZWR1bGVkIHN1Y2Nlc3NmdWxseS4nKVxyXG5cclxuICAgICAgYXdhaXQgb25DcmVhdGVkKClcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvcihcclxuICAgICAgICBlcnIgaW5zdGFuY2VvZiBFcnJvclxyXG4gICAgICAgICAgPyBlcnIubWVzc2FnZVxyXG4gICAgICAgICAgOiAnVW5hYmxlIHRvIHNjaGVkdWxlIG1lZXRpbmcuJ1xyXG4gICAgICApXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBhbmVsXCI+XHJcbiAgICAgIDxoMj5TY2hlZHVsZSBPbmxpbmUgQ2xhc3M8L2gyPlxyXG5cclxuICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJtZWV0aW5nLXRpdGxlXCI+TWVldGluZyBUaXRsZTwvbGFiZWw+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICBpZD1cIm1lZXRpbmctdGl0bGVcIlxyXG4gICAgICAgICAgdmFsdWU9e3RpdGxlfVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRUaXRsZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cImUuZy4gU29mdHdhcmUgRW5naW5lZXJpbmcgTGVjdHVyZVwiXHJcbiAgICAgICAgICBtYXhMZW5ndGg9ezIwMH1cclxuICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgLz5cclxuXHJcbiAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJtZWV0aW5nLWRlc2NyaXB0aW9uXCI+XHJcbiAgICAgICAgICBEZXNjcmlwdGlvblxyXG4gICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICBpZD1cIm1lZXRpbmctZGVzY3JpcHRpb25cIlxyXG4gICAgICAgICAgdmFsdWU9e2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREZXNjcmlwdGlvbihlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICBwbGFjZWhvbGRlcj1cIkxlY3R1cmUgdG9waWNzIGFuZCBpbnN0cnVjdGlvbnNcIlxyXG4gICAgICAgICAgcm93cz17NH1cclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm1lZXRpbmctc3RhcnRcIj5TdGFydCBEYXRlIGFuZCBUaW1lPC9sYWJlbD5cclxuICAgICAgICA8aW5wdXRcclxuICAgICAgICAgIGlkPVwibWVldGluZy1zdGFydFwiXHJcbiAgICAgICAgICB0eXBlPVwiZGF0ZXRpbWUtbG9jYWxcIlxyXG4gICAgICAgICAgdmFsdWU9e3N0YXJ0c0F0fVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRTdGFydHNBdChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgIC8+XHJcblxyXG4gICAgICAgIDxsYWJlbCBodG1sRm9yPVwibWVldGluZy1lbmRcIj5FbmQgRGF0ZSBhbmQgVGltZTwvbGFiZWw+XHJcbiAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICBpZD1cIm1lZXRpbmctZW5kXCJcclxuICAgICAgICAgIHR5cGU9XCJkYXRldGltZS1sb2NhbFwiXHJcbiAgICAgICAgICB2YWx1ZT17ZW5kc0F0fVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRFbmRzQXQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgcmVxdWlyZWRcclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj57ZXJyb3J9PC9wPn1cclxuXHJcbiAgICAgICAge21lc3NhZ2UgJiYgKFxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwic3VjY2Vzcy1tZXNzYWdlXCIgcm9sZT1cInN0YXR1c1wiPlxyXG4gICAgICAgICAgICB7bWVzc2FnZX1cclxuICAgICAgICAgIDwvcD5cclxuICAgICAgICApfVxyXG5cclxuICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17bG9hZGluZ30+XHJcbiAgICAgICAgICB7bG9hZGluZyA/ICdTY2hlZHVsaW5nLi4uJyA6ICdTY2hlZHVsZSBDbGFzcyd9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgIDwvZm9ybT5cclxuICAgIDwvc2VjdGlvbj5cclxuICApXHJcbn1cclxuIl19