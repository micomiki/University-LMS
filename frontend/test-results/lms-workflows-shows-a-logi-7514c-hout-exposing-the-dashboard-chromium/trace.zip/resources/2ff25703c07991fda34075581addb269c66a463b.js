import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AddNewSubmissionForm.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AddNewSubmissionForm.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
export default function AddNewSubmissionForm({ assignmentId, token, onSubmitted }) {
	_s();
	const [open, setOpen] = useState(false);
	const [textResponse, setTextResponse] = useState("");
	const [file, setFile] = useState(null);
	const [saving, setSaving] = useState(false);
	const [error, setError] = useState("");
	const [message, setMessage] = useState("");
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		setMessage("");
		if (!textResponse.trim() && !file) {
			setError("Enter a response or attach a file.");
			return;
		}
		const form = new FormData();
		if (textResponse.trim()) form.append("text_response", textResponse.trim());
		if (file) form.append("file", file);
		setSaving(true);
		try {
			const response = await fetch(`/api/submissions/assignments/${assignmentId}`, {
				method: "POST",
				headers: { Authorization: `Bearer ${token}` },
				body: form
			});
			if (!response.ok) {
				const body = await response.json().catch(() => null);
				throw new Error(typeof body?.detail === "string" ? body.detail : `Unable to add submission (HTTP ${response.status}).`);
			}
			setTextResponse("");
			setFile(null);
			setOpen(false);
			setMessage("New attempt added successfully.");
			await onSubmitted();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to add submission.");
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "new-attempt-form",
		children: [
			!open && /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				className: "btn-secondary",
				onClick: () => {
					setOpen(true);
					setError("");
					setMessage("");
				},
				children: "+ Add New Submission"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 9
			}, this),
			message && /* @__PURE__ */ _jsxDEV("p", {
				className: "success-message",
				role: "status",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 19
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 80,
				columnNumber: 17
			}, this),
			open && /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: (event) => void handleSubmit(event),
				children: [
					/* @__PURE__ */ _jsxDEV("h4", { children: "Add New Submission Attempt" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 84,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: "This creates a separate attempt. Earlier attempts and professor feedback will remain in your submission history." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 85,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: `new-attempt-text-${assignmentId}`,
						children: "Response (optional when a file is attached)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 89,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("textarea", {
						id: `new-attempt-text-${assignmentId}`,
						rows: 5,
						value: textResponse,
						onChange: (event) => setTextResponse(event.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 92,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: `new-attempt-file-${assignmentId}`,
						children: "Attach file (optional)"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: `new-attempt-file-${assignmentId}`,
						type: "file",
						accept: ".pdf,.doc,.docx,.ppt,.pptx,.txt,.csv,.xls,.xlsx,.png,.jpg,.jpeg",
						onChange: (event) => setFile(event.target.files?.[0] ?? null)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "submission-actions",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: saving,
							children: saving ? "Submitting..." : "Submit New Attempt"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 106,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "btn-secondary",
							disabled: saving,
							onClick: () => {
								setOpen(false);
								setTextResponse("");
								setFile(null);
								setError("");
							},
							children: "Cancel"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 109,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 105,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 83,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 64,
		columnNumber: 5
	}, this);
}
_s(AddNewSubmissionForm, "eYMHbww27YYZ92hWSaaUUoegr9M=");
_c = AddNewSubmissionForm;
var _c;
$RefreshReg$(_c, "AddNewSubmissionForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AddNewSubmissionForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AddNewSubmissionForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AddNewSubmissionForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AddNewSubmissionForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0M7Ozs7QUFRekMsZUFBZSxTQUFTLHFCQUFxQixFQUMzQyxjQUNBLE9BQ0EsZUFDUTs7Q0FDUixNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsS0FBSztDQUN0QyxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBUyxFQUFFO0NBQ25ELE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBc0IsSUFBSTtDQUNsRCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsS0FBSztDQUMxQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUV6QyxlQUFlLGFBQWEsT0FBbUM7RUFDN0QsTUFBTSxlQUFlO0VBQ3JCLFNBQVMsRUFBRTtFQUNYLFdBQVcsRUFBRTtFQUViLElBQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxDQUFDLE1BQU07R0FDakMsU0FBUyxvQ0FBb0M7R0FDN0M7RUFDRjtFQUVBLE1BQU0sT0FBTyxJQUFJLFNBQVM7RUFDMUIsSUFBSSxhQUFhLEtBQUssR0FBRyxLQUFLLE9BQU8saUJBQWlCLGFBQWEsS0FBSyxDQUFDO0VBQ3pFLElBQUksTUFBTSxLQUFLLE9BQU8sUUFBUSxJQUFJO0VBRWxDLFVBQVUsSUFBSTtFQUNkLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxNQUFNLGdDQUFnQyxnQkFBZ0I7SUFDM0UsUUFBUTtJQUNSLFNBQVMsRUFBRSxlQUFlLFVBQVUsUUFBUTtJQUM1QyxNQUFNO0dBQ1IsQ0FBQztHQUNELElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQyxZQUFZLElBQUk7SUFDbkQsTUFBTSxJQUFJLE1BQ1IsT0FBTyxNQUFNLFdBQVcsV0FDcEIsS0FBSyxTQUNMLGtDQUFrQyxTQUFTLE9BQU8sR0FDeEQ7R0FDRjtHQUVBLGdCQUFnQixFQUFFO0dBQ2xCLFFBQVEsSUFBSTtHQUNaLFFBQVEsS0FBSztHQUNiLFdBQVcsaUNBQWlDO0dBQzVDLE1BQU0sWUFBWTtFQUNwQixTQUFTLEtBQUs7R0FDWixTQUFTLGVBQWUsUUFBUSxJQUFJLFVBQVUsMkJBQTJCO0VBQzNFLFVBQVU7R0FDUixVQUFVLEtBQUs7RUFDakI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZjtHQUNHLENBQUMsUUFDQSx3QkFBQyxVQUFEO0lBQ0UsTUFBSztJQUNMLFdBQVU7SUFDVixlQUFlO0tBQ2IsUUFBUSxJQUFJO0tBQ1osU0FBUyxFQUFFO0tBQ1gsV0FBVyxFQUFFO0lBQ2Y7Y0FDRDtHQUVPOzs7OztHQUdULFdBQVcsd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBa0IsTUFBSztjQUFVO0dBQVc7Ozs7O0dBQ3BFLFNBQVMsd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBUSxNQUFLO2NBQVM7R0FBUzs7Ozs7R0FFckQsUUFDQyx3QkFBQyxRQUFEO0lBQU0sV0FBVyxVQUFVLEtBQUssYUFBYSxLQUFLO2NBQWxEO0tBQ0Usd0JBQUMsTUFBRCxZQUFJLDZCQUE4Qjs7Ozs7S0FDbEMsd0JBQUMsS0FBRCxZQUFHLG1IQUdBOzs7OztLQUNILHdCQUFDLFNBQUQ7TUFBTyxTQUFTLG9CQUFvQjtnQkFBZ0I7S0FFN0M7Ozs7O0tBQ1Asd0JBQUMsWUFBRDtNQUNFLElBQUksb0JBQW9CO01BQ3hCLE1BQU07TUFDTixPQUFPO01BQ1AsV0FBVyxVQUFVLGdCQUFnQixNQUFNLE9BQU8sS0FBSztLQUN4RDs7Ozs7S0FDRCx3QkFBQyxTQUFEO01BQU8sU0FBUyxvQkFBb0I7Z0JBQWdCO0tBQTZCOzs7OztLQUNqRix3QkFBQyxTQUFEO01BQ0UsSUFBSSxvQkFBb0I7TUFDeEIsTUFBSztNQUNMLFFBQU87TUFDUCxXQUFXLFVBQVUsUUFBUSxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUk7S0FDN0Q7Ozs7O0tBQ0Qsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQVEsTUFBSztPQUFTLFVBQVU7aUJBQzdCLFNBQVMsa0JBQWtCO01BQ3RCOzs7O2dCQUNSLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsV0FBVTtPQUNWLFVBQVU7T0FDVixlQUFlO1FBQ2IsUUFBUSxLQUFLO1FBQ2IsZ0JBQWdCLEVBQUU7UUFDbEIsUUFBUSxJQUFJO1FBQ1osU0FBUyxFQUFFO09BQ2I7aUJBQ0Q7TUFFTzs7OztjQUNMOzs7Ozs7SUFDRDs7Ozs7O0VBRUw7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFkZE5ld1N1Ym1pc3Npb25Gb3JtLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdHlwZSBGb3JtRXZlbnQgfSBmcm9tICdyZWFjdCdcblxudHlwZSBQcm9wcyA9IHtcbiAgYXNzaWdubWVudElkOiBudW1iZXJcbiAgdG9rZW46IHN0cmluZ1xuICBvblN1Ym1pdHRlZDogKCkgPT4gdm9pZCB8IFByb21pc2U8dm9pZD5cbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQWRkTmV3U3VibWlzc2lvbkZvcm0oe1xuICBhc3NpZ25tZW50SWQsXG4gIHRva2VuLFxuICBvblN1Ym1pdHRlZCxcbn06IFByb3BzKSB7XG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbdGV4dFJlc3BvbnNlLCBzZXRUZXh0UmVzcG9uc2VdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtmaWxlLCBzZXRGaWxlXSA9IHVzZVN0YXRlPEZpbGUgfCBudWxsPihudWxsKVxuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKCcnKVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pIHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG4gICAgc2V0RXJyb3IoJycpXG4gICAgc2V0TWVzc2FnZSgnJylcblxuICAgIGlmICghdGV4dFJlc3BvbnNlLnRyaW0oKSAmJiAhZmlsZSkge1xuICAgICAgc2V0RXJyb3IoJ0VudGVyIGEgcmVzcG9uc2Ugb3IgYXR0YWNoIGEgZmlsZS4nKVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgY29uc3QgZm9ybSA9IG5ldyBGb3JtRGF0YSgpXG4gICAgaWYgKHRleHRSZXNwb25zZS50cmltKCkpIGZvcm0uYXBwZW5kKCd0ZXh0X3Jlc3BvbnNlJywgdGV4dFJlc3BvbnNlLnRyaW0oKSlcbiAgICBpZiAoZmlsZSkgZm9ybS5hcHBlbmQoJ2ZpbGUnLCBmaWxlKVxuXG4gICAgc2V0U2F2aW5nKHRydWUpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goYC9hcGkvc3VibWlzc2lvbnMvYXNzaWdubWVudHMvJHthc3NpZ25tZW50SWR9YCwge1xuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9LFxuICAgICAgICBib2R5OiBmb3JtLFxuICAgICAgfSlcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgICAgY29uc3QgYm9keSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKS5jYXRjaCgoKSA9PiBudWxsKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgdHlwZW9mIGJvZHk/LmRldGFpbCA9PT0gJ3N0cmluZydcbiAgICAgICAgICAgID8gYm9keS5kZXRhaWxcbiAgICAgICAgICAgIDogYFVuYWJsZSB0byBhZGQgc3VibWlzc2lvbiAoSFRUUCAke3Jlc3BvbnNlLnN0YXR1c30pLmAsXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgc2V0VGV4dFJlc3BvbnNlKCcnKVxuICAgICAgc2V0RmlsZShudWxsKVxuICAgICAgc2V0T3BlbihmYWxzZSlcbiAgICAgIHNldE1lc3NhZ2UoJ05ldyBhdHRlbXB0IGFkZGVkIHN1Y2Nlc3NmdWxseS4nKVxuICAgICAgYXdhaXQgb25TdWJtaXR0ZWQoKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdVbmFibGUgdG8gYWRkIHN1Ym1pc3Npb24uJylcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0U2F2aW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJuZXctYXR0ZW1wdC1mb3JtXCI+XG4gICAgICB7IW9wZW4gJiYgKFxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiXG4gICAgICAgICAgb25DbGljaz17KCkgPT4ge1xuICAgICAgICAgICAgc2V0T3Blbih0cnVlKVxuICAgICAgICAgICAgc2V0RXJyb3IoJycpXG4gICAgICAgICAgICBzZXRNZXNzYWdlKCcnKVxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICArIEFkZCBOZXcgU3VibWlzc2lvblxuICAgICAgICA8L2J1dHRvbj5cbiAgICAgICl9XG5cbiAgICAgIHttZXNzYWdlICYmIDxwIGNsYXNzTmFtZT1cInN1Y2Nlc3MtbWVzc2FnZVwiIHJvbGU9XCJzdGF0dXNcIj57bWVzc2FnZX08L3A+fVxuICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImVycm9yXCIgcm9sZT1cImFsZXJ0XCI+e2Vycm9yfTwvcD59XG5cbiAgICAgIHtvcGVuICYmIChcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9eyhldmVudCkgPT4gdm9pZCBoYW5kbGVTdWJtaXQoZXZlbnQpfT5cbiAgICAgICAgICA8aDQ+QWRkIE5ldyBTdWJtaXNzaW9uIEF0dGVtcHQ8L2g0PlxuICAgICAgICAgIDxwPlxuICAgICAgICAgICAgVGhpcyBjcmVhdGVzIGEgc2VwYXJhdGUgYXR0ZW1wdC4gRWFybGllciBhdHRlbXB0cyBhbmQgcHJvZmVzc29yIGZlZWRiYWNrXG4gICAgICAgICAgICB3aWxsIHJlbWFpbiBpbiB5b3VyIHN1Ym1pc3Npb24gaGlzdG9yeS5cbiAgICAgICAgICA8L3A+XG4gICAgICAgICAgPGxhYmVsIGh0bWxGb3I9e2BuZXctYXR0ZW1wdC10ZXh0LSR7YXNzaWdubWVudElkfWB9PlxuICAgICAgICAgICAgUmVzcG9uc2UgKG9wdGlvbmFsIHdoZW4gYSBmaWxlIGlzIGF0dGFjaGVkKVxuICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICBpZD17YG5ldy1hdHRlbXB0LXRleHQtJHthc3NpZ25tZW50SWR9YH1cbiAgICAgICAgICAgIHJvd3M9ezV9XG4gICAgICAgICAgICB2YWx1ZT17dGV4dFJlc3BvbnNlfVxuICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT4gc2V0VGV4dFJlc3BvbnNlKGV2ZW50LnRhcmdldC52YWx1ZSl9XG4gICAgICAgICAgLz5cbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj17YG5ldy1hdHRlbXB0LWZpbGUtJHthc3NpZ25tZW50SWR9YH0+QXR0YWNoIGZpbGUgKG9wdGlvbmFsKTwvbGFiZWw+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICBpZD17YG5ldy1hdHRlbXB0LWZpbGUtJHthc3NpZ25tZW50SWR9YH1cbiAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcbiAgICAgICAgICAgIGFjY2VwdD1cIi5wZGYsLmRvYywuZG9jeCwucHB0LC5wcHR4LC50eHQsLmNzdiwueGxzLC54bHN4LC5wbmcsLmpwZywuanBlZ1wiXG4gICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PiBzZXRGaWxlKGV2ZW50LnRhcmdldC5maWxlcz8uWzBdID8/IG51bGwpfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzdWJtaXNzaW9uLWFjdGlvbnNcIj5cbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXtzYXZpbmd9PlxuICAgICAgICAgICAgICB7c2F2aW5nID8gJ1N1Ym1pdHRpbmcuLi4nIDogJ1N1Ym1pdCBOZXcgQXR0ZW1wdCd9XG4gICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnlcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XG4gICAgICAgICAgICAgICAgc2V0T3BlbihmYWxzZSlcbiAgICAgICAgICAgICAgICBzZXRUZXh0UmVzcG9uc2UoJycpXG4gICAgICAgICAgICAgICAgc2V0RmlsZShudWxsKVxuICAgICAgICAgICAgICAgIHNldEVycm9yKCcnKVxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBDYW5jZWxcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Zvcm0+XG4gICAgICApfVxuICAgIDwvZGl2PlxuICApXG59XG4iXX0=