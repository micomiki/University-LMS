import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/EditAssignmentForm.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/EditAssignmentForm.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
function toLocalDateTime(value) {
	const date = new Date(value);
	if (Number.isNaN(date.getTime())) return "";
	const pad = (n) => String(n).padStart(2, "0");
	return `${date.getFullYear()}-` + `${pad(date.getMonth() + 1)}-` + `${pad(date.getDate())}T` + `${pad(date.getHours())}:` + `${pad(date.getMinutes())}`;
}
export default function EditAssignmentForm({ assignment, token, onSaved, onCancel }) {
	_s();
	const [title, setTitle] = useState(assignment.title);
	const [description, setDescription] = useState(assignment.description ?? "");
	const [instructions, setInstructions] = useState(assignment.instructions ?? "");
	const [dueAt, setDueAt] = useState(toLocalDateTime(assignment.due_at));
	const [maxScore, setMaxScore] = useState(String(assignment.max_score));
	const [saving, setSaving] = useState(false);
	const [error, setError] = useState("");
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		const deadline = new Date(dueAt);
		const score = Number(maxScore);
		if (!title.trim()) {
			setError("Assignment title is required.");
			return;
		}
		if (Number.isNaN(deadline.getTime())) {
			setError("Enter a valid deadline.");
			return;
		}
		if (!Number.isFinite(score) || score <= 0) {
			setError("Maximum score must be greater than zero.");
			return;
		}
		setSaving(true);
		try {
			const response = await fetch(`/api/assignments/${assignment.id}`, {
				method: "PUT",
				headers: {
					Authorization: `Bearer ${token}`,
					"Content-Type": "application/json"
				},
				body: JSON.stringify({
					title: title.trim(),
					description: description.trim() || null,
					instructions: instructions.trim() || null,
					due_at: deadline.toISOString(),
					max_score: score
				})
			});
			if (!response.ok) {
				const data = await response.json().catch(() => null);
				throw new Error(typeof data?.detail === "string" ? data.detail : `Update failed (${response.status}).`);
			}
			onSaved();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to update assignment.");
		} finally {
			setSaving(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("form", {
		className: "edit-assignment-form",
		onSubmit: handleSubmit,
		children: [
			/* @__PURE__ */ _jsxDEV("h3", { children: "Edit Assignment" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 131,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: `title-${assignment.id}`,
				children: "Title"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 133,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				id: `title-${assignment.id}`,
				value: title,
				onChange: (e) => setTitle(e.target.value),
				maxLength: 200,
				required: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 136,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: `description-${assignment.id}`,
				children: "Description"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 144,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("textarea", {
				id: `description-${assignment.id}`,
				value: description,
				onChange: (e) => setDescription(e.target.value),
				rows: 3
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 147,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: `instructions-${assignment.id}`,
				children: "Instructions"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 154,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("textarea", {
				id: `instructions-${assignment.id}`,
				value: instructions,
				onChange: (e) => setInstructions(e.target.value),
				rows: 5
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 157,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: `due-${assignment.id}`,
				children: "Deadline"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 164,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				id: `due-${assignment.id}`,
				type: "datetime-local",
				value: dueAt,
				onChange: (e) => setDueAt(e.target.value),
				required: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 167,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("label", {
				htmlFor: `score-${assignment.id}`,
				children: "Maximum Score"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 175,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("input", {
				id: `score-${assignment.id}`,
				type: "number",
				min: "0.01",
				step: "0.01",
				value: maxScore,
				onChange: (e) => setMaxScore(e.target.value),
				required: true
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 178,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 189,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "submission-actions",
				children: [/* @__PURE__ */ _jsxDEV("button", {
					type: "submit",
					disabled: saving,
					children: saving ? "Saving..." : "Save Changes"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 195,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "btn-secondary",
					disabled: saving,
					onClick: onCancel,
					children: "Cancel"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 199,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 194,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 127,
		columnNumber: 5
	}, this);
}
_s(EditAssignmentForm, "k2xWDK1Vs6f8DSiJX7qQiZHw0Xk=");
_c = EditAssignmentForm;
var _c;
$RefreshReg$(_c, "EditAssignmentForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/EditAssignmentForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/EditAssignmentForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/EditAssignmentForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/EditAssignmentForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxnQkFBZ0M7Ozs7QUFrQnpDLFNBQVMsZ0JBQWdCLE9BQXVCO0NBQzlDLE1BQU0sT0FBTyxJQUFJLEtBQUssS0FBSztDQUUzQixJQUFJLE9BQU8sTUFBTSxLQUFLLFFBQVEsQ0FBQyxHQUFHLE9BQU87Q0FFekMsTUFBTSxPQUFPLE1BQWMsT0FBTyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsR0FBRztDQUVwRCxPQUNFLEdBQUcsS0FBSyxZQUFZLEVBQUUsS0FDdEIsR0FBRyxJQUFJLEtBQUssU0FBUyxJQUFJLENBQUMsRUFBRSxLQUM1QixHQUFHLElBQUksS0FBSyxRQUFRLENBQUMsRUFBRSxLQUN2QixHQUFHLElBQUksS0FBSyxTQUFTLENBQUMsRUFBRSxLQUN4QixHQUFHLElBQUksS0FBSyxXQUFXLENBQUM7QUFFNUI7QUFFQSxlQUFlLFNBQVMsbUJBQW1CLEVBQ3pDLFlBQ0EsT0FDQSxTQUNBLFlBQ1E7O0NBQ1IsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLFdBQVcsS0FBSztDQUNuRCxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FDcEMsV0FBVyxlQUFlLEVBQzVCO0NBQ0EsTUFBTSxDQUFDLGNBQWMsbUJBQW1CLFNBQ3RDLFdBQVcsZ0JBQWdCLEVBQzdCO0NBQ0EsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUN4QixnQkFBZ0IsV0FBVyxNQUFNLENBQ25DO0NBQ0EsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUM5QixPQUFPLFdBQVcsU0FBUyxDQUM3QjtDQUVBLE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxLQUFLO0NBQzFDLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBRXJDLGVBQWUsYUFDYixPQUNBO0VBQ0EsTUFBTSxlQUFlO0VBQ3JCLFNBQVMsRUFBRTtFQUVYLE1BQU0sV0FBVyxJQUFJLEtBQUssS0FBSztFQUMvQixNQUFNLFFBQVEsT0FBTyxRQUFRO0VBRTdCLElBQUksQ0FBQyxNQUFNLEtBQUssR0FBRztHQUNqQixTQUFTLCtCQUErQjtHQUN4QztFQUNGO0VBRUEsSUFBSSxPQUFPLE1BQU0sU0FBUyxRQUFRLENBQUMsR0FBRztHQUNwQyxTQUFTLHlCQUF5QjtHQUNsQztFQUNGO0VBRUEsSUFBSSxDQUFDLE9BQU8sU0FBUyxLQUFLLEtBQUssU0FBUyxHQUFHO0dBQ3pDLFNBQVMsMENBQTBDO0dBQ25EO0VBQ0Y7RUFFQSxVQUFVLElBQUk7RUFFZCxJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sTUFDckIsb0JBQW9CLFdBQVcsTUFDL0I7SUFDRSxRQUFRO0lBQ1IsU0FBUztLQUNQLGVBQWUsVUFBVTtLQUN6QixnQkFBZ0I7SUFDbEI7SUFDQSxNQUFNLEtBQUssVUFBVTtLQUNuQixPQUFPLE1BQU0sS0FBSztLQUNsQixhQUFhLFlBQVksS0FBSyxLQUFLO0tBQ25DLGNBQWMsYUFBYSxLQUFLLEtBQUs7S0FDckMsUUFBUSxTQUFTLFlBQVk7S0FDN0IsV0FBVztJQUNiLENBQUM7R0FDSCxDQUNGO0dBRUEsSUFBSSxDQUFDLFNBQVMsSUFBSTtJQUNoQixNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUssQ0FBQyxDQUFDLFlBQVksSUFBSTtJQUVuRCxNQUFNLElBQUksTUFDUixPQUFPLE1BQU0sV0FBVyxXQUNwQixLQUFLLFNBQ0wsa0JBQWtCLFNBQVMsT0FBTyxHQUN4QztHQUNGO0dBRUEsUUFBUTtFQUNWLFNBQVMsS0FBSztHQUNaLFNBQ0UsZUFBZSxRQUNYLElBQUksVUFDSiw4QkFDTjtFQUNGLFVBQVU7R0FDUixVQUFVLEtBQUs7RUFDakI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsUUFBRDtFQUNFLFdBQVU7RUFDVixVQUFVO1lBRlo7R0FJRSx3QkFBQyxNQUFELFlBQUksa0JBQW1COzs7OztHQUV2Qix3QkFBQyxTQUFEO0lBQU8sU0FBUyxTQUFTLFdBQVc7Y0FBTTtHQUVuQzs7Ozs7R0FDUCx3QkFBQyxTQUFEO0lBQ0UsSUFBSSxTQUFTLFdBQVc7SUFDeEIsT0FBTztJQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO0lBQ3hDLFdBQVc7SUFDWDtHQUNEOzs7OztHQUVELHdCQUFDLFNBQUQ7SUFBTyxTQUFTLGVBQWUsV0FBVztjQUFNO0dBRXpDOzs7OztHQUNQLHdCQUFDLFlBQUQ7SUFDRSxJQUFJLGVBQWUsV0FBVztJQUM5QixPQUFPO0lBQ1AsV0FBVyxNQUFNLGVBQWUsRUFBRSxPQUFPLEtBQUs7SUFDOUMsTUFBTTtHQUNQOzs7OztHQUVELHdCQUFDLFNBQUQ7SUFBTyxTQUFTLGdCQUFnQixXQUFXO2NBQU07R0FFMUM7Ozs7O0dBQ1Asd0JBQUMsWUFBRDtJQUNFLElBQUksZ0JBQWdCLFdBQVc7SUFDL0IsT0FBTztJQUNQLFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7SUFDL0MsTUFBTTtHQUNQOzs7OztHQUVELHdCQUFDLFNBQUQ7SUFBTyxTQUFTLE9BQU8sV0FBVztjQUFNO0dBRWpDOzs7OztHQUNQLHdCQUFDLFNBQUQ7SUFDRSxJQUFJLE9BQU8sV0FBVztJQUN0QixNQUFLO0lBQ0wsT0FBTztJQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO0lBQ3hDO0dBQ0Q7Ozs7O0dBRUQsd0JBQUMsU0FBRDtJQUFPLFNBQVMsU0FBUyxXQUFXO2NBQU07R0FFbkM7Ozs7O0dBQ1Asd0JBQUMsU0FBRDtJQUNFLElBQUksU0FBUyxXQUFXO0lBQ3hCLE1BQUs7SUFDTCxLQUFJO0lBQ0osTUFBSztJQUNMLE9BQU87SUFDUCxXQUFXLE1BQU0sWUFBWSxFQUFFLE9BQU8sS0FBSztJQUMzQztHQUNEOzs7OztHQUVBLFNBQ0Msd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBUSxNQUFLO2NBQ3ZCO0dBQ0E7Ozs7O0dBR0wsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLFVBQUQ7S0FBUSxNQUFLO0tBQVMsVUFBVTtlQUM3QixTQUFTLGNBQWM7SUFDbEI7Ozs7Y0FFUix3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLFdBQVU7S0FDVixVQUFVO0tBQ1YsU0FBUztlQUNWO0lBRU87Ozs7WUFDTDs7Ozs7O0VBQ0Q7Ozs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkVkaXRBc3NpZ25tZW50Rm9ybS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCB7IHVzZVN0YXRlLCB0eXBlIEZvcm1FdmVudCB9IGZyb20gJ3JlYWN0J1xyXG5cclxudHlwZSBBc3NpZ25tZW50ID0ge1xyXG4gIGlkOiBudW1iZXJcclxuICB0aXRsZTogc3RyaW5nXHJcbiAgZGVzY3JpcHRpb246IHN0cmluZyB8IG51bGxcclxuICBpbnN0cnVjdGlvbnM6IHN0cmluZyB8IG51bGxcclxuICBkdWVfYXQ6IHN0cmluZ1xyXG4gIG1heF9zY29yZTogbnVtYmVyIHwgc3RyaW5nXHJcbn1cclxuXHJcbnR5cGUgUHJvcHMgPSB7XHJcbiAgYXNzaWdubWVudDogQXNzaWdubWVudFxyXG4gIHRva2VuOiBzdHJpbmdcclxuICBvblNhdmVkOiAoKSA9PiB2b2lkXHJcbiAgb25DYW5jZWw6ICgpID0+IHZvaWRcclxufVxyXG5cclxuZnVuY3Rpb24gdG9Mb2NhbERhdGVUaW1lKHZhbHVlOiBzdHJpbmcpOiBzdHJpbmcge1xyXG4gIGNvbnN0IGRhdGUgPSBuZXcgRGF0ZSh2YWx1ZSlcclxuXHJcbiAgaWYgKE51bWJlci5pc05hTihkYXRlLmdldFRpbWUoKSkpIHJldHVybiAnJ1xyXG5cclxuICBjb25zdCBwYWQgPSAobjogbnVtYmVyKSA9PiBTdHJpbmcobikucGFkU3RhcnQoMiwgJzAnKVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgYCR7ZGF0ZS5nZXRGdWxsWWVhcigpfS1gICtcclxuICAgIGAke3BhZChkYXRlLmdldE1vbnRoKCkgKyAxKX0tYCArXHJcbiAgICBgJHtwYWQoZGF0ZS5nZXREYXRlKCkpfVRgICtcclxuICAgIGAke3BhZChkYXRlLmdldEhvdXJzKCkpfTpgICtcclxuICAgIGAke3BhZChkYXRlLmdldE1pbnV0ZXMoKSl9YFxyXG4gIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRWRpdEFzc2lnbm1lbnRGb3JtKHtcclxuICBhc3NpZ25tZW50LFxyXG4gIHRva2VuLFxyXG4gIG9uU2F2ZWQsXHJcbiAgb25DYW5jZWwsXHJcbn06IFByb3BzKSB7XHJcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZShhc3NpZ25tZW50LnRpdGxlKVxyXG4gIGNvbnN0IFtkZXNjcmlwdGlvbiwgc2V0RGVzY3JpcHRpb25dID0gdXNlU3RhdGUoXHJcbiAgICBhc3NpZ25tZW50LmRlc2NyaXB0aW9uID8/ICcnXHJcbiAgKVxyXG4gIGNvbnN0IFtpbnN0cnVjdGlvbnMsIHNldEluc3RydWN0aW9uc10gPSB1c2VTdGF0ZShcclxuICAgIGFzc2lnbm1lbnQuaW5zdHJ1Y3Rpb25zID8/ICcnXHJcbiAgKVxyXG4gIGNvbnN0IFtkdWVBdCwgc2V0RHVlQXRdID0gdXNlU3RhdGUoXHJcbiAgICB0b0xvY2FsRGF0ZVRpbWUoYXNzaWdubWVudC5kdWVfYXQpXHJcbiAgKVxyXG4gIGNvbnN0IFttYXhTY29yZSwgc2V0TWF4U2NvcmVdID0gdXNlU3RhdGUoXHJcbiAgICBTdHJpbmcoYXNzaWdubWVudC5tYXhfc2NvcmUpXHJcbiAgKVxyXG5cclxuICBjb25zdCBbc2F2aW5nLCBzZXRTYXZpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJylcclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gaGFuZGxlU3VibWl0KFxyXG4gICAgZXZlbnQ6IEZvcm1FdmVudDxIVE1MRm9ybUVsZW1lbnQ+XHJcbiAgKSB7XHJcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICBzZXRFcnJvcignJylcclxuXHJcbiAgICBjb25zdCBkZWFkbGluZSA9IG5ldyBEYXRlKGR1ZUF0KVxyXG4gICAgY29uc3Qgc2NvcmUgPSBOdW1iZXIobWF4U2NvcmUpXHJcblxyXG4gICAgaWYgKCF0aXRsZS50cmltKCkpIHtcclxuICAgICAgc2V0RXJyb3IoJ0Fzc2lnbm1lbnQgdGl0bGUgaXMgcmVxdWlyZWQuJylcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcblxyXG4gICAgaWYgKE51bWJlci5pc05hTihkZWFkbGluZS5nZXRUaW1lKCkpKSB7XHJcbiAgICAgIHNldEVycm9yKCdFbnRlciBhIHZhbGlkIGRlYWRsaW5lLicpXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG5cclxuICAgIGlmICghTnVtYmVyLmlzRmluaXRlKHNjb3JlKSB8fCBzY29yZSA8PSAwKSB7XHJcbiAgICAgIHNldEVycm9yKCdNYXhpbXVtIHNjb3JlIG11c3QgYmUgZ3JlYXRlciB0aGFuIHplcm8uJylcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcblxyXG4gICAgc2V0U2F2aW5nKHRydWUpXHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICBgL2FwaS9hc3NpZ25tZW50cy8ke2Fzc2lnbm1lbnQuaWR9YCxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBtZXRob2Q6ICdQVVQnLFxyXG4gICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCxcclxuICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgIHRpdGxlOiB0aXRsZS50cmltKCksXHJcbiAgICAgICAgICAgIGRlc2NyaXB0aW9uOiBkZXNjcmlwdGlvbi50cmltKCkgfHwgbnVsbCxcclxuICAgICAgICAgICAgaW5zdHJ1Y3Rpb25zOiBpbnN0cnVjdGlvbnMudHJpbSgpIHx8IG51bGwsXHJcbiAgICAgICAgICAgIGR1ZV9hdDogZGVhZGxpbmUudG9JU09TdHJpbmcoKSxcclxuICAgICAgICAgICAgbWF4X3Njb3JlOiBzY29yZSxcclxuICAgICAgICAgIH0pLFxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG5cclxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCkuY2F0Y2goKCkgPT4gbnVsbClcclxuXHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICAgICAgdHlwZW9mIGRhdGE/LmRldGFpbCA9PT0gJ3N0cmluZydcclxuICAgICAgICAgICAgPyBkYXRhLmRldGFpbFxyXG4gICAgICAgICAgICA6IGBVcGRhdGUgZmFpbGVkICgke3Jlc3BvbnNlLnN0YXR1c30pLmBcclxuICAgICAgICApXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIG9uU2F2ZWQoKVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldEVycm9yKFxyXG4gICAgICAgIGVyciBpbnN0YW5jZW9mIEVycm9yXHJcbiAgICAgICAgICA/IGVyci5tZXNzYWdlXHJcbiAgICAgICAgICA6ICdVbmFibGUgdG8gdXBkYXRlIGFzc2lnbm1lbnQuJ1xyXG4gICAgICApXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRTYXZpbmcoZmFsc2UpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGZvcm1cclxuICAgICAgY2xhc3NOYW1lPVwiZWRpdC1hc3NpZ25tZW50LWZvcm1cIlxyXG4gICAgICBvblN1Ym1pdD17aGFuZGxlU3VibWl0fVxyXG4gICAgPlxyXG4gICAgICA8aDM+RWRpdCBBc3NpZ25tZW50PC9oMz5cclxuXHJcbiAgICAgIDxsYWJlbCBodG1sRm9yPXtgdGl0bGUtJHthc3NpZ25tZW50LmlkfWB9PlxyXG4gICAgICAgIFRpdGxlXHJcbiAgICAgIDwvbGFiZWw+XHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIGlkPXtgdGl0bGUtJHthc3NpZ25tZW50LmlkfWB9XHJcbiAgICAgICAgdmFsdWU9e3RpdGxlfVxyXG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGl0bGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgIG1heExlbmd0aD17MjAwfVxyXG4gICAgICAgIHJlcXVpcmVkXHJcbiAgICAgIC8+XHJcblxyXG4gICAgICA8bGFiZWwgaHRtbEZvcj17YGRlc2NyaXB0aW9uLSR7YXNzaWdubWVudC5pZH1gfT5cclxuICAgICAgICBEZXNjcmlwdGlvblxyXG4gICAgICA8L2xhYmVsPlxyXG4gICAgICA8dGV4dGFyZWFcclxuICAgICAgICBpZD17YGRlc2NyaXB0aW9uLSR7YXNzaWdubWVudC5pZH1gfVxyXG4gICAgICAgIHZhbHVlPXtkZXNjcmlwdGlvbn1cclxuICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldERlc2NyaXB0aW9uKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICByb3dzPXszfVxyXG4gICAgICAvPlxyXG5cclxuICAgICAgPGxhYmVsIGh0bWxGb3I9e2BpbnN0cnVjdGlvbnMtJHthc3NpZ25tZW50LmlkfWB9PlxyXG4gICAgICAgIEluc3RydWN0aW9uc1xyXG4gICAgICA8L2xhYmVsPlxyXG4gICAgICA8dGV4dGFyZWFcclxuICAgICAgICBpZD17YGluc3RydWN0aW9ucy0ke2Fzc2lnbm1lbnQuaWR9YH1cclxuICAgICAgICB2YWx1ZT17aW5zdHJ1Y3Rpb25zfVxyXG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0SW5zdHJ1Y3Rpb25zKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICByb3dzPXs1fVxyXG4gICAgICAvPlxyXG5cclxuICAgICAgPGxhYmVsIGh0bWxGb3I9e2BkdWUtJHthc3NpZ25tZW50LmlkfWB9PlxyXG4gICAgICAgIERlYWRsaW5lXHJcbiAgICAgIDwvbGFiZWw+XHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIGlkPXtgZHVlLSR7YXNzaWdubWVudC5pZH1gfVxyXG4gICAgICAgIHR5cGU9XCJkYXRldGltZS1sb2NhbFwiXHJcbiAgICAgICAgdmFsdWU9e2R1ZUF0fVxyXG4gICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RHVlQXQoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgIHJlcXVpcmVkXHJcbiAgICAgIC8+XHJcblxyXG4gICAgICA8bGFiZWwgaHRtbEZvcj17YHNjb3JlLSR7YXNzaWdubWVudC5pZH1gfT5cclxuICAgICAgICBNYXhpbXVtIFNjb3JlXHJcbiAgICAgIDwvbGFiZWw+XHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIGlkPXtgc2NvcmUtJHthc3NpZ25tZW50LmlkfWB9XHJcbiAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgbWluPVwiMC4wMVwiXHJcbiAgICAgICAgc3RlcD1cIjAuMDFcIlxyXG4gICAgICAgIHZhbHVlPXttYXhTY29yZX1cclxuICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldE1heFNjb3JlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICByZXF1aXJlZFxyXG4gICAgICAvPlxyXG5cclxuICAgICAge2Vycm9yICYmIChcclxuICAgICAgICA8cCBjbGFzc05hbWU9XCJlcnJvclwiIHJvbGU9XCJhbGVydFwiPlxyXG4gICAgICAgICAge2Vycm9yfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VibWlzc2lvbi1hY3Rpb25zXCI+XHJcbiAgICAgICAgPGJ1dHRvbiB0eXBlPVwic3VibWl0XCIgZGlzYWJsZWQ9e3NhdmluZ30+XHJcbiAgICAgICAgICB7c2F2aW5nID8gJ1NhdmluZy4uLicgOiAnU2F2ZSBDaGFuZ2VzJ31cclxuICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJidG4tc2Vjb25kYXJ5XCJcclxuICAgICAgICAgIGRpc2FibGVkPXtzYXZpbmd9XHJcbiAgICAgICAgICBvbkNsaWNrPXtvbkNhbmNlbH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICBDYW5jZWxcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcbiAgICA8L2Zvcm0+XHJcbiAgKVxyXG59XHJcbiJdfQ==