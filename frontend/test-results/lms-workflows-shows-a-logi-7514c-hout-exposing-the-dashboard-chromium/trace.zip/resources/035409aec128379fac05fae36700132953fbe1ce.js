import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/FinalSubmissionSummary.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
import "/src/components/FinalSubmissionSummary.css";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/FinalSubmissionSummary.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
async function requireOk(response) {
	if (!response.ok) {
		const body = await response.json().catch(() => null);
		throw new Error(typeof body?.detail === "string" ? body.detail : `Request failed (HTTP ${response.status}).`);
	}
	return response;
}
export default function FinalSubmissionSummary({ submissionId, token, maxScore }) {
	_s();
	const [submission, setSubmission] = useState(null);
	const [loading, setLoading] = useState(true);
	const [refreshKey, setRefreshKey] = useState(0);
	const [downloading, setDownloading] = useState(false);
	const [error, setError] = useState("");
	useEffect(() => {
		const controller = new AbortController();
		async function loadSubmission() {
			setLoading(true);
			setError("");
			try {
				const response = await requireOk(await fetch(`/api/submissions/${submissionId}`, {
					headers: { Authorization: `Bearer ${token}` },
					signal: controller.signal
				}));
				const result = await response.json();
				if (!controller.signal.aborted) setSubmission(result);
			} catch (err) {
				if (!controller.signal.aborted) {
					setError(err instanceof Error ? err.message : "Unable to load submission.");
				}
			} finally {
				if (!controller.signal.aborted) setLoading(false);
			}
		}
		void loadSubmission();
		return () => controller.abort();
	}, [
		submissionId,
		token,
		refreshKey
	]);
	async function downloadFile() {
		if (!submission?.original_filename) return;
		setDownloading(true);
		setError("");
		try {
			const response = await requireOk(await fetch(`/api/submissions/${submissionId}/download`, { headers: { Authorization: `Bearer ${token}` } }));
			const blob = await response.blob();
			const url = URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.href = url;
			link.download = submission.original_filename;
			document.body.appendChild(link);
			link.click();
			link.remove();
			window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to download file.");
		} finally {
			setDownloading(false);
		}
	}
	const hasFinalGrade = submission?.score !== null && submission?.score !== undefined;
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "final-submission-summary",
		"aria-label": "Final submission",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "final-submission-summary-heading",
				children: [/* @__PURE__ */ _jsxDEV("h4", { children: "Final Submitted Work" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 101,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("span", {
					className: "final-submission-locked",
					children: "Submission closed"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 102,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 100,
				columnNumber: 7
			}, this),
			loading && /* @__PURE__ */ _jsxDEV("p", { children: "Loading your final submission..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 105,
				columnNumber: 19
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "error",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 106,
				columnNumber: 17
			}, this),
			!loading && submission && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				submission.text_response && /* @__PURE__ */ _jsxDEV("div", {
					className: "final-submission-response",
					children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Response" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 112,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", { children: submission.text_response }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 113,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 111,
					columnNumber: 13
				}, this),
				submission.original_filename && /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "btn-secondary",
					disabled: downloading,
					onClick: () => void downloadFile(),
					children: downloading ? "Downloading..." : `Download submitted file: ${submission.original_filename}`
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 118,
					columnNumber: 13
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "final-submission-grade",
					children: hasFinalGrade ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
						/* @__PURE__ */ _jsxDEV("strong", { children: [
							"Final grade: ",
							submission.score,
							" / ",
							maxScore
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 133,
							columnNumber: 17
						}, this),
						submission.feedback && /* @__PURE__ */ _jsxDEV("p", { children: [
							/* @__PURE__ */ _jsxDEV("strong", { children: "Final grading feedback:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 22
							}, this),
							" ",
							submission.feedback
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 135,
							columnNumber: 19
						}, this),
						submission.graded_at && /* @__PURE__ */ _jsxDEV("small", { children: ["Graded: ", new Date(submission.graded_at).toLocaleString()] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 138,
							columnNumber: 19
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 132,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV("p", { children: "Final grade: Awaiting professor grading." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 142,
						columnNumber: 15
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 130,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "btn-secondary",
					onClick: () => setRefreshKey((previous) => previous + 1),
					disabled: loading,
					children: "Refresh final grade"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 146,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 109,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 99,
		columnNumber: 5
	}, this);
}
_s(FinalSubmissionSummary, "xyFX+O7NBjanNPGUGi83nwaSswI=");
_c = FinalSubmissionSummary;
var _c;
$RefreshReg$(_c, "FinalSubmissionSummary");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/FinalSubmissionSummary.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/FinalSubmissionSummary.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/FinalSubmissionSummary.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/FinalSubmissionSummary.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxPQUFPOzs7O0FBaUJQLGVBQWUsVUFBVSxVQUF1QztDQUM5RCxJQUFJLENBQUMsU0FBUyxJQUFJO0VBQ2hCLE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSyxDQUFDLENBQUMsWUFBWSxJQUFJO0VBQ25ELE1BQU0sSUFBSSxNQUNSLE9BQU8sTUFBTSxXQUFXLFdBQ3BCLEtBQUssU0FDTCx3QkFBd0IsU0FBUyxPQUFPLEdBQzlDO0NBQ0Y7Q0FDQSxPQUFPO0FBQ1Q7QUFFQSxlQUFlLFNBQVMsdUJBQXVCLEVBQzdDLGNBQ0EsT0FDQSxZQUNROztDQUNSLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFrQyxJQUFJO0NBQzFFLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0NBQzNDLE1BQU0sQ0FBQyxZQUFZLGlCQUFpQixTQUFTLENBQUM7Q0FDOUMsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQVMsS0FBSztDQUNwRCxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUVyQyxnQkFBZ0I7RUFDZCxNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7RUFFdkMsZUFBZSxpQkFBaUI7R0FDOUIsV0FBVyxJQUFJO0dBQ2YsU0FBUyxFQUFFO0dBQ1gsSUFBSTtJQUNGLE1BQU0sV0FBVyxNQUFNLFVBQ3JCLE1BQU0sTUFBTSxvQkFBb0IsZ0JBQWdCO0tBQzlDLFNBQVMsRUFBRSxlQUFlLFVBQVUsUUFBUTtLQUM1QyxRQUFRLFdBQVc7SUFDckIsQ0FBQyxDQUNIO0lBQ0EsTUFBTSxTQUFVLE1BQU0sU0FBUyxLQUFLO0lBQ3BDLElBQUksQ0FBQyxXQUFXLE9BQU8sU0FBUyxjQUFjLE1BQU07R0FDdEQsU0FBUyxLQUFLO0lBQ1osSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUFTO0tBQzlCLFNBQVMsZUFBZSxRQUFRLElBQUksVUFBVSw0QkFBNEI7SUFDNUU7R0FDRixVQUFVO0lBQ1IsSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUFTLFdBQVcsS0FBSztHQUNsRDtFQUNGO0VBRUEsS0FBSyxlQUFlO0VBQ3BCLGFBQWEsV0FBVyxNQUFNO0NBQ2hDLEdBQUc7RUFBQztFQUFjO0VBQU87Q0FBVSxDQUFDO0NBRXBDLGVBQWUsZUFBZTtFQUM1QixJQUFJLENBQUMsWUFBWSxtQkFBbUI7RUFDcEMsZUFBZSxJQUFJO0VBQ25CLFNBQVMsRUFBRTtFQUNYLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxVQUNyQixNQUFNLE1BQU0sb0JBQW9CLGFBQWEsWUFBWSxFQUN2RCxTQUFTLEVBQUUsZUFBZSxVQUFVLFFBQVEsRUFDOUMsQ0FBQyxDQUNIO0dBQ0EsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLO0dBQ2pDLE1BQU0sTUFBTSxJQUFJLGdCQUFnQixJQUFJO0dBQ3BDLE1BQU0sT0FBTyxTQUFTLGNBQWMsR0FBRztHQUN2QyxLQUFLLE9BQU87R0FDWixLQUFLLFdBQVcsV0FBVztHQUMzQixTQUFTLEtBQUssWUFBWSxJQUFJO0dBQzlCLEtBQUssTUFBTTtHQUNYLEtBQUssT0FBTztHQUNaLE9BQU8saUJBQWlCLElBQUksZ0JBQWdCLEdBQUcsR0FBRyxHQUFJO0VBQ3hELFNBQVMsS0FBSztHQUNaLFNBQVMsZUFBZSxRQUFRLElBQUksVUFBVSwwQkFBMEI7RUFDMUUsVUFBVTtHQUNSLGVBQWUsS0FBSztFQUN0QjtDQUNGO0NBRUEsTUFBTSxnQkFBZ0IsWUFBWSxVQUFVLFFBQVEsWUFBWSxVQUFVO0NBRTFFLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7RUFBMkIsY0FBVztZQUF6RDtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUksdUJBQXdCOzs7O2NBQzVCLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQTBCO0lBQXVCOzs7O1lBQzlEOzs7Ozs7R0FFSixXQUFXLHdCQUFDLEtBQUQsWUFBRyxtQ0FBbUM7Ozs7O0dBQ2pELFNBQVMsd0JBQUMsS0FBRDtJQUFHLE1BQUs7SUFBUSxXQUFVO2NBQVM7R0FBUzs7Ozs7R0FFckQsQ0FBQyxXQUFXLGNBQ1g7SUFDRyxXQUFXLGlCQUNWLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWYsQ0FDRSx3QkFBQyxVQUFELFlBQVEsV0FBZ0I7Ozs7ZUFDeEIsd0JBQUMsS0FBRCxZQUFJLFdBQVcsY0FBaUI7Ozs7YUFDN0I7Ozs7OztJQUdOLFdBQVcscUJBQ1Ysd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxXQUFVO0tBQ1YsVUFBVTtLQUNWLGVBQWUsS0FBSyxhQUFhO2VBRWhDLGNBQ0csbUJBQ0EsNEJBQTRCLFdBQVc7SUFDckM7Ozs7O0lBR1Ysd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFDWixnQkFDQztNQUNFLHdCQUFDLFVBQUQ7T0FBUTtPQUFjLFdBQVc7T0FBTTtPQUFJO01BQWlCOzs7OztNQUMzRCxXQUFXLFlBQ1Ysd0JBQUMsS0FBRDtPQUFHLHdCQUFDLFVBQUQsWUFBUSwwQkFBK0I7Ozs7O09BQUM7T0FBRSxXQUFXO01BQVk7Ozs7O01BRXJFLFdBQVcsYUFDVix3QkFBQyxTQUFELGFBQU8sWUFBUyxJQUFJLEtBQUssV0FBVyxTQUFTLENBQUMsQ0FBQyxlQUFlLENBQVM7Ozs7O0tBRXpFOzs7O2dCQUVGLHdCQUFDLEtBQUQsWUFBRywyQ0FBMkM7Ozs7O0lBRTdDOzs7OztJQUVMLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsV0FBVTtLQUNWLGVBQWUsZUFBZSxhQUFhLFdBQVcsQ0FBQztLQUN2RCxVQUFVO2VBQ1g7SUFFTzs7Ozs7R0FDUjs7Ozs7RUFFRzs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiRmluYWxTdWJtaXNzaW9uU3VtbWFyeS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0ICcuL0ZpbmFsU3VibWlzc2lvblN1bW1hcnkuY3NzJ1xuXG50eXBlIFN1Ym1pc3Npb25EZXRhaWwgPSB7XG4gIGlkOiBudW1iZXJcbiAgdGV4dF9yZXNwb25zZT86IHN0cmluZyB8IG51bGxcbiAgb3JpZ2luYWxfZmlsZW5hbWU/OiBzdHJpbmcgfCBudWxsXG4gIHNjb3JlPzogbnVtYmVyIHwgc3RyaW5nIHwgbnVsbFxuICBmZWVkYmFjaz86IHN0cmluZyB8IG51bGxcbiAgZ3JhZGVkX2F0Pzogc3RyaW5nIHwgbnVsbFxufVxuXG50eXBlIFByb3BzID0ge1xuICBzdWJtaXNzaW9uSWQ6IG51bWJlclxuICB0b2tlbjogc3RyaW5nXG4gIG1heFNjb3JlOiBudW1iZXIgfCBzdHJpbmdcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVxdWlyZU9rKHJlc3BvbnNlOiBSZXNwb25zZSk6IFByb21pc2U8UmVzcG9uc2U+IHtcbiAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgIGNvbnN0IGJvZHkgPSBhd2FpdCByZXNwb25zZS5qc29uKCkuY2F0Y2goKCkgPT4gbnVsbClcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICB0eXBlb2YgYm9keT8uZGV0YWlsID09PSAnc3RyaW5nJ1xuICAgICAgICA/IGJvZHkuZGV0YWlsXG4gICAgICAgIDogYFJlcXVlc3QgZmFpbGVkIChIVFRQICR7cmVzcG9uc2Uuc3RhdHVzfSkuYCxcbiAgICApXG4gIH1cbiAgcmV0dXJuIHJlc3BvbnNlXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZpbmFsU3VibWlzc2lvblN1bW1hcnkoe1xuICBzdWJtaXNzaW9uSWQsXG4gIHRva2VuLFxuICBtYXhTY29yZSxcbn06IFByb3BzKSB7XG4gIGNvbnN0IFtzdWJtaXNzaW9uLCBzZXRTdWJtaXNzaW9uXSA9IHVzZVN0YXRlPFN1Ym1pc3Npb25EZXRhaWwgfCBudWxsPihudWxsKVxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKVxuICBjb25zdCBbcmVmcmVzaEtleSwgc2V0UmVmcmVzaEtleV0gPSB1c2VTdGF0ZSgwKVxuICBjb25zdCBbZG93bmxvYWRpbmcsIHNldERvd25sb2FkaW5nXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKVxuXG4gICAgYXN5bmMgZnVuY3Rpb24gbG9hZFN1Ym1pc3Npb24oKSB7XG4gICAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgICBzZXRFcnJvcignJylcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcmVxdWlyZU9rKFxuICAgICAgICAgIGF3YWl0IGZldGNoKGAvYXBpL3N1Ym1pc3Npb25zLyR7c3VibWlzc2lvbklkfWAsIHtcbiAgICAgICAgICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAgfSxcbiAgICAgICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXG4gICAgICAgICAgfSksXG4gICAgICAgIClcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IHJlc3BvbnNlLmpzb24oKSkgYXMgU3VibWlzc2lvbkRldGFpbFxuICAgICAgICBpZiAoIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHNldFN1Ym1pc3Npb24ocmVzdWx0KVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGlmICghY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgICAgIHNldEVycm9yKGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiAnVW5hYmxlIHRvIGxvYWQgc3VibWlzc2lvbi4nKVxuICAgICAgICB9XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBpZiAoIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHNldExvYWRpbmcoZmFsc2UpXG4gICAgICB9XG4gICAgfVxuXG4gICAgdm9pZCBsb2FkU3VibWlzc2lvbigpXG4gICAgcmV0dXJuICgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKVxuICB9LCBbc3VibWlzc2lvbklkLCB0b2tlbiwgcmVmcmVzaEtleV0pXG5cbiAgYXN5bmMgZnVuY3Rpb24gZG93bmxvYWRGaWxlKCkge1xuICAgIGlmICghc3VibWlzc2lvbj8ub3JpZ2luYWxfZmlsZW5hbWUpIHJldHVyblxuICAgIHNldERvd25sb2FkaW5nKHRydWUpXG4gICAgc2V0RXJyb3IoJycpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcmVxdWlyZU9rKFxuICAgICAgICBhd2FpdCBmZXRjaChgL2FwaS9zdWJtaXNzaW9ucy8ke3N1Ym1pc3Npb25JZH0vZG93bmxvYWRgLCB7XG4gICAgICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9LFxuICAgICAgICB9KSxcbiAgICAgIClcbiAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXNwb25zZS5ibG9iKClcbiAgICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYilcbiAgICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJylcbiAgICAgIGxpbmsuaHJlZiA9IHVybFxuICAgICAgbGluay5kb3dubG9hZCA9IHN1Ym1pc3Npb24ub3JpZ2luYWxfZmlsZW5hbWVcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluaylcbiAgICAgIGxpbmsuY2xpY2soKVxuICAgICAgbGluay5yZW1vdmUoKVxuICAgICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4gVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpLCAxMDAwKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdVbmFibGUgdG8gZG93bmxvYWQgZmlsZS4nKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXREb3dubG9hZGluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYXNGaW5hbEdyYWRlID0gc3VibWlzc2lvbj8uc2NvcmUgIT09IG51bGwgJiYgc3VibWlzc2lvbj8uc2NvcmUgIT09IHVuZGVmaW5lZFxuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiZmluYWwtc3VibWlzc2lvbi1zdW1tYXJ5XCIgYXJpYS1sYWJlbD1cIkZpbmFsIHN1Ym1pc3Npb25cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmluYWwtc3VibWlzc2lvbi1zdW1tYXJ5LWhlYWRpbmdcIj5cbiAgICAgICAgPGg0PkZpbmFsIFN1Ym1pdHRlZCBXb3JrPC9oND5cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZmluYWwtc3VibWlzc2lvbi1sb2NrZWRcIj5TdWJtaXNzaW9uIGNsb3NlZDwvc3Bhbj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7bG9hZGluZyAmJiA8cD5Mb2FkaW5nIHlvdXIgZmluYWwgc3VibWlzc2lvbi4uLjwvcD59XG4gICAgICB7ZXJyb3IgJiYgPHAgcm9sZT1cImFsZXJ0XCIgY2xhc3NOYW1lPVwiZXJyb3JcIj57ZXJyb3J9PC9wPn1cblxuICAgICAgeyFsb2FkaW5nICYmIHN1Ym1pc3Npb24gJiYgKFxuICAgICAgICA8PlxuICAgICAgICAgIHtzdWJtaXNzaW9uLnRleHRfcmVzcG9uc2UgJiYgKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmaW5hbC1zdWJtaXNzaW9uLXJlc3BvbnNlXCI+XG4gICAgICAgICAgICAgIDxzdHJvbmc+UmVzcG9uc2U8L3N0cm9uZz5cbiAgICAgICAgICAgICAgPHA+e3N1Ym1pc3Npb24udGV4dF9yZXNwb25zZX08L3A+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge3N1Ym1pc3Npb24ub3JpZ2luYWxfZmlsZW5hbWUgJiYgKFxuICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtkb3dubG9hZGluZ31cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdm9pZCBkb3dubG9hZEZpbGUoKX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge2Rvd25sb2FkaW5nXG4gICAgICAgICAgICAgICAgPyAnRG93bmxvYWRpbmcuLi4nXG4gICAgICAgICAgICAgICAgOiBgRG93bmxvYWQgc3VibWl0dGVkIGZpbGU6ICR7c3VibWlzc2lvbi5vcmlnaW5hbF9maWxlbmFtZX1gfVxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmluYWwtc3VibWlzc2lvbi1ncmFkZVwiPlxuICAgICAgICAgICAge2hhc0ZpbmFsR3JhZGUgPyAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPHN0cm9uZz5GaW5hbCBncmFkZToge3N1Ym1pc3Npb24uc2NvcmV9IC8ge21heFNjb3JlfTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgIHtzdWJtaXNzaW9uLmZlZWRiYWNrICYmIChcbiAgICAgICAgICAgICAgICAgIDxwPjxzdHJvbmc+RmluYWwgZ3JhZGluZyBmZWVkYmFjazo8L3N0cm9uZz4ge3N1Ym1pc3Npb24uZmVlZGJhY2t9PC9wPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgICAge3N1Ym1pc3Npb24uZ3JhZGVkX2F0ICYmIChcbiAgICAgICAgICAgICAgICAgIDxzbWFsbD5HcmFkZWQ6IHtuZXcgRGF0ZShzdWJtaXNzaW9uLmdyYWRlZF9hdCkudG9Mb2NhbGVTdHJpbmcoKX08L3NtYWxsPlxuICAgICAgICAgICAgICAgICl9XG4gICAgICAgICAgICAgIDwvPlxuICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgPHA+RmluYWwgZ3JhZGU6IEF3YWl0aW5nIHByb2Zlc3NvciBncmFkaW5nLjwvcD5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnlcIlxuICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmVmcmVzaEtleSgocHJldmlvdXMpID0+IHByZXZpb3VzICsgMSl9XG4gICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICA+XG4gICAgICAgICAgICBSZWZyZXNoIGZpbmFsIGdyYWRlXG4gICAgICAgICAgPC9idXR0b24+XG4gICAgICAgIDwvPlxuICAgICAgKX1cbiAgICA8L3NlY3Rpb24+XG4gIClcbn1cbiJdfQ==