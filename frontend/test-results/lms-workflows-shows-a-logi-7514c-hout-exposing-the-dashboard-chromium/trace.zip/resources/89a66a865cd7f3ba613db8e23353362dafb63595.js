import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport12_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport12_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
import ScheduleMeetingForm from "/src/components/ScheduleMeetingForm.tsx";
import EditMeetingForm from "/src/components/EditMeetingForm.tsx";
import TrackedClassroom from "/src/components/TrackedClassroom.tsx";
import AttendanceManager from "/src/components/AttendanceManager.tsx";
import AutomaticAttendanceReport from "/src/components/AutomaticAttendanceReport.tsx";
import RoleDashboard from "/src/components/RoleDashboard.tsx";
import CourseMaterials from "/src/components/CourseMaterials.tsx";
import CourseAssignments from "/src/components/CourseAssignments.tsx";
import NotificationCenter from "/src/components/NotificationCenter.tsx";
import Sidebar from "/src/components/Sidebar.tsx";
import CourseSubNav from "/src/components/CourseSubNav.tsx";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/App.tsx";
import __vite__cjsImport12_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
async function apiRequest(path, options = {}, token) {
	const headers = new Headers(options.headers);
	if (token) {
		headers.set("Authorization", `Bearer ${token}`);
	}
	const response = await fetch(path, {
		...options,
		headers
	});
	if (!response.ok) {
		let message = `Request failed (${response.status})`;
		try {
			const body = await response.json();
			if (typeof body.detail === "string") {
				message = body.detail;
			}
		} catch {}
		throw new Error(message);
	}
	return response.json();
}
function getJitsiRoom(meetingUrl) {
	const url = new URL(meetingUrl);
	const roomName = url.pathname.slice(1);
	if (url.protocol !== "https:" || url.hostname !== "meet.jit.si" || !/^[a-zA-Z0-9_-]+$/.test(roomName)) {
		throw new Error("Invalid Jitsi meeting URL.");
	}
	return roomName;
}
function formatDate(value) {
	return new Date(value).toLocaleString();
}
export default function App() {
	_s();
	const [email, setEmail] = useState("");
	const [password, setPassword] = useState("");
	const [token, setToken] = useState("");
	const [editingMeetingId, setEditingMeetingId] = useState(null);
	const [attendanceMeetingId, setAttendanceMeetingId] = useState(null);
	const [account, setAccount] = useState(null);
	const [activeMeetingId, setActiveMeetingId] = useState(null);
	const [page, setPage] = useState("dashboard");
	const [autoReportMeetingId, setAutoReportMeetingId] = useState(null);
	const [courses, setCourses] = useState([]);
	const [meetings, setMeetings] = useState([]);
	const [selectedCourseId, setSelectedCourseId] = useState(null);
	const [courseSection, setCourseSection] = useState("overview");
	const [roomName, setRoomName] = useState("");
	const [error, setError] = useState("");
	const [loading, setLoading] = useState(false);
	const canManageMeetings = account?.role.toLowerCase() === "professor" || account?.role.toLowerCase() === "admin";
	async function handleLogin(event) {
		event.preventDefault();
		setError("");
		setLoading(true);
		try {
			const credentials = new URLSearchParams({
				username: email,
				password
			});
			const login = await apiRequest("/api/auth/login", {
				method: "POST",
				headers: { "Content-Type": "application/x-www-form-urlencoded" },
				body: credentials
			});
			const user = await apiRequest("/api/auth/me", {}, login.access_token);
			const courseList = await apiRequest("/api/courses/", {}, login.access_token);
			setToken(login.access_token);
			setAccount(user);
			setCourses(courseList);
			setPassword("");
			setPage("dashboard");
		} catch (err) {
			setError(err instanceof Error ? err.message : "Login failed.");
		} finally {
			setLoading(false);
		}
	}
	async function selectCourse(courseId) {
		setSelectedCourseId(courseId);
		setMeetings([]);
		setRoomName("");
		setError("");
		setLoading(true);
		setEditingMeetingId(null);
		setAttendanceMeetingId(null);
		setActiveMeetingId(null);
		setAutoReportMeetingId(null);
		setCourseSection("overview");
		try {
			const result = await apiRequest(`/api/meetings/courses/${courseId}`, {}, token);
			setMeetings([...result].sort((a, b) => new Date(a.starts_at).getTime() - new Date(b.starts_at).getTime()));
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to load meetings.");
		} finally {
			setLoading(false);
		}
	}
	async function openMeeting(meeting, create) {
		setError("");
		setLoading(true);
		try {
			const action = create ? "room" : "join";
			const result = await apiRequest(`/api/meetings/${meeting.id}/${action}`, { method: create ? "POST" : "GET" }, token);
			const room = getJitsiRoom(result.meeting_url);
			setActiveMeetingId(meeting.id);
			setRoomName(room);
			setPage("classroom");
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to open classroom.");
		} finally {
			setLoading(false);
		}
	}
	async function cancelMeeting(meeting) {
		const confirmed = window.confirm(`Are you sure you want to cancel "${meeting.title}"?`);
		if (!confirmed) {
			return;
		}
		setError("");
		setLoading(true);
		try {
			await apiRequest(`/api/meetings/${meeting.id}`, { method: "DELETE" }, token);
			setEditingMeetingId(null);
			// Reload meetings to show the updated status.
			await selectCourse(meeting.course_id);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to cancel meeting.");
		} finally {
			setLoading(false);
		}
	}
	function logout() {
		setToken("");
		setAccount(null);
		setCourses([]);
		setMeetings([]);
		setSelectedCourseId(null);
		setRoomName("");
		setError("");
		setPassword("");
		setAttendanceMeetingId(null);
		setPage("dashboard");
		setActiveMeetingId(null);
		setAutoReportMeetingId(null);
	}
	if (!account) {
		return /* @__PURE__ */ _jsxDEV("main", {
			className: "container",
			children: [/* @__PURE__ */ _jsxDEV("header", {
				className: "panel",
				children: [/* @__PURE__ */ _jsxDEV("h1", { children: "University LMS" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 315,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Learning Management System" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 316,
					columnNumber: 11
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 314,
				columnNumber: 9
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				className: "panel",
				onSubmit: handleLogin,
				children: [
					/* @__PURE__ */ _jsxDEV("h2", { children: "Sign In" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 323,
						columnNumber: 11
					}, this),
					error && /* @__PURE__ */ _jsxDEV("p", {
						className: "error",
						role: "alert",
						children: error
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 326,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "email",
						children: "Email"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 331,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "email",
						type: "email",
						required: true,
						value: email,
						onChange: (e) => setEmail(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 332,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "password",
						children: "Password"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 340,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "password",
						type: "password",
						required: true,
						value: password,
						onChange: (e) => setPassword(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 341,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "submit",
						disabled: loading,
						children: loading ? "Signing in..." : "Sign In"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 349,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 319,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 313,
			columnNumber: 7
		}, this);
	}
	async function openAssignmentFromDashboard(courseId) {
		setPage("courses");
		await selectCourse(courseId);
		setCourseSection("assignments");
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "lms-shell",
		children: [/* @__PURE__ */ _jsxDEV(Sidebar, {
			page,
			role: account.role,
			onNavigate: (nextPage) => {
				setPage(nextPage);
				setError("");
			}
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 363,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("main", {
			className: "lms-main",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "lms-topbar",
					children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h1", { children: "University LMS" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 375,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Learning Management Dashboard" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 376,
						columnNumber: 13
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 374,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("div", {
						className: "lms-topbar-actions",
						children: [/* @__PURE__ */ _jsxDEV(NotificationCenter, {
							token,
							onOpenAssignment: (courseId) => {
								setPage("courses");
								void selectCourse(courseId).then(() => {
									setCourseSection("assignments");
								});
							}
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 380,
							columnNumber: 3
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							onClick: logout,
							children: "Logout"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 389,
							columnNumber: 3
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 379,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 373,
					columnNumber: 9
				}, this),
				error && /* @__PURE__ */ _jsxDEV("p", {
					className: "error",
					role: "alert",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 394,
					columnNumber: 11
				}, this),
				page === "dashboard" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("section", {
					className: "panel",
					children: [/* @__PURE__ */ _jsxDEV("h2", { children: ["Welcome, ", account.full_name] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 403,
						columnNumber: 7
					}, this), /* @__PURE__ */ _jsxDEV("p", { children: [
						"You are logged in as a",
						" ",
						/* @__PURE__ */ _jsxDEV("strong", { children: account.role }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 406,
							columnNumber: 9
						}, this),
						"."
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 404,
						columnNumber: 7
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 402,
					columnNumber: 5
				}, this), account.role.toLowerCase() === "admin" ? /* @__PURE__ */ _jsxDEV("section", {
					className: "panel",
					children: [
						/* @__PURE__ */ _jsxDEV("h2", { children: "Administration" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 412,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("p", { children: [courses.length, " courses available to manage."] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 413,
							columnNumber: 9
						}, this),
						/* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							onClick: () => setPage("courses"),
							children: "Manage courses"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 414,
							columnNumber: 9
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 411,
					columnNumber: 7
				}, this) : /* @__PURE__ */ _jsxDEV(RoleDashboard, {
					role: account.role,
					token,
					courses,
					onOpenAssignment: (courseId) => {
						void openAssignmentFromDashboard(courseId);
					}
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 422,
					columnNumber: 7
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 401,
					columnNumber: 3
				}, this),
				page === "courses" && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
					/* @__PURE__ */ _jsxDEV("section", {
						className: "panel",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", { children: "Courses" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 438,
								columnNumber: 15
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "course-grid",
								children: courses.map((course) => /* @__PURE__ */ _jsxDEV("article", {
									className: "course-card",
									children: [
										/* @__PURE__ */ _jsxDEV("h3", { children: course.title }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 446,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("p", { children: course.course_code }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 447,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("p", { children: course.description || "No description available." }, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 448,
											columnNumber: 21
										}, this),
										/* @__PURE__ */ _jsxDEV("button", {
											disabled: loading,
											onClick: () => selectCourse(course.id),
											children: "Open Course"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 453,
											columnNumber: 21
										}, this)
									]
								}, course.id, true, {
									fileName: _jsxFileName,
									lineNumber: 442,
									columnNumber: 19
								}, this))
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 440,
								columnNumber: 15
							}, this),
							courses.length === 0 && /* @__PURE__ */ _jsxDEV("p", { children: "No courses available." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 464,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 437,
						columnNumber: 13
					}, this),
					selectedCourseId !== null && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("section", {
						className: "panel",
						children: [/* @__PURE__ */ _jsxDEV("h2", { children: courses.find((course) => course.id === selectedCourseId)?.title || "Selected Course" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 473,
							columnNumber: 7
						}, this), /* @__PURE__ */ _jsxDEV(CourseSubNav, {
							activeSection: courseSection,
							onChange: setCourseSection
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 479,
							columnNumber: 7
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 472,
						columnNumber: 5
					}, this), courseSection === "overview" && /* @__PURE__ */ _jsxDEV("section", {
						className: "panel",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", { children: "Course Overview" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 488,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: courses.find((course) => course.id === selectedCourseId)?.description || "Welcome to this course." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 490,
								columnNumber: 9
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: "Select Course Materials, Assignments, or Meetings from the navigation above." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 497,
								columnNumber: 9
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 487,
						columnNumber: 7
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 471,
						columnNumber: 3
					}, this),
					selectedCourseId !== null && courseSection === "meetings" && canManageMeetings && /* @__PURE__ */ _jsxDEV(ScheduleMeetingForm, {
						courseId: selectedCourseId,
						token,
						onCreated: () => selectCourse(selectedCourseId)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 509,
						columnNumber: 3
					}, this),
					selectedCourseId !== null && courseSection === "materials" && /* @__PURE__ */ _jsxDEV(CourseMaterials, {
						courseId: selectedCourseId,
						token
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 519,
						columnNumber: 5
					}, this),
					selectedCourseId !== null && courseSection === "assignments" && /* @__PURE__ */ _jsxDEV(CourseAssignments, {
						courseId: selectedCourseId,
						token,
						role: account.role
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 528,
						columnNumber: 5
					}, this),
					selectedCourseId !== null && courseSection === "meetings" && /* @__PURE__ */ _jsxDEV("section", {
						className: "panel",
						children: [
							/* @__PURE__ */ _jsxDEV("h2", { children: "Scheduled Meetings" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 538,
								columnNumber: 17
							}, this),
							loading && /* @__PURE__ */ _jsxDEV("p", { children: "Loading meetings..." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 540,
								columnNumber: 29
							}, this),
							!loading && meetings.length === 0 && /* @__PURE__ */ _jsxDEV("p", { children: "No meetings to display." }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 543,
								columnNumber: 19
							}, this),
							meetings.map((meeting) => /* @__PURE__ */ _jsxDEV("article", {
								className: "meeting-card",
								children: [
									/* @__PURE__ */ _jsxDEV("h3", { children: meeting.title }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 552,
										columnNumber: 5
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: meeting.description || "Online class" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 554,
										columnNumber: 5
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: ["Starts: ", formatDate(meeting.starts_at)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 558,
										columnNumber: 5
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: ["Ends: ", formatDate(meeting.ends_at)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 562,
										columnNumber: 5
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: ["Status: ", /* @__PURE__ */ _jsxDEV("strong", { children: meeting.status }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 567,
										columnNumber: 15
									}, this)] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 566,
										columnNumber: 5
									}, this),
									meeting.status === "scheduled" && /* @__PURE__ */ _jsxDEV("div", {
										className: "meeting-actions",
										children: [
											canManageMeetings && /* @__PURE__ */ _jsxDEV("button", {
												disabled: loading,
												onClick: () => openMeeting(meeting, true),
												children: "Create / Open Room"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 573,
												columnNumber: 11
											}, this),
											/* @__PURE__ */ _jsxDEV("button", {
												disabled: loading,
												onClick: () => openMeeting(meeting, false),
												children: "Join Class"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 581,
												columnNumber: 9
											}, this),
											canManageMeetings && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("button", {
												className: "btn-secondary",
												disabled: loading,
												onClick: () => setEditingMeetingId(editingMeetingId === meeting.id ? null : meeting.id),
												children: "Edit Meeting"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 590,
												columnNumber: 13
											}, this), /* @__PURE__ */ _jsxDEV("button", {
												className: "btn-danger",
												disabled: loading,
												onClick: () => cancelMeeting(meeting),
												children: "Cancel Class"
											}, void 0, false, {
												fileName: _jsxFileName,
												lineNumber: 604,
												columnNumber: 13
											}, this)] }, void 0, true, {
												fileName: _jsxFileName,
												lineNumber: 589,
												columnNumber: 11
											}, this)
										]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 571,
										columnNumber: 7
									}, this),
									canManageMeetings && meeting.status === "scheduled" && editingMeetingId === meeting.id && /* @__PURE__ */ _jsxDEV(EditMeetingForm, {
										meeting,
										token,
										onCancel: () => setEditingMeetingId(null),
										onUpdated: async () => {
											setEditingMeetingId(null);
											await selectCourse(meeting.course_id);
										}
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 619,
										columnNumber: 9
									}, this),
									canManageMeetings && meeting.status !== "cancelled" && /* @__PURE__ */ _jsxDEV("div", {
										className: "meeting-actions",
										children: /* @__PURE__ */ _jsxDEV("button", {
											type: "button",
											className: "btn-secondary",
											onClick: () => setAttendanceMeetingId(attendanceMeetingId === meeting.id ? null : meeting.id),
											children: attendanceMeetingId === meeting.id ? "Close Attendance" : "Manage Attendance"
										}, void 0, false, {
											fileName: _jsxFileName,
											lineNumber: 634,
											columnNumber: 5
										}, this)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 633,
										columnNumber: 3
									}, this),
									canManageMeetings && meeting.status !== "cancelled" && attendanceMeetingId === meeting.id && /* @__PURE__ */ _jsxDEV(AttendanceManager, {
										meetingId: meeting.id,
										token,
										onClose: () => setAttendanceMeetingId(null)
									}, meeting.id, false, {
										fileName: _jsxFileName,
										lineNumber: 655,
										columnNumber: 5
									}, this),
									canManageMeetings && /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "btn-secondary",
										onClick: () => setAutoReportMeetingId(autoReportMeetingId === meeting.id ? null : meeting.id),
										children: autoReportMeetingId === meeting.id ? "Hide Automatic Report" : "Automatic Attendance Report"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 668,
										columnNumber: 3
									}, this),
									canManageMeetings && autoReportMeetingId === meeting.id && /* @__PURE__ */ _jsxDEV(AutomaticAttendanceReport, {
										meetingId: meeting.id,
										token
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 687,
										columnNumber: 5
									}, this)
								]
							}, meeting.id, true, {
								fileName: _jsxFileName,
								lineNumber: 548,
								columnNumber: 3
							}, this))
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 537,
						columnNumber: 3
					}, this)
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 436,
					columnNumber: 11
				}, this),
				page === "classroom" && /* @__PURE__ */ _jsxDEV("section", {
					className: "panel classroom",
					children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Live Classroom" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 703,
						columnNumber: 13
					}, this), roomName ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setRoomName(""),
						children: "Close Classroom"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 707,
						columnNumber: 17
					}, this), activeMeetingId !== null && /* @__PURE__ */ _jsxDEV(TrackedClassroom, {
						meetingId: activeMeetingId,
						roomName,
						token,
						role: account.role,
						displayName: account.full_name,
						onClose: () => {
							setRoomName("");
							setActiveMeetingId(null);
						}
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 714,
						columnNumber: 3
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 706,
						columnNumber: 15
					}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV("p", { children: "No classroom is open. Select a course and join a scheduled meeting to get started." }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 729,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						onClick: () => setPage("courses"),
						children: "Go to Courses"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 735,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 728,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 702,
					columnNumber: 11
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 372,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 362,
		columnNumber: 5
	}, this);
}
_s(App, "1v6a95840bgzerb4cbt1Xw9DcRY=");
_c = App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxnQkFBZ0M7QUFDekMsT0FBTyx5QkFBeUI7QUFDaEMsT0FBTyxxQkFBcUI7QUFDNUIsT0FBTyxzQkFBc0I7QUFDN0IsT0FBTyx1QkFBdUI7QUFDOUIsT0FBTywrQkFBK0I7QUFDdEMsT0FBTyxtQkFBbUI7QUFDMUIsT0FBTyxxQkFBcUI7QUFDNUIsT0FBTyx1QkFBdUI7QUFDOUIsT0FBTyx3QkFBd0I7QUFDL0IsT0FBTyxhQUVBO0FBQ1AsT0FBTyxrQkFFQTs7OztBQW1DUCxlQUFlLFdBQ2IsTUFDQSxVQUF1QixDQUFDLEdBQ3hCLE9BQ1k7Q0FDWixNQUFNLFVBQVUsSUFBSSxRQUFRLFFBQVEsT0FBTztDQUUzQyxJQUFJLE9BQU87RUFDVCxRQUFRLElBQUksaUJBQWlCLFVBQVUsT0FBTztDQUNoRDtDQUVBLE1BQU0sV0FBVyxNQUFNLE1BQU0sTUFBTTtFQUNqQyxHQUFHO0VBQ0g7Q0FDRixDQUFDO0NBRUQsSUFBSSxDQUFDLFNBQVMsSUFBSTtFQUNoQixJQUFJLFVBQVUsbUJBQW1CLFNBQVMsT0FBTztFQUVqRCxJQUFJO0dBQ0YsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLO0dBQ2pDLElBQUksT0FBTyxLQUFLLFdBQVcsVUFBVTtJQUNuQyxVQUFVLEtBQUs7R0FDakI7RUFDRixRQUFRLENBRVI7RUFFQSxNQUFNLElBQUksTUFBTSxPQUFPO0NBQ3pCO0NBRUEsT0FBTyxTQUFTLEtBQUs7QUFDdkI7QUFFQSxTQUFTLGFBQWEsWUFBNEI7Q0FDaEQsTUFBTSxNQUFNLElBQUksSUFBSSxVQUFVO0NBQzlCLE1BQU0sV0FBVyxJQUFJLFNBQVMsTUFBTSxDQUFDO0NBRXJDLElBQ0UsSUFBSSxhQUFhLFlBQ2pCLElBQUksYUFBYSxpQkFDakIsQ0FBQyxtQkFBbUIsS0FBSyxRQUFRLEdBQ2pDO0VBQ0EsTUFBTSxJQUFJLE1BQU0sNEJBQTRCO0NBQzlDO0NBRUEsT0FBTztBQUNUO0FBRUEsU0FBUyxXQUFXLE9BQXVCO0NBQ3pDLE9BQU8sSUFBSSxLQUFLLEtBQUssQ0FBQyxDQUFDLGVBQWU7QUFDeEM7QUFFQSxlQUFlLFNBQVMsTUFBTTs7Q0FDNUIsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLGtCQUFrQix1QkFBdUIsU0FBd0IsSUFBSTtDQUM1RSxNQUFNLENBQUMscUJBQXFCLDBCQUM1QixTQUF3QixJQUFJO0NBQzVCLE1BQU0sQ0FBQyxTQUFTLGNBQ2QsU0FBeUIsSUFBSTtDQUMvQixNQUFNLENBQUMsaUJBQWlCLHNCQUN4QixTQUF3QixJQUFJO0NBQzVCLE1BQU0sQ0FBQyxNQUFNLFdBQ1gsU0FBd0IsV0FBVztDQUNyQyxNQUFNLENBQUMscUJBQXFCLDBCQUM1QixTQUF3QixJQUFJO0NBQzVCLE1BQU0sQ0FBQyxTQUFTLGNBQWMsU0FBbUIsQ0FBQyxDQUFDO0NBQ25ELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBb0IsQ0FBQyxDQUFDO0NBSXRELE1BQU0sQ0FBQyxrQkFBa0IsdUJBQ3ZCLFNBQXdCLElBQUk7Q0FFOUIsTUFBTSxDQUFDLGVBQWUsb0JBQ3RCLFNBQXdCLFVBQVU7Q0FFbEMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7Q0FFNUMsTUFBTSxvQkFDSixTQUFTLEtBQUssWUFBWSxNQUFNLGVBQ2hDLFNBQVMsS0FBSyxZQUFZLE1BQU07Q0FFbEMsZUFBZSxZQUNiLE9BQ0E7RUFDQSxNQUFNLGVBQWU7RUFDckIsU0FBUyxFQUFFO0VBQ1gsV0FBVyxJQUFJO0VBRWYsSUFBSTtHQUNGLE1BQU0sY0FBYyxJQUFJLGdCQUFnQjtJQUN0QyxVQUFVO0lBQ1Y7R0FDRixDQUFDO0dBRUQsTUFBTSxRQUFRLE1BQU0sV0FDbEIsbUJBQ0E7SUFDRSxRQUFRO0lBQ1IsU0FBUyxFQUNQLGdCQUNFLG9DQUNKO0lBQ0EsTUFBTTtHQUNSLENBQ0Y7R0FFQSxNQUFNLE9BQU8sTUFBTSxXQUNqQixnQkFDQSxDQUFDLEdBQ0QsTUFBTSxZQUNSO0dBRUEsTUFBTSxhQUFhLE1BQU0sV0FDdkIsaUJBQ0EsQ0FBQyxHQUNELE1BQU0sWUFDUjtHQUVBLFNBQVMsTUFBTSxZQUFZO0dBQzNCLFdBQVcsSUFBSTtHQUNmLFdBQVcsVUFBVTtHQUNyQixZQUFZLEVBQUU7R0FDZCxRQUFRLFdBQVc7RUFDckIsU0FBUyxLQUFLO0dBQ1osU0FDRSxlQUFlLFFBQVEsSUFBSSxVQUFVLGVBQ3ZDO0VBQ0YsVUFBVTtHQUNSLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUEsZUFBZSxhQUFhLFVBQWtCO0VBQzVDLG9CQUFvQixRQUFRO0VBQzVCLFlBQVksQ0FBQyxDQUFDO0VBQ2QsWUFBWSxFQUFFO0VBQ2QsU0FBUyxFQUFFO0VBQ1gsV0FBVyxJQUFJO0VBQ2Ysb0JBQW9CLElBQUk7RUFDeEIsdUJBQXVCLElBQUk7RUFDM0IsbUJBQW1CLElBQUk7RUFDdkIsdUJBQXVCLElBQUk7RUFDM0IsaUJBQWlCLFVBQVU7RUFDM0IsSUFBSTtHQUNGLE1BQU0sU0FBUyxNQUFNLFdBQ25CLHlCQUF5QixZQUN6QixDQUFDLEdBQ0QsS0FDRjtHQUVBLFlBQ0UsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLE1BQ1QsR0FBRyxNQUNGLElBQUksS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDLFFBQVEsSUFDOUIsSUFBSSxLQUFLLEVBQUUsU0FBUyxDQUFDLENBQUMsUUFBUSxDQUNsQyxDQUNGO0VBQ0YsU0FBUyxLQUFLO0dBQ1osU0FDRSxlQUFlLFFBQ1gsSUFBSSxVQUNKLDBCQUNOO0VBQ0YsVUFBVTtHQUNSLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUEsZUFBZSxZQUNiLFNBQ0EsUUFDQTtFQUNBLFNBQVMsRUFBRTtFQUNYLFdBQVcsSUFBSTtFQUVmLElBQUk7R0FDRixNQUFNLFNBQVMsU0FBUyxTQUFTO0dBRWpDLE1BQU0sU0FBUyxNQUFNLFdBQ25CLGlCQUFpQixRQUFRLEdBQUcsR0FBRyxVQUMvQixFQUNFLFFBQVEsU0FBUyxTQUFTLE1BQzVCLEdBQ0EsS0FDRjtHQUVBLE1BQU0sT0FBTyxhQUFhLE9BQU8sV0FBVztHQUU1QyxtQkFBbUIsUUFBUSxFQUFFO0dBQzdCLFlBQVksSUFBSTtHQUNoQixRQUFRLFdBQVc7RUFDckIsU0FBUyxLQUFLO0dBQ1osU0FDRSxlQUFlLFFBQ1gsSUFBSSxVQUNKLDJCQUNOO0VBQ0YsVUFBVTtHQUNSLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUYsZUFBZSxjQUFjLFNBQWtCO0VBQzdDLE1BQU0sWUFBWSxPQUFPLFFBQ3ZCLG9DQUFvQyxRQUFRLE1BQU0sR0FDcEQ7RUFFQSxJQUFJLENBQUMsV0FBVztHQUNkO0VBQ0Y7RUFFQSxTQUFTLEVBQUU7RUFDWCxXQUFXLElBQUk7RUFFZixJQUFJO0dBQ0YsTUFBTSxXQUNKLGlCQUFpQixRQUFRLE1BQ3pCLEVBQ0UsUUFBUSxTQUNWLEdBQ0EsS0FDRjtHQUVBLG9CQUFvQixJQUFJOztHQUd4QixNQUFNLGFBQWEsUUFBUSxTQUFTO0VBQ3RDLFNBQVMsS0FBSztHQUNaLFNBQ0UsZUFBZSxRQUNYLElBQUksVUFDSiwyQkFDTjtFQUNGLFVBQVU7R0FDUixXQUFXLEtBQUs7RUFDbEI7Q0FDRjtDQUVFLFNBQVMsU0FBUztFQUNoQixTQUFTLEVBQUU7RUFDWCxXQUFXLElBQUk7RUFDZixXQUFXLENBQUMsQ0FBQztFQUNiLFlBQVksQ0FBQyxDQUFDO0VBQ2Qsb0JBQW9CLElBQUk7RUFDeEIsWUFBWSxFQUFFO0VBQ2QsU0FBUyxFQUFFO0VBQ1gsWUFBWSxFQUFFO0VBQ2QsdUJBQXVCLElBQUk7RUFDM0IsUUFBUSxXQUFXO0VBQ25CLG1CQUFtQixJQUFJO0VBQ3ZCLHVCQUF1QixJQUFJO0NBQzdCO0NBRUEsSUFBSSxDQUFDLFNBQVM7RUFDWixPQUNFLHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQWhCLENBQ0Usd0JBQUMsVUFBRDtJQUFRLFdBQVU7Y0FBbEIsQ0FDRSx3QkFBQyxNQUFELFlBQUksaUJBQWtCOzs7O2NBQ3RCLHdCQUFDLEtBQUQsWUFBRyw2QkFBNkI7Ozs7WUFDMUI7Ozs7O2FBRVIsd0JBQUMsUUFBRDtJQUNFLFdBQVU7SUFDVixVQUFVO2NBRlo7S0FJRSx3QkFBQyxNQUFELFlBQUksVUFBVzs7Ozs7S0FFZCxTQUNDLHdCQUFDLEtBQUQ7TUFBRyxXQUFVO01BQVEsTUFBSztnQkFDdkI7S0FDQTs7Ozs7S0FHTCx3QkFBQyxTQUFEO01BQU8sU0FBUTtnQkFBUTtLQUFZOzs7OztLQUNuQyx3QkFBQyxTQUFEO01BQ0UsSUFBRztNQUNILE1BQUs7TUFDTDtNQUNBLE9BQU87TUFDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztLQUN6Qzs7Ozs7S0FFRCx3QkFBQyxTQUFEO01BQU8sU0FBUTtnQkFBVztLQUFlOzs7OztLQUN6Qyx3QkFBQyxTQUFEO01BQ0UsSUFBRztNQUNILE1BQUs7TUFDTDtNQUNBLE9BQU87TUFDUCxXQUFXLE1BQU0sWUFBWSxFQUFFLE9BQU8sS0FBSztLQUM1Qzs7Ozs7S0FFRCx3QkFBQyxVQUFEO01BQVEsTUFBSztNQUFTLFVBQVU7Z0JBQzdCLFVBQVUsa0JBQWtCO0tBQ3ZCOzs7OztJQUNKOzs7OztXQUNGOzs7Ozs7Q0FFVjtDQUNGLGVBQWUsNEJBQTRCLFVBQWtCO0VBQzNELFFBQVEsU0FBUztFQUNqQixNQUFNLGFBQWEsUUFBUTtFQUMzQixpQkFBaUIsYUFBYTtDQUNoQztDQUNFLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLFNBQUQ7R0FDUTtHQUNOLE1BQU0sUUFBUTtHQUNkLGFBQWEsYUFBYTtJQUN4QixRQUFRLFFBQVE7SUFDaEIsU0FBUyxFQUFFO0dBQ2I7RUFDRDs7OztZQUVELHdCQUFDLFFBQUQ7R0FBTSxXQUFVO2FBQWhCO0lBQ0Usd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksaUJBQWtCOzs7O2VBQ3RCLHdCQUFDLEtBQUQsWUFBRyxnQ0FBZ0M7Ozs7YUFDaEM7Ozs7ZUFFTCx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNSLHdCQUFDLG9CQUFEO09BQ1M7T0FDUCxtQkFBbUIsYUFBYTtRQUM5QixRQUFRLFNBQVM7UUFDakIsS0FBSyxhQUFhLFFBQVEsQ0FBQyxDQUFDLFdBQVc7U0FDckMsaUJBQWlCLGFBQWE7UUFDaEMsQ0FBQztPQUNIO01BQ0Q7Ozs7Z0JBQ0Qsd0JBQUMsVUFBRDtPQUFRLFNBQVM7aUJBQVE7TUFBYzs7OztjQUNwQzs7Ozs7YUFDUTs7Ozs7O0lBRUosU0FDQyx3QkFBQyxLQUFEO0tBQUcsV0FBVTtLQUFRLE1BQUs7ZUFDdkI7SUFDQTs7Ozs7SUFJWixTQUFTLGVBQ1IsZ0RBQ0Usd0JBQUMsV0FBRDtLQUFTLFdBQVU7ZUFBbkIsQ0FDRSx3QkFBQyxNQUFELGFBQUksYUFBVSxRQUFRLFNBQWM7Ozs7ZUFDcEMsd0JBQUMsS0FBRDtNQUFHO01BQ3NCO01BQ3ZCLHdCQUFDLFVBQUQsWUFBUyxRQUFRLEtBQWE7Ozs7O01BQUM7S0FDOUI7Ozs7YUFDSTs7Ozs7Y0FFUixRQUFRLEtBQUssWUFBWSxNQUFNLFVBQzlCLHdCQUFDLFdBQUQ7S0FBUyxXQUFVO2VBQW5CO01BQ0Usd0JBQUMsTUFBRCxZQUFJLGlCQUFrQjs7Ozs7TUFDdEIsd0JBQUMsS0FBRCxhQUFJLFFBQVEsUUFBTywrQkFBZ0M7Ozs7O01BQ25ELHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsZUFBZSxRQUFRLFNBQVM7aUJBQ2pDO01BRU87Ozs7O0tBQ0Q7Ozs7O2VBRVQsd0JBQUMsZUFBRDtLQUNFLE1BQU0sUUFBUTtLQUNQO0tBQ0U7S0FDVCxtQkFBbUIsYUFBYTtNQUM5QixLQUFLLDRCQUE0QixRQUFRO0tBQzNDO0lBQ0Q7Ozs7WUFFSDs7Ozs7SUFJSyxTQUFTLGFBQ1I7S0FDRSx3QkFBQyxXQUFEO01BQVMsV0FBVTtnQkFBbkI7T0FDRSx3QkFBQyxNQUFELFlBQUksVUFBVzs7Ozs7T0FFZix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFDWixRQUFRLEtBQUssV0FDWix3QkFBQyxXQUFEO1NBQ0UsV0FBVTttQkFEWjtVQUlFLHdCQUFDLE1BQUQsWUFBSyxPQUFPLE1BQVU7Ozs7O1VBQ3RCLHdCQUFDLEtBQUQsWUFBSSxPQUFPLFlBQWU7Ozs7O1VBQzFCLHdCQUFDLEtBQUQsWUFDRyxPQUFPLGVBQ04sNEJBQ0Q7Ozs7O1VBRUgsd0JBQUMsVUFBRDtXQUNsQixVQUFVO1dBQ1YsZUFBZSxhQUFhLE9BQU8sRUFBRTtxQkFDdEM7VUFFTzs7Ozs7U0FDbUI7V0FmRixPQUFPOzs7O2VBZUwsQ0FDVjtPQUNFOzs7OztPQUVKLFFBQVEsV0FBVyxLQUNsQix3QkFBQyxLQUFELFlBQUcsd0JBQXdCOzs7OztNQUV0Qjs7Ozs7O0tBSXBCLHFCQUFxQixRQUNwQixnREFDRSx3QkFBQyxXQUFEO01BQVMsV0FBVTtnQkFBbkIsQ0FDRSx3QkFBQyxNQUFELFlBQ0csUUFBUSxNQUNOLFdBQVcsT0FBTyxPQUFPLGdCQUM1QixDQUFDLEVBQUUsU0FBUyxrQkFDVjs7OztnQkFFSix3QkFBQyxjQUFEO09BQ0UsZUFBZTtPQUNmLFVBQVU7TUFDWDs7OztjQUNNOzs7OztlQUdSLGtCQUFrQixjQUNqQix3QkFBQyxXQUFEO01BQVMsV0FBVTtnQkFBbkI7T0FDRSx3QkFBQyxNQUFELFlBQUksa0JBQW1COzs7OztPQUV2Qix3QkFBQyxLQUFELFlBQ0csUUFBUSxNQUNOLFdBQVcsT0FBTyxPQUFPLGdCQUM1QixDQUFDLEVBQUUsZUFDRCwwQkFDRDs7Ozs7T0FFSCx3QkFBQyxLQUFELFlBQUcsK0VBR0E7Ozs7O01BQ0k7Ozs7O2FBRVg7Ozs7O0tBR0gscUJBQXFCLFFBQ3BCLGtCQUFrQixjQUNsQixxQkFDQSx3QkFBQyxxQkFBRDtNQUNFLFVBQVU7TUFDSDtNQUNQLGlCQUFpQixhQUFhLGdCQUFnQjtLQUMvQzs7Ozs7S0FJRixxQkFBcUIsUUFDcEIsa0JBQWtCLGVBQ2hCLHdCQUFDLGlCQUFEO01BQ0UsVUFBVTtNQUNIO0tBQ1I7Ozs7O0tBSUoscUJBQXFCLFFBQ3BCLGtCQUFrQixpQkFDaEIsd0JBQUMsbUJBQUQ7TUFDRSxVQUFVO01BQ0g7TUFDUCxNQUFNLFFBQVE7S0FDZjs7Ozs7S0FHUSxxQkFBcUIsUUFDaEMsa0JBQWtCLGNBQ2xCLHdCQUFDLFdBQUQ7TUFBUyxXQUFVO2dCQUFuQjtPQUNjLHdCQUFDLE1BQUQsWUFBSSxxQkFBc0I7Ozs7O09BRXpCLFdBQVcsd0JBQUMsS0FBRCxZQUFHLHNCQUFzQjs7Ozs7T0FFcEMsQ0FBQyxXQUFXLFNBQVMsV0FBVyxLQUMvQix3QkFBQyxLQUFELFlBQUcsMEJBQTBCOzs7OztPQUk5QyxTQUFTLEtBQUssWUFDYix3QkFBQyxXQUFEO1FBQ0UsV0FBVTtrQkFEWjtTQUlFLHdCQUFDLE1BQUQsWUFBSyxRQUFRLE1BQVU7Ozs7O1NBRXZCLHdCQUFDLEtBQUQsWUFDRyxRQUFRLGVBQWUsZUFDdkI7Ozs7O1NBRUgsd0JBQUMsS0FBRCxhQUFHLFlBQ1EsV0FBVyxRQUFRLFNBQVMsQ0FDcEM7Ozs7O1NBRUgsd0JBQUMsS0FBRCxhQUFHLFVBQ00sV0FBVyxRQUFRLE9BQU8sQ0FDaEM7Ozs7O1NBRUgsd0JBQUMsS0FBRCxhQUFHLFlBQ08sd0JBQUMsVUFBRCxZQUFTLFFBQVEsT0FBZTs7OztpQkFDdkM7Ozs7O1NBRUYsUUFBUSxXQUFXLGVBQ2xCLHdCQUFDLE9BQUQ7VUFBSyxXQUFVO29CQUFmO1dBQ0cscUJBQ0Msd0JBQUMsVUFBRDtZQUNFLFVBQVU7WUFDVixlQUFlLFlBQVksU0FBUyxJQUFJO3NCQUN6QztXQUVPOzs7OztXQUdWLHdCQUFDLFVBQUQ7WUFDRSxVQUFVO1lBQ1YsZUFBZSxZQUFZLFNBQVMsS0FBSztzQkFDMUM7V0FFTzs7Ozs7V0FFUCxxQkFDQyxnREFDRSx3QkFBQyxVQUFEO1lBQ0UsV0FBVTtZQUNWLFVBQVU7WUFDVixlQUNFLG9CQUNFLHFCQUFxQixRQUFRLEtBQ3pCLE9BQ0EsUUFBUSxFQUNkO3NCQUVIO1dBRU87Ozs7cUJBRVIsd0JBQUMsVUFBRDtZQUNFLFdBQVU7WUFDVixVQUFVO1lBQ1YsZUFBZSxjQUFjLE9BQU87c0JBQ3JDO1dBRU87Ozs7bUJBQ1I7Ozs7O1VBRUQ7Ozs7OztTQUdOLHFCQUNDLFFBQVEsV0FBVyxlQUNuQixxQkFBcUIsUUFBUSxNQUMzQix3QkFBQyxpQkFBRDtVQUNXO1VBQ0Y7VUFDUCxnQkFDRSxvQkFBb0IsSUFBSTtVQUUxQixXQUFXLFlBQVk7V0FDckIsb0JBQW9CLElBQUk7V0FDeEIsTUFBTSxhQUFhLFFBQVEsU0FBUztVQUN0QztTQUNEOzs7OztTQUdSLHFCQUFxQixRQUFRLFdBQVcsZUFDdkMsd0JBQUMsT0FBRDtVQUFLLFdBQVU7b0JBQ2Isd0JBQUMsVUFBRDtXQUNFLE1BQUs7V0FDTCxXQUFVO1dBQ1YsZUFDRSx1QkFDRSx3QkFBd0IsUUFBUSxLQUM1QixPQUNBLFFBQVEsRUFDZDtxQkFHRCx3QkFBd0IsUUFBUSxLQUM3QixxQkFDQTtVQUNFOzs7OztTQUNMOzs7OztTQUdOLHFCQUNDLFFBQVEsV0FBVyxlQUNuQix3QkFBd0IsUUFBUSxNQUM5Qix3QkFBQyxtQkFBRDtVQUVFLFdBQVcsUUFBUTtVQUNaO1VBQ1AsZUFDRSx1QkFBdUIsSUFBSTtTQUU5QixHQU5NLFFBQVE7Ozs7Z0JBTWQ7U0FLSixxQkFDQyx3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLFdBQVU7VUFDVixlQUNFLHVCQUNFLHdCQUF3QixRQUFRLEtBQzVCLE9BQ0EsUUFBUSxFQUNkO29CQUdELHdCQUF3QixRQUFRLEtBQzdCLDBCQUNBO1NBQ0U7Ozs7O1NBR1QscUJBQ0Msd0JBQXdCLFFBQVEsTUFDOUIsd0JBQUMsMkJBQUQ7VUFDRSxXQUFXLFFBQVE7VUFDWjtTQUNSOzs7OztRQUdNO1VBL0lGLFFBQVE7Ozs7Y0ErSU4sQ0FDVjtNQUVzQjs7Ozs7O0lBRVg7Ozs7O0lBR0gsU0FBUyxlQUNSLHdCQUFDLFdBQUQ7S0FBUyxXQUFVO2VBQW5CLENBQ0Usd0JBQUMsTUFBRCxZQUFJLGlCQUFrQjs7OztlQUVyQixXQUNDLGdEQUNFLHdCQUFDLFVBQUQ7TUFDRSxlQUFlLFlBQVksRUFBRTtnQkFDOUI7S0FFTzs7OztlQUVQLG9CQUFvQixRQUNuQyx3QkFBQyxrQkFBRDtNQUNFLFdBQVc7TUFDRDtNQUNIO01BQ1AsTUFBTSxRQUFRO01BQ2QsYUFBYSxRQUFRO01BQ3JCLGVBQWU7T0FDYixZQUFZLEVBQUU7T0FDZCxtQkFBbUIsSUFBSTtNQUN6QjtLQUNEOzs7O2FBRWE7Ozs7Z0JBRUYsZ0RBQ0Usd0JBQUMsS0FBRCxZQUFHLHFGQUlBOzs7O2VBRUgsd0JBQUMsVUFBRDtNQUNFLGVBQWUsUUFBUSxTQUFTO2dCQUNqQztLQUVPOzs7O2FBQ1I7Ozs7YUFFRzs7Ozs7O0dBRVA7Ozs7O1VBQ0g7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiXG5pbXBvcnQgeyB1c2VTdGF0ZSwgdHlwZSBGb3JtRXZlbnQgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBTY2hlZHVsZU1lZXRpbmdGb3JtIGZyb20gJy4vY29tcG9uZW50cy9TY2hlZHVsZU1lZXRpbmdGb3JtJ1xuaW1wb3J0IEVkaXRNZWV0aW5nRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvRWRpdE1lZXRpbmdGb3JtJ1xuaW1wb3J0IFRyYWNrZWRDbGFzc3Jvb20gZnJvbSAnLi9jb21wb25lbnRzL1RyYWNrZWRDbGFzc3Jvb20nXG5pbXBvcnQgQXR0ZW5kYW5jZU1hbmFnZXIgZnJvbSAnLi9jb21wb25lbnRzL0F0dGVuZGFuY2VNYW5hZ2VyJ1xuaW1wb3J0IEF1dG9tYXRpY0F0dGVuZGFuY2VSZXBvcnQgZnJvbSAnLi9jb21wb25lbnRzL0F1dG9tYXRpY0F0dGVuZGFuY2VSZXBvcnQnXG5pbXBvcnQgUm9sZURhc2hib2FyZCBmcm9tICcuL2NvbXBvbmVudHMvUm9sZURhc2hib2FyZCdcbmltcG9ydCBDb3Vyc2VNYXRlcmlhbHMgZnJvbSAnLi9jb21wb25lbnRzL0NvdXJzZU1hdGVyaWFscydcbmltcG9ydCBDb3Vyc2VBc3NpZ25tZW50cyBmcm9tICcuL2NvbXBvbmVudHMvQ291cnNlQXNzaWdubWVudHMnXG5pbXBvcnQgTm90aWZpY2F0aW9uQ2VudGVyIGZyb20gJy4vY29tcG9uZW50cy9Ob3RpZmljYXRpb25DZW50ZXInXG5pbXBvcnQgU2lkZWJhciwge1xuICB0eXBlIERhc2hib2FyZFBhZ2UsXG59IGZyb20gJy4vY29tcG9uZW50cy9TaWRlYmFyJ1xuaW1wb3J0IENvdXJzZVN1Yk5hdiwge1xuICB0eXBlIENvdXJzZVNlY3Rpb24sXG59IGZyb20gJy4vY29tcG9uZW50cy9Db3Vyc2VTdWJOYXYnXG50eXBlIEFjY291bnQgPSB7XG4gIGZ1bGxfbmFtZTogc3RyaW5nXG4gIHJvbGU6IHN0cmluZ1xufVxuXG50eXBlIExvZ2luUmVzcG9uc2UgPSB7XG4gIGFjY2Vzc190b2tlbjogc3RyaW5nXG4gIHRva2VuX3R5cGU6IHN0cmluZ1xufVxuXG50eXBlIENvdXJzZSA9IHtcbiAgaWQ6IG51bWJlclxuICB0aXRsZTogc3RyaW5nXG4gIGNvdXJzZV9jb2RlOiBzdHJpbmdcbiAgZGVzY3JpcHRpb246IHN0cmluZyB8IG51bGxcbn1cblxudHlwZSBNZWV0aW5nID0ge1xuICBpZDogbnVtYmVyXG4gIGNvdXJzZV9pZDogbnVtYmVyXG4gIHRpdGxlOiBzdHJpbmdcbiAgZGVzY3JpcHRpb246IHN0cmluZyB8IG51bGxcbiAgc3RhcnRzX2F0OiBzdHJpbmdcbiAgZW5kc19hdDogc3RyaW5nXG4gIHN0YXR1czogc3RyaW5nXG4gIG1lZXRpbmdfdXJsOiBzdHJpbmcgfCBudWxsXG59XG5cbnR5cGUgTWVldGluZ0xpbmsgPSB7XG4gIGlkOiBudW1iZXJcbiAgbWVldGluZ191cmw6IHN0cmluZ1xuICBzdGF0dXM6IHN0cmluZ1xufVxuXG5hc3luYyBmdW5jdGlvbiBhcGlSZXF1ZXN0PFQ+KFxuICBwYXRoOiBzdHJpbmcsXG4gIG9wdGlvbnM6IFJlcXVlc3RJbml0ID0ge30sXG4gIHRva2VuPzogc3RyaW5nXG4pOiBQcm9taXNlPFQ+IHtcbiAgY29uc3QgaGVhZGVycyA9IG5ldyBIZWFkZXJzKG9wdGlvbnMuaGVhZGVycylcblxuICBpZiAodG9rZW4pIHtcbiAgICBoZWFkZXJzLnNldCgnQXV0aG9yaXphdGlvbicsIGBCZWFyZXIgJHt0b2tlbn1gKVxuICB9XG5cbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChwYXRoLCB7XG4gICAgLi4ub3B0aW9ucyxcbiAgICBoZWFkZXJzLFxuICB9KVxuXG4gIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICBsZXQgbWVzc2FnZSA9IGBSZXF1ZXN0IGZhaWxlZCAoJHtyZXNwb25zZS5zdGF0dXN9KWBcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBib2R5ID0gYXdhaXQgcmVzcG9uc2UuanNvbigpXG4gICAgICBpZiAodHlwZW9mIGJvZHkuZGV0YWlsID09PSAnc3RyaW5nJykge1xuICAgICAgICBtZXNzYWdlID0gYm9keS5kZXRhaWxcbiAgICAgIH1cbiAgICB9IGNhdGNoIHtcbiAgICAgIC8vIEtlZXAgdGhlIEhUVFAgc3RhdHVzIG1lc3NhZ2UuXG4gICAgfVxuXG4gICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpXG4gIH1cblxuICByZXR1cm4gcmVzcG9uc2UuanNvbigpXG59XG5cbmZ1bmN0aW9uIGdldEppdHNpUm9vbShtZWV0aW5nVXJsOiBzdHJpbmcpOiBzdHJpbmcge1xuICBjb25zdCB1cmwgPSBuZXcgVVJMKG1lZXRpbmdVcmwpXG4gIGNvbnN0IHJvb21OYW1lID0gdXJsLnBhdGhuYW1lLnNsaWNlKDEpXG5cbiAgaWYgKFxuICAgIHVybC5wcm90b2NvbCAhPT0gJ2h0dHBzOicgfHxcbiAgICB1cmwuaG9zdG5hbWUgIT09ICdtZWV0LmppdC5zaScgfHxcbiAgICAhL15bYS16QS1aMC05Xy1dKyQvLnRlc3Qocm9vbU5hbWUpXG4gICkge1xuICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCBKaXRzaSBtZWV0aW5nIFVSTC4nKVxuICB9XG5cbiAgcmV0dXJuIHJvb21OYW1lXG59XG5cbmZ1bmN0aW9uIGZvcm1hdERhdGUodmFsdWU6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBuZXcgRGF0ZSh2YWx1ZSkudG9Mb2NhbGVTdHJpbmcoKVxufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBcHAoKSB7XG4gIGNvbnN0IFtlbWFpbCwgc2V0RW1haWxdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFt0b2tlbiwgc2V0VG9rZW5dID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtlZGl0aW5nTWVldGluZ0lkLCBzZXRFZGl0aW5nTWVldGluZ0lkXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpXG4gIGNvbnN0IFthdHRlbmRhbmNlTWVldGluZ0lkLCBzZXRBdHRlbmRhbmNlTWVldGluZ0lkXSA9XG4gIHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpXG4gIGNvbnN0IFthY2NvdW50LCBzZXRBY2NvdW50XSA9XG4gICAgdXNlU3RhdGU8QWNjb3VudCB8IG51bGw+KG51bGwpXG4gIGNvbnN0IFthY3RpdmVNZWV0aW5nSWQsIHNldEFjdGl2ZU1lZXRpbmdJZF0gPVxuICB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKVxuICBjb25zdCBbcGFnZSwgc2V0UGFnZV0gPVxuICAgIHVzZVN0YXRlPERhc2hib2FyZFBhZ2U+KCdkYXNoYm9hcmQnKVxuICBjb25zdCBbYXV0b1JlcG9ydE1lZXRpbmdJZCwgc2V0QXV0b1JlcG9ydE1lZXRpbmdJZF0gPVxuICB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKVxuICBjb25zdCBbY291cnNlcywgc2V0Q291cnNlc10gPSB1c2VTdGF0ZTxDb3Vyc2VbXT4oW10pXG4gIGNvbnN0IFttZWV0aW5ncywgc2V0TWVldGluZ3NdID0gdXNlU3RhdGU8TWVldGluZ1tdPihbXSlcbiAgXG5cblxuICBjb25zdCBbc2VsZWN0ZWRDb3Vyc2VJZCwgc2V0U2VsZWN0ZWRDb3Vyc2VJZF0gPVxuICAgIHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpXG4gIFxuICBjb25zdCBbY291cnNlU2VjdGlvbiwgc2V0Q291cnNlU2VjdGlvbl0gPVxuICB1c2VTdGF0ZTxDb3Vyc2VTZWN0aW9uPignb3ZlcnZpZXcnKSAgXG5cbiAgY29uc3QgW3Jvb21OYW1lLCBzZXRSb29tTmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3QgY2FuTWFuYWdlTWVldGluZ3MgPVxuICAgIGFjY291bnQ/LnJvbGUudG9Mb3dlckNhc2UoKSA9PT0gJ3Byb2Zlc3NvcicgfHxcbiAgICBhY2NvdW50Py5yb2xlLnRvTG93ZXJDYXNlKCkgPT09ICdhZG1pbidcblxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVMb2dpbihcbiAgICBldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD5cbiAgKSB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuICAgIHNldEVycm9yKCcnKVxuICAgIHNldExvYWRpbmcodHJ1ZSlcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBjcmVkZW50aWFscyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoe1xuICAgICAgICB1c2VybmFtZTogZW1haWwsXG4gICAgICAgIHBhc3N3b3JkLFxuICAgICAgfSlcblxuICAgICAgY29uc3QgbG9naW4gPSBhd2FpdCBhcGlSZXF1ZXN0PExvZ2luUmVzcG9uc2U+KFxuICAgICAgICAnL2FwaS9hdXRoL2xvZ2luJyxcbiAgICAgICAge1xuICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOlxuICAgICAgICAgICAgICAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkJyxcbiAgICAgICAgICB9LFxuICAgICAgICAgIGJvZHk6IGNyZWRlbnRpYWxzLFxuICAgICAgICB9XG4gICAgICApXG5cbiAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBhcGlSZXF1ZXN0PEFjY291bnQ+KFxuICAgICAgICAnL2FwaS9hdXRoL21lJyxcbiAgICAgICAge30sXG4gICAgICAgIGxvZ2luLmFjY2Vzc190b2tlblxuICAgICAgKVxuXG4gICAgICBjb25zdCBjb3Vyc2VMaXN0ID0gYXdhaXQgYXBpUmVxdWVzdDxDb3Vyc2VbXT4oXG4gICAgICAgICcvYXBpL2NvdXJzZXMvJyxcbiAgICAgICAge30sXG4gICAgICAgIGxvZ2luLmFjY2Vzc190b2tlblxuICAgICAgKVxuXG4gICAgICBzZXRUb2tlbihsb2dpbi5hY2Nlc3NfdG9rZW4pXG4gICAgICBzZXRBY2NvdW50KHVzZXIpXG4gICAgICBzZXRDb3Vyc2VzKGNvdXJzZUxpc3QpXG4gICAgICBzZXRQYXNzd29yZCgnJylcbiAgICAgIHNldFBhZ2UoJ2Rhc2hib2FyZCcpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihcbiAgICAgICAgZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdMb2dpbiBmYWlsZWQuJ1xuICAgICAgKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIHNlbGVjdENvdXJzZShjb3Vyc2VJZDogbnVtYmVyKSB7XG4gICAgc2V0U2VsZWN0ZWRDb3Vyc2VJZChjb3Vyc2VJZClcbiAgICBzZXRNZWV0aW5ncyhbXSlcbiAgICBzZXRSb29tTmFtZSgnJylcbiAgICBzZXRFcnJvcignJylcbiAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgc2V0RWRpdGluZ01lZXRpbmdJZChudWxsKVxuICAgIHNldEF0dGVuZGFuY2VNZWV0aW5nSWQobnVsbClcbiAgICBzZXRBY3RpdmVNZWV0aW5nSWQobnVsbClcbiAgICBzZXRBdXRvUmVwb3J0TWVldGluZ0lkKG51bGwpXG4gICAgc2V0Q291cnNlU2VjdGlvbignb3ZlcnZpZXcnKVxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBhcGlSZXF1ZXN0PE1lZXRpbmdbXT4oXG4gICAgICAgIGAvYXBpL21lZXRpbmdzL2NvdXJzZXMvJHtjb3Vyc2VJZH1gLFxuICAgICAgICB7fSxcbiAgICAgICAgdG9rZW5cbiAgICAgIClcblxuICAgICAgc2V0TWVldGluZ3MoXG4gICAgICAgIFsuLi5yZXN1bHRdLnNvcnQoXG4gICAgICAgICAgKGEsIGIpID0+XG4gICAgICAgICAgICBuZXcgRGF0ZShhLnN0YXJ0c19hdCkuZ2V0VGltZSgpIC1cbiAgICAgICAgICAgIG5ldyBEYXRlKGIuc3RhcnRzX2F0KS5nZXRUaW1lKClcbiAgICAgICAgKVxuICAgICAgKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoXG4gICAgICAgIGVyciBpbnN0YW5jZW9mIEVycm9yXG4gICAgICAgICAgPyBlcnIubWVzc2FnZVxuICAgICAgICAgIDogJ1VuYWJsZSB0byBsb2FkIG1lZXRpbmdzLidcbiAgICAgIClcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSlcbiAgICB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBvcGVuTWVldGluZyhcbiAgICBtZWV0aW5nOiBNZWV0aW5nLFxuICAgIGNyZWF0ZTogYm9vbGVhblxuICApIHtcbiAgICBzZXRFcnJvcignJylcbiAgICBzZXRMb2FkaW5nKHRydWUpXG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgYWN0aW9uID0gY3JlYXRlID8gJ3Jvb20nIDogJ2pvaW4nXG5cbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGFwaVJlcXVlc3Q8TWVldGluZ0xpbms+KFxuICAgICAgICBgL2FwaS9tZWV0aW5ncy8ke21lZXRpbmcuaWR9LyR7YWN0aW9ufWAsXG4gICAgICAgIHtcbiAgICAgICAgICBtZXRob2Q6IGNyZWF0ZSA/ICdQT1NUJyA6ICdHRVQnLFxuICAgICAgICB9LFxuICAgICAgICB0b2tlblxuICAgICAgKVxuXG4gICAgICBjb25zdCByb29tID0gZ2V0Sml0c2lSb29tKHJlc3VsdC5tZWV0aW5nX3VybClcblxuICAgICAgc2V0QWN0aXZlTWVldGluZ0lkKG1lZXRpbmcuaWQpXG4gICAgICBzZXRSb29tTmFtZShyb29tKVxuICAgICAgc2V0UGFnZSgnY2xhc3Nyb29tJylcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKFxuICAgICAgICBlcnIgaW5zdGFuY2VvZiBFcnJvclxuICAgICAgICAgID8gZXJyLm1lc3NhZ2VcbiAgICAgICAgICA6ICdVbmFibGUgdG8gb3BlbiBjbGFzc3Jvb20uJ1xuICAgICAgKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxuICAgIH1cbiAgfVxuICBcbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbE1lZXRpbmcobWVldGluZzogTWVldGluZykge1xuICBjb25zdCBjb25maXJtZWQgPSB3aW5kb3cuY29uZmlybShcbiAgICBgQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGNhbmNlbCBcIiR7bWVldGluZy50aXRsZX1cIj9gXG4gIClcblxuICBpZiAoIWNvbmZpcm1lZCkge1xuICAgIHJldHVyblxuICB9XG5cbiAgc2V0RXJyb3IoJycpXG4gIHNldExvYWRpbmcodHJ1ZSlcblxuICB0cnkge1xuICAgIGF3YWl0IGFwaVJlcXVlc3Q8TWVldGluZz4oXG4gICAgICBgL2FwaS9tZWV0aW5ncy8ke21lZXRpbmcuaWR9YCxcbiAgICAgIHtcbiAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcbiAgICAgIH0sXG4gICAgICB0b2tlblxuICAgIClcblxuICAgIHNldEVkaXRpbmdNZWV0aW5nSWQobnVsbClcblxuICAgIC8vIFJlbG9hZCBtZWV0aW5ncyB0byBzaG93IHRoZSB1cGRhdGVkIHN0YXR1cy5cbiAgICBhd2FpdCBzZWxlY3RDb3Vyc2UobWVldGluZy5jb3Vyc2VfaWQpXG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHNldEVycm9yKFxuICAgICAgZXJyIGluc3RhbmNlb2YgRXJyb3JcbiAgICAgICAgPyBlcnIubWVzc2FnZVxuICAgICAgICA6ICdVbmFibGUgdG8gY2FuY2VsIG1lZXRpbmcuJ1xuICAgIClcbiAgfSBmaW5hbGx5IHtcbiAgICBzZXRMb2FkaW5nKGZhbHNlKVxuICB9XG59XG5cbiAgZnVuY3Rpb24gbG9nb3V0KCkge1xuICAgIHNldFRva2VuKCcnKVxuICAgIHNldEFjY291bnQobnVsbClcbiAgICBzZXRDb3Vyc2VzKFtdKVxuICAgIHNldE1lZXRpbmdzKFtdKVxuICAgIHNldFNlbGVjdGVkQ291cnNlSWQobnVsbClcbiAgICBzZXRSb29tTmFtZSgnJylcbiAgICBzZXRFcnJvcignJylcbiAgICBzZXRQYXNzd29yZCgnJylcbiAgICBzZXRBdHRlbmRhbmNlTWVldGluZ0lkKG51bGwpXG4gICAgc2V0UGFnZSgnZGFzaGJvYXJkJylcbiAgICBzZXRBY3RpdmVNZWV0aW5nSWQobnVsbClcbiAgICBzZXRBdXRvUmVwb3J0TWVldGluZ0lkKG51bGwpXG4gIH1cblxuICBpZiAoIWFjY291bnQpIHtcbiAgICByZXR1cm4gKFxuICAgICAgPG1haW4gY2xhc3NOYW1lPVwiY29udGFpbmVyXCI+XG4gICAgICAgIDxoZWFkZXIgY2xhc3NOYW1lPVwicGFuZWxcIj5cbiAgICAgICAgICA8aDE+VW5pdmVyc2l0eSBMTVM8L2gxPlxuICAgICAgICAgIDxwPkxlYXJuaW5nIE1hbmFnZW1lbnQgU3lzdGVtPC9wPlxuICAgICAgICA8L2hlYWRlcj5cblxuICAgICAgICA8Zm9ybVxuICAgICAgICAgIGNsYXNzTmFtZT1cInBhbmVsXCJcbiAgICAgICAgICBvblN1Ym1pdD17aGFuZGxlTG9naW59XG4gICAgICAgID5cbiAgICAgICAgICA8aDI+U2lnbiBJbjwvaDI+XG5cbiAgICAgICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICAgICAge2Vycm9yfVxuICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICl9XG5cbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImVtYWlsXCI+RW1haWw8L2xhYmVsPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgaWQ9XCJlbWFpbFwiXG4gICAgICAgICAgICB0eXBlPVwiZW1haWxcIlxuICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgIHZhbHVlPXtlbWFpbH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0RW1haWwoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgIC8+XG5cbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkXCI+UGFzc3dvcmQ8L2xhYmVsPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgaWQ9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxuICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAgIHZhbHVlPXtwYXNzd29yZH1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0UGFzc3dvcmQoZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAgIC8+XG5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJzdWJtaXRcIiBkaXNhYmxlZD17bG9hZGluZ30+XG4gICAgICAgICAgICB7bG9hZGluZyA/ICdTaWduaW5nIGluLi4uJyA6ICdTaWduIEluJ31cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgPC9mb3JtPlxuICAgICAgPC9tYWluPlxuICAgIClcbiAgfVxuYXN5bmMgZnVuY3Rpb24gb3BlbkFzc2lnbm1lbnRGcm9tRGFzaGJvYXJkKGNvdXJzZUlkOiBudW1iZXIpIHtcbiAgc2V0UGFnZSgnY291cnNlcycpXG4gIGF3YWl0IHNlbGVjdENvdXJzZShjb3Vyc2VJZClcbiAgc2V0Q291cnNlU2VjdGlvbignYXNzaWdubWVudHMnKVxufVxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibG1zLXNoZWxsXCI+XG4gICAgICA8U2lkZWJhclxuICAgICAgICBwYWdlPXtwYWdlfVxuICAgICAgICByb2xlPXthY2NvdW50LnJvbGV9XG4gICAgICAgIG9uTmF2aWdhdGU9eyhuZXh0UGFnZSkgPT4ge1xuICAgICAgICAgIHNldFBhZ2UobmV4dFBhZ2UpXG4gICAgICAgICAgc2V0RXJyb3IoJycpXG4gICAgICAgIH19XG4gICAgICAvPlxuXG4gICAgICA8bWFpbiBjbGFzc05hbWU9XCJsbXMtbWFpblwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxtcy10b3BiYXJcIj5cbiAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgPGgxPlVuaXZlcnNpdHkgTE1TPC9oMT5cbiAgICAgICAgICAgIDxwPkxlYXJuaW5nIE1hbmFnZW1lbnQgRGFzaGJvYXJkPC9wPlxuICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsbXMtdG9wYmFyLWFjdGlvbnNcIj5cbiAgPE5vdGlmaWNhdGlvbkNlbnRlclxuICAgIHRva2VuPXt0b2tlbn1cbiAgICBvbk9wZW5Bc3NpZ25tZW50PXsoY291cnNlSWQpID0+IHtcbiAgICAgIHNldFBhZ2UoJ2NvdXJzZXMnKVxuICAgICAgdm9pZCBzZWxlY3RDb3Vyc2UoY291cnNlSWQpLnRoZW4oKCkgPT4ge1xuICAgICAgICBzZXRDb3Vyc2VTZWN0aW9uKCdhc3NpZ25tZW50cycpXG4gICAgICB9KVxuICAgIH19XG4gIC8+XG4gIDxidXR0b24gb25DbGljaz17bG9nb3V0fT5Mb2dvdXQ8L2J1dHRvbj5cbjwvZGl2PlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICB7ZXJyb3IgJiYgKFxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImVycm9yXCIgcm9sZT1cImFsZXJ0XCI+XG4gICAgICAgICAgICB7ZXJyb3J9XG4gICAgICAgICAgPC9wPlxuICAgICAgICApfVxuXG4gICAgICAgIFxue3BhZ2UgPT09ICdkYXNoYm9hcmQnICYmIChcbiAgPD5cbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJwYW5lbFwiPlxuICAgICAgPGgyPldlbGNvbWUsIHthY2NvdW50LmZ1bGxfbmFtZX08L2gyPlxuICAgICAgPHA+XG4gICAgICAgIFlvdSBhcmUgbG9nZ2VkIGluIGFzIGF7JyAnfVxuICAgICAgICA8c3Ryb25nPnthY2NvdW50LnJvbGV9PC9zdHJvbmc+LlxuICAgICAgPC9wPlxuICAgIDwvc2VjdGlvbj5cblxuICAgIHthY2NvdW50LnJvbGUudG9Mb3dlckNhc2UoKSA9PT0gJ2FkbWluJyA/IChcbiAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBhbmVsXCI+XG4gICAgICAgIDxoMj5BZG1pbmlzdHJhdGlvbjwvaDI+XG4gICAgICAgIDxwPntjb3Vyc2VzLmxlbmd0aH0gY291cnNlcyBhdmFpbGFibGUgdG8gbWFuYWdlLjwvcD5cbiAgICAgICAgPGJ1dHRvblxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFBhZ2UoJ2NvdXJzZXMnKX1cbiAgICAgICAgPlxuICAgICAgICAgIE1hbmFnZSBjb3Vyc2VzXG4gICAgICAgIDwvYnV0dG9uPlxuICAgICAgPC9zZWN0aW9uPlxuICAgICkgOiAoXG4gICAgICA8Um9sZURhc2hib2FyZFxuICAgICAgICByb2xlPXthY2NvdW50LnJvbGV9XG4gICAgICAgIHRva2VuPXt0b2tlbn1cbiAgICAgICAgY291cnNlcz17Y291cnNlc31cbiAgICAgICAgb25PcGVuQXNzaWdubWVudD17KGNvdXJzZUlkKSA9PiB7XG4gICAgICAgICAgdm9pZCBvcGVuQXNzaWdubWVudEZyb21EYXNoYm9hcmQoY291cnNlSWQpXG4gICAgICAgIH19XG4gICAgICAvPlxuICAgICl9XG4gIDwvPlxuKX1cblxuXG4gICAgICAgIHtwYWdlID09PSAnY291cnNlcycgJiYgKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJwYW5lbFwiPlxuICAgICAgICAgICAgICA8aDI+Q291cnNlczwvaDI+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb3Vyc2UtZ3JpZFwiPlxuICAgICAgICAgICAgICAgIHtjb3Vyc2VzLm1hcCgoY291cnNlKSA9PiAoXG4gICAgICAgICAgICAgICAgICA8YXJ0aWNsZVxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJjb3Vyc2UtY2FyZFwiXG4gICAgICAgICAgICAgICAgICAgIGtleT17Y291cnNlLmlkfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICA8aDM+e2NvdXJzZS50aXRsZX08L2gzPlxuICAgICAgICAgICAgICAgICAgICA8cD57Y291cnNlLmNvdXJzZV9jb2RlfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgICAgICAge2NvdXJzZS5kZXNjcmlwdGlvbiB8fFxuICAgICAgICAgICAgICAgICAgICAgICAgJ05vIGRlc2NyaXB0aW9uIGF2YWlsYWJsZS4nfVxuICAgICAgICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICBkaXNhYmxlZD17bG9hZGluZ31cbiAgb25DbGljaz17KCkgPT4gc2VsZWN0Q291cnNlKGNvdXJzZS5pZCl9XG4+XG4gIE9wZW4gQ291cnNlXG48L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgIDwvYXJ0aWNsZT5cbiAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAge2NvdXJzZXMubGVuZ3RoID09PSAwICYmIChcbiAgICAgICAgICAgICAgICA8cD5ObyBjb3Vyc2VzIGF2YWlsYWJsZS48L3A+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L3NlY3Rpb24+XG5cblxuey8qIENvdXJzZSBTdWItTmF2aWdhdGlvbiAqL31cbntzZWxlY3RlZENvdXJzZUlkICE9PSBudWxsICYmIChcbiAgPD5cbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJwYW5lbFwiPlxuICAgICAgPGgyPlxuICAgICAgICB7Y291cnNlcy5maW5kKFxuICAgICAgICAgIChjb3Vyc2UpID0+IGNvdXJzZS5pZCA9PT0gc2VsZWN0ZWRDb3Vyc2VJZFxuICAgICAgICApPy50aXRsZSB8fCAnU2VsZWN0ZWQgQ291cnNlJ31cbiAgICAgIDwvaDI+XG5cbiAgICAgIDxDb3Vyc2VTdWJOYXZcbiAgICAgICAgYWN0aXZlU2VjdGlvbj17Y291cnNlU2VjdGlvbn1cbiAgICAgICAgb25DaGFuZ2U9e3NldENvdXJzZVNlY3Rpb259XG4gICAgICAvPlxuICAgIDwvc2VjdGlvbj5cblxuICAgIHsvKiBDb3Vyc2UgT3ZlcnZpZXcgKi99XG4gICAge2NvdXJzZVNlY3Rpb24gPT09ICdvdmVydmlldycgJiYgKFxuICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicGFuZWxcIj5cbiAgICAgICAgPGgyPkNvdXJzZSBPdmVydmlldzwvaDI+XG5cbiAgICAgICAgPHA+XG4gICAgICAgICAge2NvdXJzZXMuZmluZChcbiAgICAgICAgICAgIChjb3Vyc2UpID0+IGNvdXJzZS5pZCA9PT0gc2VsZWN0ZWRDb3Vyc2VJZFxuICAgICAgICAgICk/LmRlc2NyaXB0aW9uIHx8XG4gICAgICAgICAgICAnV2VsY29tZSB0byB0aGlzIGNvdXJzZS4nfVxuICAgICAgICA8L3A+XG5cbiAgICAgICAgPHA+XG4gICAgICAgICAgU2VsZWN0IENvdXJzZSBNYXRlcmlhbHMsIEFzc2lnbm1lbnRzLFxuICAgICAgICAgIG9yIE1lZXRpbmdzIGZyb20gdGhlIG5hdmlnYXRpb24gYWJvdmUuXG4gICAgICAgIDwvcD5cbiAgICAgIDwvc2VjdGlvbj5cbiAgICApfVxuICA8Lz5cbil9XG5cbntzZWxlY3RlZENvdXJzZUlkICE9PSBudWxsICYmXG4gIGNvdXJzZVNlY3Rpb24gPT09ICdtZWV0aW5ncycgJiZcbiAgY2FuTWFuYWdlTWVldGluZ3MgJiYgKFxuICA8U2NoZWR1bGVNZWV0aW5nRm9ybVxuICAgIGNvdXJzZUlkPXtzZWxlY3RlZENvdXJzZUlkfVxuICAgIHRva2VuPXt0b2tlbn1cbiAgICBvbkNyZWF0ZWQ9eygpID0+IHNlbGVjdENvdXJzZShzZWxlY3RlZENvdXJzZUlkKX1cbiAgLz5cbil9XG5cbnsvKiBDb3Vyc2UgbGVhcm5pbmcgbWF0ZXJpYWxzICovfVxue3NlbGVjdGVkQ291cnNlSWQgIT09IG51bGwgJiZcbiAgY291cnNlU2VjdGlvbiA9PT0gJ21hdGVyaWFscycgJiYgKFxuICAgIDxDb3Vyc2VNYXRlcmlhbHNcbiAgICAgIGNvdXJzZUlkPXtzZWxlY3RlZENvdXJzZUlkfVxuICAgICAgdG9rZW49e3Rva2VufVxuICAgIC8+XG4gICl9XG5cbnsvKiBORVc6IENvdXJzZSBBc3NpZ25tZW50cyAqL31cbntzZWxlY3RlZENvdXJzZUlkICE9PSBudWxsICYmXG4gIGNvdXJzZVNlY3Rpb24gPT09ICdhc3NpZ25tZW50cycgJiYgKFxuICAgIDxDb3Vyc2VBc3NpZ25tZW50c1xuICAgICAgY291cnNlSWQ9e3NlbGVjdGVkQ291cnNlSWR9XG4gICAgICB0b2tlbj17dG9rZW59XG4gICAgICByb2xlPXthY2NvdW50LnJvbGV9XG4gICAgLz5cbiAgKX1cblxuICAgICAgICAgICAge3NlbGVjdGVkQ291cnNlSWQgIT09IG51bGwgJiZcbiAgY291cnNlU2VjdGlvbiA9PT0gJ21lZXRpbmdzJyAmJiAoXG4gIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBhbmVsXCI+XG4gICAgICAgICAgICAgICAgPGgyPlNjaGVkdWxlZCBNZWV0aW5nczwvaDI+XG5cbiAgICAgICAgICAgICAgICB7bG9hZGluZyAmJiA8cD5Mb2FkaW5nIG1lZXRpbmdzLi4uPC9wPn1cblxuICAgICAgICAgICAgICAgIHshbG9hZGluZyAmJiBtZWV0aW5ncy5sZW5ndGggPT09IDAgJiYgKFxuICAgICAgICAgICAgICAgICAgPHA+Tm8gbWVldGluZ3MgdG8gZGlzcGxheS48L3A+XG4gICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgIFxue21lZXRpbmdzLm1hcCgobWVldGluZykgPT4gKFxuICA8YXJ0aWNsZVxuICAgIGNsYXNzTmFtZT1cIm1lZXRpbmctY2FyZFwiXG4gICAga2V5PXttZWV0aW5nLmlkfVxuICA+XG4gICAgPGgzPnttZWV0aW5nLnRpdGxlfTwvaDM+XG5cbiAgICA8cD5cbiAgICAgIHttZWV0aW5nLmRlc2NyaXB0aW9uIHx8ICdPbmxpbmUgY2xhc3MnfVxuICAgIDwvcD5cblxuICAgIDxwPlxuICAgICAgU3RhcnRzOiB7Zm9ybWF0RGF0ZShtZWV0aW5nLnN0YXJ0c19hdCl9XG4gICAgPC9wPlxuXG4gICAgPHA+XG4gICAgICBFbmRzOiB7Zm9ybWF0RGF0ZShtZWV0aW5nLmVuZHNfYXQpfVxuICAgIDwvcD5cblxuICAgIDxwPlxuICAgICAgU3RhdHVzOiA8c3Ryb25nPnttZWV0aW5nLnN0YXR1c308L3N0cm9uZz5cbiAgICA8L3A+XG5cbiAgICB7bWVldGluZy5zdGF0dXMgPT09ICdzY2hlZHVsZWQnICYmIChcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWVldGluZy1hY3Rpb25zXCI+XG4gICAgICAgIHtjYW5NYW5hZ2VNZWV0aW5ncyAmJiAoXG4gICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvcGVuTWVldGluZyhtZWV0aW5nLCB0cnVlKX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICBDcmVhdGUgLyBPcGVuIFJvb21cbiAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgKX1cblxuICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XG4gICAgICAgICAgb25DbGljaz17KCkgPT4gb3Blbk1lZXRpbmcobWVldGluZywgZmFsc2UpfVxuICAgICAgICA+XG4gICAgICAgICAgSm9pbiBDbGFzc1xuICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICB7Y2FuTWFuYWdlTWVldGluZ3MgJiYgKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnlcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17bG9hZGluZ31cbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cbiAgICAgICAgICAgICAgICBzZXRFZGl0aW5nTWVldGluZ0lkKFxuICAgICAgICAgICAgICAgICAgZWRpdGluZ01lZXRpbmdJZCA9PT0gbWVldGluZy5pZFxuICAgICAgICAgICAgICAgICAgICA/IG51bGxcbiAgICAgICAgICAgICAgICAgICAgOiBtZWV0aW5nLmlkXG4gICAgICAgICAgICAgICAgKVxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIEVkaXQgTWVldGluZ1xuICAgICAgICAgICAgPC9idXR0b24+XG5cbiAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWRhbmdlclwiXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjYW5jZWxNZWV0aW5nKG1lZXRpbmcpfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBDYW5jZWwgQ2xhc3NcbiAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgIDwvPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgKX1cblxuICAgIHtjYW5NYW5hZ2VNZWV0aW5ncyAmJlxuICAgICAgbWVldGluZy5zdGF0dXMgPT09ICdzY2hlZHVsZWQnICYmXG4gICAgICBlZGl0aW5nTWVldGluZ0lkID09PSBtZWV0aW5nLmlkICYmIChcbiAgICAgICAgPEVkaXRNZWV0aW5nRm9ybVxuICAgICAgICAgIG1lZXRpbmc9e21lZXRpbmd9XG4gICAgICAgICAgdG9rZW49e3Rva2VufVxuICAgICAgICAgIG9uQ2FuY2VsPXsoKSA9PlxuICAgICAgICAgICAgc2V0RWRpdGluZ01lZXRpbmdJZChudWxsKVxuICAgICAgICAgIH1cbiAgICAgICAgICBvblVwZGF0ZWQ9e2FzeW5jICgpID0+IHtcbiAgICAgICAgICAgIHNldEVkaXRpbmdNZWV0aW5nSWQobnVsbClcbiAgICAgICAgICAgIGF3YWl0IHNlbGVjdENvdXJzZShtZWV0aW5nLmNvdXJzZV9pZClcbiAgICAgICAgICB9fVxuICAgICAgICAvPlxuICAgICAgKX1cbiAgICBcbntjYW5NYW5hZ2VNZWV0aW5ncyAmJiBtZWV0aW5nLnN0YXR1cyAhPT0gJ2NhbmNlbGxlZCcgJiYgKFxuICA8ZGl2IGNsYXNzTmFtZT1cIm1lZXRpbmctYWN0aW9uc1wiPlxuICAgIDxidXR0b25cbiAgICAgIHR5cGU9XCJidXR0b25cIlxuICAgICAgY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiXG4gICAgICBvbkNsaWNrPXsoKSA9PlxuICAgICAgICBzZXRBdHRlbmRhbmNlTWVldGluZ0lkKFxuICAgICAgICAgIGF0dGVuZGFuY2VNZWV0aW5nSWQgPT09IG1lZXRpbmcuaWRcbiAgICAgICAgICAgID8gbnVsbFxuICAgICAgICAgICAgOiBtZWV0aW5nLmlkXG4gICAgICAgIClcbiAgICAgIH1cbiAgICA+XG4gICAgICB7YXR0ZW5kYW5jZU1lZXRpbmdJZCA9PT0gbWVldGluZy5pZFxuICAgICAgICA/ICdDbG9zZSBBdHRlbmRhbmNlJ1xuICAgICAgICA6ICdNYW5hZ2UgQXR0ZW5kYW5jZSd9XG4gICAgPC9idXR0b24+XG4gIDwvZGl2PlxuKX1cblxue2Nhbk1hbmFnZU1lZXRpbmdzICYmXG4gIG1lZXRpbmcuc3RhdHVzICE9PSAnY2FuY2VsbGVkJyAmJlxuICBhdHRlbmRhbmNlTWVldGluZ0lkID09PSBtZWV0aW5nLmlkICYmIChcbiAgICA8QXR0ZW5kYW5jZU1hbmFnZXJcbiAgICAgIGtleT17bWVldGluZy5pZH1cbiAgICAgIG1lZXRpbmdJZD17bWVldGluZy5pZH1cbiAgICAgIHRva2VuPXt0b2tlbn1cbiAgICAgIG9uQ2xvc2U9eygpID0+XG4gICAgICAgIHNldEF0dGVuZGFuY2VNZWV0aW5nSWQobnVsbClcbiAgICAgIH1cbiAgICAvPlxuICApfVxuICBcbnsvKiBBdXRvbWF0aWMgQXR0ZW5kYW5jZSBSZXBvcnQgKi99XG5cbntjYW5NYW5hZ2VNZWV0aW5ncyAmJiAoXG4gIDxidXR0b25cbiAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICBjbGFzc05hbWU9XCJidG4tc2Vjb25kYXJ5XCJcbiAgICBvbkNsaWNrPXsoKSA9PlxuICAgICAgc2V0QXV0b1JlcG9ydE1lZXRpbmdJZChcbiAgICAgICAgYXV0b1JlcG9ydE1lZXRpbmdJZCA9PT0gbWVldGluZy5pZFxuICAgICAgICAgID8gbnVsbFxuICAgICAgICAgIDogbWVldGluZy5pZFxuICAgICAgKVxuICAgIH1cbiAgPlxuICAgIHthdXRvUmVwb3J0TWVldGluZ0lkID09PSBtZWV0aW5nLmlkXG4gICAgICA/ICdIaWRlIEF1dG9tYXRpYyBSZXBvcnQnXG4gICAgICA6ICdBdXRvbWF0aWMgQXR0ZW5kYW5jZSBSZXBvcnQnfVxuICA8L2J1dHRvbj5cbil9XG5cbntjYW5NYW5hZ2VNZWV0aW5ncyAmJlxuICBhdXRvUmVwb3J0TWVldGluZ0lkID09PSBtZWV0aW5nLmlkICYmIChcbiAgICA8QXV0b21hdGljQXR0ZW5kYW5jZVJlcG9ydFxuICAgICAgbWVldGluZ0lkPXttZWV0aW5nLmlkfVxuICAgICAgdG9rZW49e3Rva2VufVxuICAgIC8+XG4gICl9XG5cbiAgPC9hcnRpY2xlPlxuKSl9XG5cbiAgICAgICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8Lz5cbiAgICAgICAgKX1cblxuICAgICAgICB7cGFnZSA9PT0gJ2NsYXNzcm9vbScgJiYgKFxuICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBhbmVsIGNsYXNzcm9vbVwiPlxuICAgICAgICAgICAgPGgyPkxpdmUgQ2xhc3Nyb29tPC9oMj5cblxuICAgICAgICAgICAge3Jvb21OYW1lID8gKFxuICAgICAgICAgICAgICA8PlxuICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFJvb21OYW1lKCcnKX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICBDbG9zZSBDbGFzc3Jvb21cbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cblxuICAgICAgICAgICAgICAgIHthY3RpdmVNZWV0aW5nSWQgIT09IG51bGwgJiYgKFxuICA8VHJhY2tlZENsYXNzcm9vbVxuICAgIG1lZXRpbmdJZD17YWN0aXZlTWVldGluZ0lkfVxuICAgIHJvb21OYW1lPXtyb29tTmFtZX1cbiAgICB0b2tlbj17dG9rZW59XG4gICAgcm9sZT17YWNjb3VudC5yb2xlfVxuICAgIGRpc3BsYXlOYW1lPXthY2NvdW50LmZ1bGxfbmFtZX1cbiAgICBvbkNsb3NlPXsoKSA9PiB7XG4gICAgICBzZXRSb29tTmFtZSgnJylcbiAgICAgIHNldEFjdGl2ZU1lZXRpbmdJZChudWxsKVxuICAgIH19XG4gIC8+XG4pfVxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICkgOiAoXG4gICAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgICAgPHA+XG4gICAgICAgICAgICAgICAgICBObyBjbGFzc3Jvb20gaXMgb3Blbi5cbiAgICAgICAgICAgICAgICAgIFNlbGVjdCBhIGNvdXJzZSBhbmQgam9pbiBhIHNjaGVkdWxlZFxuICAgICAgICAgICAgICAgICAgbWVldGluZyB0byBnZXQgc3RhcnRlZC5cbiAgICAgICAgICAgICAgICA8L3A+XG5cbiAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRQYWdlKCdjb3Vyc2VzJyl9XG4gICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgR28gdG8gQ291cnNlc1xuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICA8Lz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICApfVxuICAgICAgPC9tYWluPlxuICAgIDwvZGl2PlxuICApXG59XG4iXX0=