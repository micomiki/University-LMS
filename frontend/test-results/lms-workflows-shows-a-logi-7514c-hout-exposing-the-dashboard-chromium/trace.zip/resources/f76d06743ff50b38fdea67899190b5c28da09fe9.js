import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AttendanceManager.tsx");const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AttendanceManager.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
const attendanceOptions = [
	{
		value: "present",
		label: "Present"
	},
	{
		value: "absent",
		label: "Absent"
	},
	{
		value: "late",
		label: "Late"
	},
	{
		value: "excused",
		label: "Excused"
	}
];
export default function AttendanceManager({ meetingId, token, onClose }) {
	_s();
	const [roster, setRoster] = useState([]);
	const [selectedStatuses, setSelectedStatuses] = useState({});
	const [loading, setLoading] = useState(true);
	const [savingId, setSavingId] = useState(null);
	const [error, setError] = useState("");
	const [message, setMessage] = useState("");
	const loadRoster = useCallback(async (signal) => {
		setLoading(true);
		setError("");
		try {
			const response = await fetch(`/api/attendance/meetings/${meetingId}/roster`, {
				headers: { Authorization: `Bearer ${token}` },
				signal
			});
			if (!response.ok) {
				throw new Error(`Unable to load attendance (${response.status}).`);
			}
			const data = await response.json();
			if (signal?.aborted) return;
			setRoster(data);
			const selections = {};
			for (const student of data) {
				const existing = attendanceOptions.find((option) => option.value === student.status);
				selections[student.student_id] = existing?.value ?? "present";
			}
			setSelectedStatuses(selections);
		} catch (err) {
			if (signal?.aborted) return;
			setError(err instanceof Error ? err.message : "Unable to load attendance.");
		} finally {
			if (!signal?.aborted) {
				setLoading(false);
			}
		}
	}, [meetingId, token]);
	useEffect(() => {
		const controller = new AbortController();
		void loadRoster(controller.signal);
		return () => controller.abort();
	}, [loadRoster]);
	async function saveAttendance(student) {
		const status = selectedStatuses[student.student_id] ?? "present";
		const isNew = student.attendance_id === null;
		const endpoint = isNew ? `/api/attendance/meetings/${meetingId}` : `/api/attendance/${student.attendance_id}`;
		setSavingId(student.student_id);
		setError("");
		setMessage("");
		try {
			const response = await fetch(endpoint, {
				method: isNew ? "POST" : "PUT",
				headers: {
					Authorization: `Bearer ${token}`,
					"Content-Type": "application/json"
				},
				body: JSON.stringify(isNew ? {
					student_id: student.student_id,
					status
				} : { status })
			});
			if (!response.ok) {
				const data = await response.json().catch(() => null);
				throw new Error(typeof data?.detail === "string" ? data.detail : `Unable to save attendance (${response.status}).`);
			}
			setMessage(`Attendance saved for ${student.full_name}.`);
			await loadRoster();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to save attendance.");
		} finally {
			setSavingId(null);
		}
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "attendance-manager",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "attendance-header",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Class Attendance" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 191,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: ["Meeting ID: ", meetingId] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 192,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 190,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "btn-secondary",
					onClick: onClose,
					children: "Close"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 195,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 189,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 205,
				columnNumber: 9
			}, this),
			message && /* @__PURE__ */ _jsxDEV("p", {
				className: "success-message",
				role: "status",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 211,
				columnNumber: 9
			}, this),
			loading ? /* @__PURE__ */ _jsxDEV("p", { children: "Loading student roster..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 217,
				columnNumber: 9
			}, this) : roster.length === 0 ? /* @__PURE__ */ _jsxDEV("p", { children: "No enrolled students found for this class." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 219,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "attendance-table-wrapper",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "attendance-table",
					children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("th", { children: "Student" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 225,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Current Status" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 226,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Mark As" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 227,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Action" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 228,
							columnNumber: 17
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 224,
						columnNumber: 15
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 223,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: roster.map((student) => /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("td", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: student.full_name }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 236,
							columnNumber: 21
						}, this), /* @__PURE__ */ _jsxDEV("small", { children: ["ID: ", student.student_id] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 237,
							columnNumber: 21
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 235,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("span", {
							className: `attendance-status ${student.status || "unmarked"}`,
							children: student.status || "Not marked"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 243,
							columnNumber: 21
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 242,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("select", {
							"aria-label": `Attendance status for ${student.full_name}`,
							value: selectedStatuses[student.student_id] ?? "present",
							disabled: savingId !== null,
							onChange: (event) => setSelectedStatuses((previous) => ({
								...previous,
								[student.student_id]: event.target.value
							})),
							children: attendanceOptions.map((option) => /* @__PURE__ */ _jsxDEV("option", {
								value: option.value,
								children: option.label
							}, option.value, false, {
								fileName: _jsxFileName,
								lineNumber: 272,
								columnNumber: 25
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 253,
							columnNumber: 21
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 252,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							disabled: savingId !== null || loading,
							onClick: () => saveAttendance(student),
							children: savingId === student.student_id ? "Saving..." : student.attendance_id === null ? "Mark" : "Update"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 283,
							columnNumber: 21
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 282,
							columnNumber: 19
						}, this)
					] }, student.student_id, true, {
						fileName: _jsxFileName,
						lineNumber: 234,
						columnNumber: 17
					}, this)) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 232,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 222,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 221,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 188,
		columnNumber: 5
	}, this);
}
_s(AttendanceManager, "c0xd20L9reTxID58ksYVlxNGxKk=");
_c = AttendanceManager;
var _c;
$RefreshReg$(_c, "AttendanceManager");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AttendanceManager.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AttendanceManager.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AttendanceManager.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AttendanceManager.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FDRSxhQUNBLFdBQ0EsZ0JBQ0s7Ozs7QUFxQlAsTUFBTSxvQkFHQTtDQUNKO0VBQUUsT0FBTztFQUFXLE9BQU87Q0FBVTtDQUNyQztFQUFFLE9BQU87RUFBVSxPQUFPO0NBQVM7Q0FDbkM7RUFBRSxPQUFPO0VBQVEsT0FBTztDQUFPO0NBQy9CO0VBQUUsT0FBTztFQUFXLE9BQU87Q0FBVTtBQUN2QztBQUVBLGVBQWUsU0FBUyxrQkFBa0IsRUFDeEMsV0FDQSxPQUNBLFdBQ1E7O0NBQ1IsTUFBTSxDQUFDLFFBQVEsYUFBYSxTQUUxQixDQUFDLENBQUM7Q0FFSixNQUFNLENBQUMsa0JBQWtCLHVCQUN2QixTQUEyQyxDQUFDLENBQUM7Q0FFL0MsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUM5QixJQUNGO0NBRUEsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEVBQUU7Q0FFekMsTUFBTSxhQUFhLFlBQ2pCLE9BQU8sV0FBeUI7RUFDOUIsV0FBVyxJQUFJO0VBQ2YsU0FBUyxFQUFFO0VBRVgsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQ3JCLDRCQUE0QixVQUFVLFVBQ3RDO0lBQ0UsU0FBUyxFQUNQLGVBQWUsVUFBVSxRQUMzQjtJQUNBO0dBQ0YsQ0FDRjtHQUVBLElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsTUFBTSxJQUFJLE1BQ1IsOEJBQThCLFNBQVMsT0FBTyxHQUNoRDtHQUNGO0dBRUEsTUFBTSxPQUNKLE1BQU0sU0FBUyxLQUFLO0dBRXRCLElBQUksUUFBUSxTQUFTO0dBRXJCLFVBQVUsSUFBSTtHQUVkLE1BQU0sYUFHRixDQUFDO0dBRUwsS0FBSyxNQUFNLFdBQVcsTUFBTTtJQUMxQixNQUFNLFdBQVcsa0JBQWtCLE1BQ2hDLFdBQVcsT0FBTyxVQUFVLFFBQVEsTUFDdkM7SUFFQSxXQUFXLFFBQVEsY0FDakIsVUFBVSxTQUFTO0dBQ3ZCO0dBRUEsb0JBQW9CLFVBQVU7RUFDaEMsU0FBUyxLQUFLO0dBQ1osSUFBSSxRQUFRLFNBQVM7R0FFckIsU0FDRSxlQUFlLFFBQ1gsSUFBSSxVQUNKLDRCQUNOO0VBQ0YsVUFBVTtHQUNSLElBQUksQ0FBQyxRQUFRLFNBQVM7SUFDcEIsV0FBVyxLQUFLO0dBQ2xCO0VBQ0Y7Q0FDRixHQUNBLENBQUMsV0FBVyxLQUFLLENBQ25CO0NBRUEsZ0JBQWdCO0VBQ2QsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0VBRXZDLEtBQUssV0FBVyxXQUFXLE1BQU07RUFFakMsYUFBYSxXQUFXLE1BQU07Q0FDaEMsR0FBRyxDQUFDLFVBQVUsQ0FBQztDQUVmLGVBQWUsZUFDYixTQUNBO0VBQ0EsTUFBTSxTQUNKLGlCQUFpQixRQUFRLGVBQWU7RUFFMUMsTUFBTSxRQUFRLFFBQVEsa0JBQWtCO0VBRXhDLE1BQU0sV0FBVyxRQUNiLDRCQUE0QixjQUM1QixtQkFBbUIsUUFBUTtFQUUvQixZQUFZLFFBQVEsVUFBVTtFQUM5QixTQUFTLEVBQUU7RUFDWCxXQUFXLEVBQUU7RUFFYixJQUFJO0dBQ0YsTUFBTSxXQUFXLE1BQU0sTUFBTSxVQUFVO0lBQ3JDLFFBQVEsUUFBUSxTQUFTO0lBQ3pCLFNBQVM7S0FDUCxlQUFlLFVBQVU7S0FDekIsZ0JBQWdCO0lBQ2xCO0lBQ0EsTUFBTSxLQUFLLFVBQ1QsUUFDSTtLQUNFLFlBQVksUUFBUTtLQUNwQjtJQUNGLElBQ0EsRUFBRSxPQUFPLENBQ2Y7R0FDRixDQUFDO0dBRUQsSUFBSSxDQUFDLFNBQVMsSUFBSTtJQUNoQixNQUFNLE9BQU8sTUFBTSxTQUNoQixLQUFLLENBQUMsQ0FDTixZQUFZLElBQUk7SUFFbkIsTUFBTSxJQUFJLE1BQ1IsT0FBTyxNQUFNLFdBQVcsV0FDcEIsS0FBSyxTQUNMLDhCQUE4QixTQUFTLE9BQU8sR0FDcEQ7R0FDRjtHQUVBLFdBQ0Usd0JBQXdCLFFBQVEsVUFBVSxFQUM1QztHQUVBLE1BQU0sV0FBVztFQUNuQixTQUFTLEtBQUs7R0FDWixTQUNFLGVBQWUsUUFDWCxJQUFJLFVBQ0osNEJBQ047RUFDRixVQUFVO0dBQ1IsWUFBWSxJQUFJO0VBQ2xCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksbUJBQW9COzs7O2NBQ3hCLHdCQUFDLEtBQUQsYUFBRyxnQkFBYSxTQUFhOzs7O1lBQzFCOzs7O2NBRUwsd0JBQUMsVUFBRDtLQUNFLE1BQUs7S0FDTCxXQUFVO0tBQ1YsU0FBUztlQUNWO0lBRU87Ozs7WUFDTDs7Ozs7O0dBRUosU0FDQyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtJQUFRLE1BQUs7Y0FDdkI7R0FDQTs7Ozs7R0FHSixXQUNDLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO0lBQWtCLE1BQUs7Y0FDakM7R0FDQTs7Ozs7R0FHSixVQUNDLHdCQUFDLEtBQUQsWUFBRyw0QkFBNEI7Ozs7Y0FDN0IsT0FBTyxXQUFXLElBQ3BCLHdCQUFDLEtBQUQsWUFBRyw2Q0FBNkM7Ozs7Y0FFaEQsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO01BQ0Usd0JBQUMsTUFBRCxZQUFJLFVBQVc7Ozs7O01BQ2Ysd0JBQUMsTUFBRCxZQUFJLGlCQUFrQjs7Ozs7TUFDdEIsd0JBQUMsTUFBRCxZQUFJLFVBQVc7Ozs7O01BQ2Ysd0JBQUMsTUFBRCxZQUFJLFNBQVU7Ozs7O0tBQ1o7Ozs7Y0FDQzs7OztlQUVQLHdCQUFDLFNBQUQsWUFDRyxPQUFPLEtBQUssWUFDWCx3QkFBQyxNQUFEO01BQ0Usd0JBQUMsTUFBRCxhQUNFLHdCQUFDLFVBQUQsWUFBUyxRQUFRLFVBQWtCOzs7O2dCQUNuQyx3QkFBQyxTQUFELGFBQU8sUUFDQSxRQUFRLFVBQ1I7Ozs7Y0FDTDs7Ozs7TUFFSix3QkFBQyxNQUFELFlBQ0Usd0JBQUMsUUFBRDtPQUNFLFdBQVcscUJBQ1QsUUFBUSxVQUFVO2lCQUduQixRQUFRLFVBQVU7TUFDZjs7OztlQUNKOzs7OztNQUVKLHdCQUFDLE1BQUQsWUFDRSx3QkFBQyxVQUFEO09BQ0UsY0FBWSx5QkFBeUIsUUFBUTtPQUM3QyxPQUNFLGlCQUNFLFFBQVEsZUFDTDtPQUVQLFVBQVUsYUFBYTtPQUN2QixXQUFXLFVBQ1QscUJBQ0csY0FBYztRQUNiLEdBQUc7U0FDRixRQUFRLGFBQ1AsTUFBTSxPQUFPO09BQ2pCLEVBQ0Y7aUJBR0Qsa0JBQWtCLEtBQUssV0FDdEIsd0JBQUMsVUFBRDtRQUVFLE9BQU8sT0FBTztrQkFFYixPQUFPO09BQ0YsR0FKRCxPQUFPOzs7O2NBSU4sQ0FDVDtNQUNLOzs7O2VBQ047Ozs7O01BRUosd0JBQUMsTUFBRCxZQUNFLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsVUFDRSxhQUFhLFFBQVE7T0FFdkIsZUFDRSxlQUFlLE9BQU87aUJBR3ZCLGFBQWEsUUFBUSxhQUNsQixjQUNBLFFBQVEsa0JBQWtCLE9BQ3hCLFNBQ0E7TUFDQTs7OztlQUNOOzs7OztLQUNGLEtBakVLLFFBQVE7Ozs7WUFpRWIsQ0FDTCxFQUNJOzs7O2FBQ0Y7Ozs7OztHQUNKOzs7OztFQUVBOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBdHRlbmRhbmNlTWFuYWdlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiXHJcbmltcG9ydCB7XHJcbiAgdXNlQ2FsbGJhY2ssXHJcbiAgdXNlRWZmZWN0LFxyXG4gIHVzZVN0YXRlLFxyXG59IGZyb20gJ3JlYWN0J1xyXG5cclxudHlwZSBBdHRlbmRhbmNlU3RhdHVzID1cclxuICB8ICdwcmVzZW50J1xyXG4gIHwgJ2Fic2VudCdcclxuICB8ICdsYXRlJ1xyXG4gIHwgJ2V4Y3VzZWQnXHJcblxyXG50eXBlIEF0dGVuZGFuY2VSb3N0ZXJJdGVtID0ge1xyXG4gIHN0dWRlbnRfaWQ6IG51bWJlclxyXG4gIGZ1bGxfbmFtZTogc3RyaW5nXHJcbiAgYXR0ZW5kYW5jZV9pZDogbnVtYmVyIHwgbnVsbFxyXG4gIHN0YXR1czogc3RyaW5nIHwgbnVsbFxyXG59XHJcblxyXG50eXBlIFByb3BzID0ge1xyXG4gIG1lZXRpbmdJZDogbnVtYmVyXHJcbiAgdG9rZW46IHN0cmluZ1xyXG4gIG9uQ2xvc2U6ICgpID0+IHZvaWRcclxufVxyXG5cclxuY29uc3QgYXR0ZW5kYW5jZU9wdGlvbnM6IHtcclxuICB2YWx1ZTogQXR0ZW5kYW5jZVN0YXR1c1xyXG4gIGxhYmVsOiBzdHJpbmdcclxufVtdID0gW1xyXG4gIHsgdmFsdWU6ICdwcmVzZW50JywgbGFiZWw6ICdQcmVzZW50JyB9LFxyXG4gIHsgdmFsdWU6ICdhYnNlbnQnLCBsYWJlbDogJ0Fic2VudCcgfSxcclxuICB7IHZhbHVlOiAnbGF0ZScsIGxhYmVsOiAnTGF0ZScgfSxcclxuICB7IHZhbHVlOiAnZXhjdXNlZCcsIGxhYmVsOiAnRXhjdXNlZCcgfSxcclxuXVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXR0ZW5kYW5jZU1hbmFnZXIoe1xyXG4gIG1lZXRpbmdJZCxcclxuICB0b2tlbixcclxuICBvbkNsb3NlLFxyXG59OiBQcm9wcykge1xyXG4gIGNvbnN0IFtyb3N0ZXIsIHNldFJvc3Rlcl0gPSB1c2VTdGF0ZTxcclxuICAgIEF0dGVuZGFuY2VSb3N0ZXJJdGVtW11cclxuICA+KFtdKVxyXG5cclxuICBjb25zdCBbc2VsZWN0ZWRTdGF0dXNlcywgc2V0U2VsZWN0ZWRTdGF0dXNlc10gPVxyXG4gICAgdXNlU3RhdGU8UmVjb3JkPG51bWJlciwgQXR0ZW5kYW5jZVN0YXR1cz4+KHt9KVxyXG5cclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKVxyXG4gIGNvbnN0IFtzYXZpbmdJZCwgc2V0U2F2aW5nSWRdID0gdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4oXHJcbiAgICBudWxsXHJcbiAgKVxyXG5cclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKCcnKVxyXG5cclxuICBjb25zdCBsb2FkUm9zdGVyID0gdXNlQ2FsbGJhY2soXHJcbiAgICBhc3luYyAoc2lnbmFsPzogQWJvcnRTaWduYWwpID0+IHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKVxyXG4gICAgICBzZXRFcnJvcignJylcclxuXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgIGAvYXBpL2F0dGVuZGFuY2UvbWVldGluZ3MvJHttZWV0aW5nSWR9L3Jvc3RlcmAsXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2lnbmFsLFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICAgICAgICBgVW5hYmxlIHRvIGxvYWQgYXR0ZW5kYW5jZSAoJHtyZXNwb25zZS5zdGF0dXN9KS5gXHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBkYXRhOiBBdHRlbmRhbmNlUm9zdGVySXRlbVtdID1cclxuICAgICAgICAgIGF3YWl0IHJlc3BvbnNlLmpzb24oKVxyXG5cclxuICAgICAgICBpZiAoc2lnbmFsPy5hYm9ydGVkKSByZXR1cm5cclxuXHJcbiAgICAgICAgc2V0Um9zdGVyKGRhdGEpXHJcblxyXG4gICAgICAgIGNvbnN0IHNlbGVjdGlvbnM6IFJlY29yZDxcclxuICAgICAgICAgIG51bWJlcixcclxuICAgICAgICAgIEF0dGVuZGFuY2VTdGF0dXNcclxuICAgICAgICA+ID0ge31cclxuXHJcbiAgICAgICAgZm9yIChjb25zdCBzdHVkZW50IG9mIGRhdGEpIHtcclxuICAgICAgICAgIGNvbnN0IGV4aXN0aW5nID0gYXR0ZW5kYW5jZU9wdGlvbnMuZmluZChcclxuICAgICAgICAgICAgKG9wdGlvbikgPT4gb3B0aW9uLnZhbHVlID09PSBzdHVkZW50LnN0YXR1c1xyXG4gICAgICAgICAgKVxyXG5cclxuICAgICAgICAgIHNlbGVjdGlvbnNbc3R1ZGVudC5zdHVkZW50X2lkXSA9XHJcbiAgICAgICAgICAgIGV4aXN0aW5nPy52YWx1ZSA/PyAncHJlc2VudCdcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNldFNlbGVjdGVkU3RhdHVzZXMoc2VsZWN0aW9ucylcclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgaWYgKHNpZ25hbD8uYWJvcnRlZCkgcmV0dXJuXHJcblxyXG4gICAgICAgIHNldEVycm9yKFxyXG4gICAgICAgICAgZXJyIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICAgICAgPyBlcnIubWVzc2FnZVxyXG4gICAgICAgICAgICA6ICdVbmFibGUgdG8gbG9hZCBhdHRlbmRhbmNlLidcclxuICAgICAgICApXHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgaWYgKCFzaWduYWw/LmFib3J0ZWQpIHtcclxuICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAgW21lZXRpbmdJZCwgdG9rZW5dXHJcbiAgKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgY29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKVxyXG5cclxuICAgIHZvaWQgbG9hZFJvc3Rlcihjb250cm9sbGVyLnNpZ25hbClcclxuXHJcbiAgICByZXR1cm4gKCkgPT4gY29udHJvbGxlci5hYm9ydCgpXHJcbiAgfSwgW2xvYWRSb3N0ZXJdKVxyXG5cclxuICBhc3luYyBmdW5jdGlvbiBzYXZlQXR0ZW5kYW5jZShcclxuICAgIHN0dWRlbnQ6IEF0dGVuZGFuY2VSb3N0ZXJJdGVtXHJcbiAgKSB7XHJcbiAgICBjb25zdCBzdGF0dXMgPVxyXG4gICAgICBzZWxlY3RlZFN0YXR1c2VzW3N0dWRlbnQuc3R1ZGVudF9pZF0gPz8gJ3ByZXNlbnQnXHJcblxyXG4gICAgY29uc3QgaXNOZXcgPSBzdHVkZW50LmF0dGVuZGFuY2VfaWQgPT09IG51bGxcclxuXHJcbiAgICBjb25zdCBlbmRwb2ludCA9IGlzTmV3XHJcbiAgICAgID8gYC9hcGkvYXR0ZW5kYW5jZS9tZWV0aW5ncy8ke21lZXRpbmdJZH1gXHJcbiAgICAgIDogYC9hcGkvYXR0ZW5kYW5jZS8ke3N0dWRlbnQuYXR0ZW5kYW5jZV9pZH1gXHJcblxyXG4gICAgc2V0U2F2aW5nSWQoc3R1ZGVudC5zdHVkZW50X2lkKVxyXG4gICAgc2V0RXJyb3IoJycpXHJcbiAgICBzZXRNZXNzYWdlKCcnKVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goZW5kcG9pbnQsIHtcclxuICAgICAgICBtZXRob2Q6IGlzTmV3ID8gJ1BPU1QnIDogJ1BVVCcsXHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAsXHJcbiAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoXHJcbiAgICAgICAgICBpc05ld1xyXG4gICAgICAgICAgICA/IHtcclxuICAgICAgICAgICAgICAgIHN0dWRlbnRfaWQ6IHN0dWRlbnQuc3R1ZGVudF9pZCxcclxuICAgICAgICAgICAgICAgIHN0YXR1cyxcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIDogeyBzdGF0dXMgfVxyXG4gICAgICAgICksXHJcbiAgICAgIH0pXHJcblxyXG4gICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlXHJcbiAgICAgICAgICAuanNvbigpXHJcbiAgICAgICAgICAuY2F0Y2goKCkgPT4gbnVsbClcclxuXHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICAgICAgdHlwZW9mIGRhdGE/LmRldGFpbCA9PT0gJ3N0cmluZydcclxuICAgICAgICAgICAgPyBkYXRhLmRldGFpbFxyXG4gICAgICAgICAgICA6IGBVbmFibGUgdG8gc2F2ZSBhdHRlbmRhbmNlICgke3Jlc3BvbnNlLnN0YXR1c30pLmBcclxuICAgICAgICApXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHNldE1lc3NhZ2UoXHJcbiAgICAgICAgYEF0dGVuZGFuY2Ugc2F2ZWQgZm9yICR7c3R1ZGVudC5mdWxsX25hbWV9LmBcclxuICAgICAgKVxyXG5cclxuICAgICAgYXdhaXQgbG9hZFJvc3RlcigpXHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJyb3IoXHJcbiAgICAgICAgZXJyIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICAgID8gZXJyLm1lc3NhZ2VcclxuICAgICAgICAgIDogJ1VuYWJsZSB0byBzYXZlIGF0dGVuZGFuY2UuJ1xyXG4gICAgICApXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRTYXZpbmdJZChudWxsKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cImF0dGVuZGFuY2UtbWFuYWdlclwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImF0dGVuZGFuY2UtaGVhZGVyXCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxoMz5DbGFzcyBBdHRlbmRhbmNlPC9oMz5cclxuICAgICAgICAgIDxwPk1lZXRpbmcgSUQ6IHttZWV0aW5nSWR9PC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgb25DbGljaz17b25DbG9zZX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICBDbG9zZVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cclxuICAgICAgICAgIHtlcnJvcn1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7bWVzc2FnZSAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwic3VjY2Vzcy1tZXNzYWdlXCIgcm9sZT1cInN0YXR1c1wiPlxyXG4gICAgICAgICAge21lc3NhZ2V9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgPHA+TG9hZGluZyBzdHVkZW50IHJvc3Rlci4uLjwvcD5cclxuICAgICAgKSA6IHJvc3Rlci5sZW5ndGggPT09IDAgPyAoXHJcbiAgICAgICAgPHA+Tm8gZW5yb2xsZWQgc3R1ZGVudHMgZm91bmQgZm9yIHRoaXMgY2xhc3MuPC9wPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXR0ZW5kYW5jZS10YWJsZS13cmFwcGVyXCI+XHJcbiAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwiYXR0ZW5kYW5jZS10YWJsZVwiPlxyXG4gICAgICAgICAgICA8dGhlYWQ+XHJcbiAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgPHRoPlN0dWRlbnQ8L3RoPlxyXG4gICAgICAgICAgICAgICAgPHRoPkN1cnJlbnQgU3RhdHVzPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aD5NYXJrIEFzPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aD5BY3Rpb248L3RoPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgIDwvdGhlYWQ+XHJcblxyXG4gICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAge3Jvc3Rlci5tYXAoKHN0dWRlbnQpID0+IChcclxuICAgICAgICAgICAgICAgIDx0ciBrZXk9e3N0dWRlbnQuc3R1ZGVudF9pZH0+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZD5cclxuICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPntzdHVkZW50LmZ1bGxfbmFtZX08L3N0cm9uZz5cclxuICAgICAgICAgICAgICAgICAgICA8c21hbGw+XHJcbiAgICAgICAgICAgICAgICAgICAgICBJRDoge3N0dWRlbnQuc3R1ZGVudF9pZH1cclxuICAgICAgICAgICAgICAgICAgICA8L3NtYWxsPlxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPHRkPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuXHJcbiAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2BhdHRlbmRhbmNlLXN0YXR1cyAke1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdHVkZW50LnN0YXR1cyB8fCAndW5tYXJrZWQnXHJcbiAgICAgICAgICAgICAgICAgICAgICB9YH1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c3R1ZGVudC5zdGF0dXMgfHwgJ05vdCBtYXJrZWQnfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuXHJcbiAgICAgICAgICAgICAgICAgIDx0ZD5cclxuICAgICAgICAgICAgICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgQXR0ZW5kYW5jZSBzdGF0dXMgZm9yICR7c3R1ZGVudC5mdWxsX25hbWV9YH1cclxuICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2VsZWN0ZWRTdGF0dXNlc1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICBzdHVkZW50LnN0dWRlbnRfaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgXSA/PyAncHJlc2VudCdcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIGRpc2FibGVkPXtzYXZpbmdJZCAhPT0gbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFNlbGVjdGVkU3RhdHVzZXMoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgKHByZXZpb3VzKSA9PiAoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLi4ucHJldmlvdXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBbc3R1ZGVudC5zdHVkZW50X2lkXTpcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXZlbnQudGFyZ2V0LnZhbHVlIGFzIEF0dGVuZGFuY2VTdGF0dXMsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICAgIHthdHRlbmRhbmNlT3B0aW9ucy5tYXAoKG9wdGlvbikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtvcHRpb24udmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e29wdGlvbi52YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgIHtvcHRpb24ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8dGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNhdmluZ0lkICE9PSBudWxsIHx8IGxvYWRpbmdcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNhdmVBdHRlbmRhbmNlKHN0dWRlbnQpXHJcbiAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAge3NhdmluZ0lkID09PSBzdHVkZW50LnN0dWRlbnRfaWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnU2F2aW5nLi4uJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICA6IHN0dWRlbnQuYXR0ZW5kYW5jZV9pZCA9PT0gbnVsbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgID8gJ01hcmsnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnVXBkYXRlJ31cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9zZWN0aW9uPlxyXG4gIClcclxufVxyXG4iXX0=