import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/NotificationCenter.tsx");const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
import "/src/components/NotificationCenter.css";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/NotificationCenter.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
async function requestJSON(path, token, method = "GET") {
	const response = await fetch(path, {
		method,
		headers: { Authorization: `Bearer ${token}` }
	});
	if (!response.ok) {
		throw new Error(`Notifications request failed (${response.status}).`);
	}
	return response.json();
}
export default function NotificationCenter({ token, onOpenAssignment }) {
	_s();
	const [open, setOpen] = useState(false);
	const [notifications, setNotifications] = useState([]);
	const [unread, setUnread] = useState(0);
	const [loading, setLoading] = useState(false);
	const [busy, setBusy] = useState(false);
	const [error, setError] = useState("");
	const refresh = useCallback(async () => {
		const [items, count] = await Promise.all([requestJSON("/api/notifications/?limit=20", token), requestJSON("/api/notifications/unread-count", token)]);
		setNotifications(items);
		setUnread(count.unread_count);
	}, [token]);
	useEffect(() => {
		let active = true;
		const sync = async () => {
			try {
				const [items, count] = await Promise.all([requestJSON("/api/notifications/?limit=20", token), requestJSON("/api/notifications/unread-count", token)]);
				if (active) {
					setNotifications(items);
					setUnread(count.unread_count);
					setError("");
				}
			} catch {
				if (active) setError("Could not load notifications.");
			}
		};
		void sync();
		const timer = window.setInterval(() => void sync(), 3e4);
		return () => {
			active = false;
			window.clearInterval(timer);
		};
	}, [token]);
	async function markRead(id) {
		setBusy(true);
		setError("");
		try {
			await requestJSON(`/api/notifications/${id}/read`, token, "PATCH");
			await refresh();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not mark notification as read.");
		} finally {
			setBusy(false);
		}
	}
	async function markAllRead() {
		setBusy(true);
		setError("");
		try {
			await requestJSON("/api/notifications/read-all", token, "PATCH");
			await refresh();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not mark all as read.");
		} finally {
			setBusy(false);
		}
	}
	async function openAssignment(item) {
		if (item.course_id === null) return;
		setLoading(true);
		if (item.read_at === null) {
			await markRead(item.id);
		}
		setOpen(false);
		setLoading(false);
		onOpenAssignment(item.course_id);
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "lms-notification-center",
		children: [/* @__PURE__ */ _jsxDEV("button", {
			className: "lms-notification-toggle",
			type: "button",
			"aria-expanded": open,
			"aria-controls": "lms-notification-panel",
			onClick: () => setOpen((value) => !value),
			children: ["Notifications", unread > 0 ? ` (${unread})` : ""]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 110,
			columnNumber: 7
		}, this), open && /* @__PURE__ */ _jsxDEV("section", {
			id: "lms-notification-panel",
			className: "lms-notification-panel",
			"aria-label": "Notifications",
			children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "lms-notification-heading",
					children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Notifications" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 123,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "btn-secondary",
						onClick: () => void markAllRead(),
						disabled: busy || unread === 0,
						children: "Mark all as read"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 124,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 122,
					columnNumber: 11
				}, this),
				error && /* @__PURE__ */ _jsxDEV("p", {
					role: "alert",
					className: "error",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 128,
					columnNumber: 21
				}, this),
				notifications.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
					className: "lms-notification-empty",
					children: "No notifications yet."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 130,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV("ul", {
					className: "lms-notification-list",
					children: notifications.map((item) => /* @__PURE__ */ _jsxDEV("li", {
						className: `lms-notification-item ${item.read_at === null ? "unread" : ""}`,
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "lms-notification-item-title",
								children: [/* @__PURE__ */ _jsxDEV("strong", { children: item.title }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 136,
									columnNumber: 21
								}, this), item.read_at === null && /* @__PURE__ */ _jsxDEV("span", {
									className: "lms-notification-dot",
									"aria-label": "Unread"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 137,
									columnNumber: 47
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 135,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("p", { children: item.message }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 139,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("small", { children: new Date(item.created_at).toLocaleString() }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 140,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "lms-notification-actions",
								children: [item.course_id !== null && /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									disabled: loading || busy,
									onClick: () => void openAssignment(item),
									children: "View assignment"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 143,
									columnNumber: 23
								}, this), item.read_at === null && /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "btn-secondary",
									disabled: busy,
									onClick: () => void markRead(item.id),
									children: "Mark read"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 148,
									columnNumber: 23
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 141,
								columnNumber: 19
							}, this)
						]
					}, item.id, true, {
						fileName: _jsxFileName,
						lineNumber: 134,
						columnNumber: 17
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 132,
					columnNumber: 13
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 121,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 109,
		columnNumber: 5
	}, this);
}
_s(NotificationCenter, "mnakIU3sbdYG9m9OruWLTecGS7Y=");
_c = NotificationCenter;
var _c;
$RefreshReg$(_c, "NotificationCenter");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/NotificationCenter.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/NotificationCenter.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/NotificationCenter.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/NotificationCenter.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxhQUFhLFdBQVcsZ0JBQWdCO0FBQ2pELE9BQU87Ozs7QUFtQlAsZUFBZSxZQUFlLE1BQWMsT0FBZSxTQUFTLE9BQW1CO0NBQ3JGLE1BQU0sV0FBVyxNQUFNLE1BQU0sTUFBTTtFQUNqQztFQUNBLFNBQVMsRUFBRSxlQUFlLFVBQVUsUUFBUTtDQUM5QyxDQUFDO0NBQ0QsSUFBSSxDQUFDLFNBQVMsSUFBSTtFQUNoQixNQUFNLElBQUksTUFBTSxpQ0FBaUMsU0FBUyxPQUFPLEdBQUc7Q0FDdEU7Q0FDQSxPQUFPLFNBQVMsS0FBSztBQUN2QjtBQUVBLGVBQWUsU0FBUyxtQkFBbUIsRUFBRSxPQUFPLG9CQUEyQjs7Q0FDN0UsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUs7Q0FDdEMsTUFBTSxDQUFDLGVBQWUsb0JBQW9CLFNBQTRCLENBQUMsQ0FBQztDQUN4RSxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsQ0FBQztDQUN0QyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsS0FBSztDQUN0QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUVyQyxNQUFNLFVBQVUsWUFBWSxZQUFZO0VBQ3RDLE1BQU0sQ0FBQyxPQUFPLFNBQVMsTUFBTSxRQUFRLElBQUksQ0FDdkMsWUFBK0IsZ0NBQWdDLEtBQUssR0FDcEUsWUFBc0MsbUNBQW1DLEtBQUssQ0FDaEYsQ0FBQztFQUNELGlCQUFpQixLQUFLO0VBQ3RCLFVBQVUsTUFBTSxZQUFZO0NBQzlCLEdBQUcsQ0FBQyxLQUFLLENBQUM7Q0FFVixnQkFBZ0I7RUFDZCxJQUFJLFNBQVM7RUFDYixNQUFNLE9BQU8sWUFBWTtHQUN2QixJQUFJO0lBQ0YsTUFBTSxDQUFDLE9BQU8sU0FBUyxNQUFNLFFBQVEsSUFBSSxDQUN2QyxZQUErQixnQ0FBZ0MsS0FBSyxHQUNwRSxZQUFzQyxtQ0FBbUMsS0FBSyxDQUNoRixDQUFDO0lBQ0QsSUFBSSxRQUFRO0tBQ1YsaUJBQWlCLEtBQUs7S0FDdEIsVUFBVSxNQUFNLFlBQVk7S0FDNUIsU0FBUyxFQUFFO0lBQ2I7R0FDRixRQUFRO0lBQ04sSUFBSSxRQUFRLFNBQVMsK0JBQStCO0dBQ3REO0VBQ0Y7RUFDQSxLQUFLLEtBQUs7RUFDVixNQUFNLFFBQVEsT0FBTyxrQkFBa0IsS0FBSyxLQUFLLEdBQUcsR0FBSztFQUN6RCxhQUFhO0dBQUUsU0FBUztHQUFPLE9BQU8sY0FBYyxLQUFLO0VBQUU7Q0FDN0QsR0FBRyxDQUFDLEtBQUssQ0FBQztDQUVWLGVBQWUsU0FBUyxJQUFZO0VBQ2xDLFFBQVEsSUFBSTtFQUNaLFNBQVMsRUFBRTtFQUNYLElBQUk7R0FDRixNQUFNLFlBQTZCLHNCQUFzQixHQUFHLFFBQVEsT0FBTyxPQUFPO0dBQ2xGLE1BQU0sUUFBUTtFQUNoQixTQUFTLEtBQUs7R0FDWixTQUFTLGVBQWUsUUFBUSxJQUFJLFVBQVUsc0NBQXNDO0VBQ3RGLFVBQVU7R0FDUixRQUFRLEtBQUs7RUFDZjtDQUNGO0NBRUEsZUFBZSxjQUFjO0VBQzNCLFFBQVEsSUFBSTtFQUNaLFNBQVMsRUFBRTtFQUNYLElBQUk7R0FDRixNQUFNLFlBQXNDLCtCQUErQixPQUFPLE9BQU87R0FDekYsTUFBTSxRQUFRO0VBQ2hCLFNBQVMsS0FBSztHQUNaLFNBQVMsZUFBZSxRQUFRLElBQUksVUFBVSw2QkFBNkI7RUFDN0UsVUFBVTtHQUNSLFFBQVEsS0FBSztFQUNmO0NBQ0Y7Q0FFQSxlQUFlLGVBQWUsTUFBdUI7RUFDbkQsSUFBSSxLQUFLLGNBQWMsTUFBTTtFQUM3QixXQUFXLElBQUk7RUFDZixJQUFJLEtBQUssWUFBWSxNQUFNO0dBQ3pCLE1BQU0sU0FBUyxLQUFLLEVBQUU7RUFDeEI7RUFDQSxRQUFRLEtBQUs7RUFDYixXQUFXLEtBQUs7RUFDaEIsaUJBQWlCLEtBQUssU0FBUztDQUNqQztDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNFLHdCQUFDLFVBQUQ7R0FDRSxXQUFVO0dBQ1YsTUFBSztHQUNMLGlCQUFlO0dBQ2YsaUJBQWM7R0FDZCxlQUFlLFNBQVEsVUFBUyxDQUFDLEtBQUs7YUFMeEMsQ0FNQyxpQkFDZSxTQUFTLElBQUksS0FBSyxPQUFPLEtBQUssRUFDdEM7Ozs7O1lBRVAsUUFDQyx3QkFBQyxXQUFEO0dBQVMsSUFBRztHQUF5QixXQUFVO0dBQXlCLGNBQVc7YUFBbkY7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFJLGdCQUFpQjs7OztlQUNyQix3QkFBQyxVQUFEO01BQVEsTUFBSztNQUFTLFdBQVU7TUFBZ0IsZUFBZSxLQUFLLFlBQVk7TUFBRyxVQUFVLFFBQVEsV0FBVztnQkFBRztLQUUzRzs7OzthQUNMOzs7Ozs7SUFDSixTQUFTLHdCQUFDLEtBQUQ7S0FBRyxNQUFLO0tBQVEsV0FBVTtlQUFTO0lBQVM7Ozs7O0lBQ3JELGNBQWMsV0FBVyxJQUN4Qix3QkFBQyxLQUFEO0tBQUcsV0FBVTtlQUF5QjtJQUF3Qjs7OztlQUU5RCx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUNYLGNBQWMsS0FBSSxTQUNqQix3QkFBQyxNQUFEO01BQWtCLFdBQVcseUJBQXlCLEtBQUssWUFBWSxPQUFPLFdBQVc7Z0JBQXpGO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFELFlBQVMsS0FBSyxNQUFjOzs7O2tCQUMzQixLQUFLLFlBQVksUUFBUSx3QkFBQyxRQUFEO1NBQU0sV0FBVTtTQUF1QixjQUFXO1FBQVU7Ozs7Z0JBQ25GOzs7Ozs7T0FDTCx3QkFBQyxLQUFELFlBQUksS0FBSyxRQUFXOzs7OztPQUNwQix3QkFBQyxTQUFELFlBQVEsSUFBSSxLQUFLLEtBQUssVUFBVSxDQUFDLENBQUMsZUFBZSxFQUFTOzs7OztPQUMxRCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNHLEtBQUssY0FBYyxRQUNsQix3QkFBQyxVQUFEO1NBQVEsTUFBSztTQUFTLFVBQVUsV0FBVztTQUFNLGVBQWUsS0FBSyxlQUFlLElBQUk7bUJBQUc7UUFFbkY7Ozs7a0JBRVQsS0FBSyxZQUFZLFFBQ2hCLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsV0FBVTtTQUFnQixVQUFVO1NBQU0sZUFBZSxLQUFLLFNBQVMsS0FBSyxFQUFFO21CQUFHO1FBRS9GOzs7O2dCQUVQOzs7Ozs7TUFDSDtRQW5CSyxLQUFLOzs7O1lBbUJWLENBQ0w7SUFDQzs7Ozs7R0FFQzs7Ozs7VUFFUjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTm90aWZpY2F0aW9uQ2VudGVyLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0ICcuL05vdGlmaWNhdGlvbkNlbnRlci5jc3MnXG5cbnR5cGUgTE1TTm90aWZpY2F0aW9uID0ge1xuICBpZDogbnVtYmVyXG4gIGV2ZW50X3R5cGU6IHN0cmluZ1xuICB0aXRsZTogc3RyaW5nXG4gIG1lc3NhZ2U6IHN0cmluZ1xuICBjb3Vyc2VfaWQ6IG51bWJlciB8IG51bGxcbiAgYXNzaWdubWVudF9pZDogbnVtYmVyIHwgbnVsbFxuICBhdHRlbXB0X2lkOiBudW1iZXIgfCBudWxsXG4gIGNyZWF0ZWRfYXQ6IHN0cmluZ1xuICByZWFkX2F0OiBzdHJpbmcgfCBudWxsXG59XG5cbnR5cGUgUHJvcHMgPSB7XG4gIHRva2VuOiBzdHJpbmdcbiAgb25PcGVuQXNzaWdubWVudDogKGNvdXJzZUlkOiBudW1iZXIpID0+IHZvaWRcbn1cblxuYXN5bmMgZnVuY3Rpb24gcmVxdWVzdEpTT048VD4ocGF0aDogc3RyaW5nLCB0b2tlbjogc3RyaW5nLCBtZXRob2QgPSAnR0VUJyk6IFByb21pc2U8VD4ge1xuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHBhdGgsIHtcbiAgICBtZXRob2QsXG4gICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9LFxuICB9KVxuICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGBOb3RpZmljYXRpb25zIHJlcXVlc3QgZmFpbGVkICgke3Jlc3BvbnNlLnN0YXR1c30pLmApXG4gIH1cbiAgcmV0dXJuIHJlc3BvbnNlLmpzb24oKSBhcyBQcm9taXNlPFQ+XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE5vdGlmaWNhdGlvbkNlbnRlcih7IHRva2VuLCBvbk9wZW5Bc3NpZ25tZW50IH06IFByb3BzKSB7XG4gIGNvbnN0IFtvcGVuLCBzZXRPcGVuXSA9IHVzZVN0YXRlKGZhbHNlKVxuICBjb25zdCBbbm90aWZpY2F0aW9ucywgc2V0Tm90aWZpY2F0aW9uc10gPSB1c2VTdGF0ZTxMTVNOb3RpZmljYXRpb25bXT4oW10pXG4gIGNvbnN0IFt1bnJlYWQsIHNldFVucmVhZF0gPSB1c2VTdGF0ZSgwKVxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW2J1c3ksIHNldEJ1c3ldID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpXG5cbiAgY29uc3QgcmVmcmVzaCA9IHVzZUNhbGxiYWNrKGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBbaXRlbXMsIGNvdW50XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgIHJlcXVlc3RKU09OPExNU05vdGlmaWNhdGlvbltdPignL2FwaS9ub3RpZmljYXRpb25zLz9saW1pdD0yMCcsIHRva2VuKSxcbiAgICAgIHJlcXVlc3RKU09OPHsgdW5yZWFkX2NvdW50OiBudW1iZXIgfT4oJy9hcGkvbm90aWZpY2F0aW9ucy91bnJlYWQtY291bnQnLCB0b2tlbiksXG4gICAgXSlcbiAgICBzZXROb3RpZmljYXRpb25zKGl0ZW1zKVxuICAgIHNldFVucmVhZChjb3VudC51bnJlYWRfY291bnQpXG4gIH0sIFt0b2tlbl0pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsZXQgYWN0aXZlID0gdHJ1ZVxuICAgIGNvbnN0IHN5bmMgPSBhc3luYyAoKSA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBbaXRlbXMsIGNvdW50XSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgICAgICByZXF1ZXN0SlNPTjxMTVNOb3RpZmljYXRpb25bXT4oJy9hcGkvbm90aWZpY2F0aW9ucy8/bGltaXQ9MjAnLCB0b2tlbiksXG4gICAgICAgICAgcmVxdWVzdEpTT048eyB1bnJlYWRfY291bnQ6IG51bWJlciB9PignL2FwaS9ub3RpZmljYXRpb25zL3VucmVhZC1jb3VudCcsIHRva2VuKSxcbiAgICAgICAgXSlcbiAgICAgICAgaWYgKGFjdGl2ZSkge1xuICAgICAgICAgIHNldE5vdGlmaWNhdGlvbnMoaXRlbXMpXG4gICAgICAgICAgc2V0VW5yZWFkKGNvdW50LnVucmVhZF9jb3VudClcbiAgICAgICAgICBzZXRFcnJvcignJylcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCB7XG4gICAgICAgIGlmIChhY3RpdmUpIHNldEVycm9yKCdDb3VsZCBub3QgbG9hZCBub3RpZmljYXRpb25zLicpXG4gICAgICB9XG4gICAgfVxuICAgIHZvaWQgc3luYygpXG4gICAgY29uc3QgdGltZXIgPSB3aW5kb3cuc2V0SW50ZXJ2YWwoKCkgPT4gdm9pZCBzeW5jKCksIDMwMDAwKVxuICAgIHJldHVybiAoKSA9PiB7IGFjdGl2ZSA9IGZhbHNlOyB3aW5kb3cuY2xlYXJJbnRlcnZhbCh0aW1lcikgfVxuICB9LCBbdG9rZW5dKVxuXG4gIGFzeW5jIGZ1bmN0aW9uIG1hcmtSZWFkKGlkOiBudW1iZXIpIHtcbiAgICBzZXRCdXN5KHRydWUpXG4gICAgc2V0RXJyb3IoJycpXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHJlcXVlc3RKU09OPExNU05vdGlmaWNhdGlvbj4oYC9hcGkvbm90aWZpY2F0aW9ucy8ke2lkfS9yZWFkYCwgdG9rZW4sICdQQVRDSCcpXG4gICAgICBhd2FpdCByZWZyZXNoKClcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyciBpbnN0YW5jZW9mIEVycm9yID8gZXJyLm1lc3NhZ2UgOiAnQ291bGQgbm90IG1hcmsgbm90aWZpY2F0aW9uIGFzIHJlYWQuJylcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0QnVzeShmYWxzZSlcbiAgICB9XG4gIH1cblxuICBhc3luYyBmdW5jdGlvbiBtYXJrQWxsUmVhZCgpIHtcbiAgICBzZXRCdXN5KHRydWUpXG4gICAgc2V0RXJyb3IoJycpXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHJlcXVlc3RKU09OPHsgdW5yZWFkX2NvdW50OiBudW1iZXIgfT4oJy9hcGkvbm90aWZpY2F0aW9ucy9yZWFkLWFsbCcsIHRva2VuLCAnUEFUQ0gnKVxuICAgICAgYXdhaXQgcmVmcmVzaCgpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ0NvdWxkIG5vdCBtYXJrIGFsbCBhcyByZWFkLicpXG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIHNldEJ1c3koZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZnVuY3Rpb24gb3BlbkFzc2lnbm1lbnQoaXRlbTogTE1TTm90aWZpY2F0aW9uKSB7XG4gICAgaWYgKGl0ZW0uY291cnNlX2lkID09PSBudWxsKSByZXR1cm5cbiAgICBzZXRMb2FkaW5nKHRydWUpXG4gICAgaWYgKGl0ZW0ucmVhZF9hdCA9PT0gbnVsbCkge1xuICAgICAgYXdhaXQgbWFya1JlYWQoaXRlbS5pZClcbiAgICB9XG4gICAgc2V0T3BlbihmYWxzZSlcbiAgICBzZXRMb2FkaW5nKGZhbHNlKVxuICAgIG9uT3BlbkFzc2lnbm1lbnQoaXRlbS5jb3Vyc2VfaWQpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibG1zLW5vdGlmaWNhdGlvbi1jZW50ZXJcIj5cbiAgICAgIDxidXR0b25cbiAgICAgICAgY2xhc3NOYW1lPVwibG1zLW5vdGlmaWNhdGlvbi10b2dnbGVcIlxuICAgICAgICB0eXBlPVwiYnV0dG9uXCJcbiAgICAgICAgYXJpYS1leHBhbmRlZD17b3Blbn1cbiAgICAgICAgYXJpYS1jb250cm9scz1cImxtcy1ub3RpZmljYXRpb24tcGFuZWxcIlxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBzZXRPcGVuKHZhbHVlID0+ICF2YWx1ZSl9XG4gICAgICA+XG4gICAgICAgIE5vdGlmaWNhdGlvbnN7dW5yZWFkID4gMCA/IGAgKCR7dW5yZWFkfSlgIDogJyd9XG4gICAgICA8L2J1dHRvbj5cblxuICAgICAge29wZW4gJiYgKFxuICAgICAgICA8c2VjdGlvbiBpZD1cImxtcy1ub3RpZmljYXRpb24tcGFuZWxcIiBjbGFzc05hbWU9XCJsbXMtbm90aWZpY2F0aW9uLXBhbmVsXCIgYXJpYS1sYWJlbD1cIk5vdGlmaWNhdGlvbnNcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxtcy1ub3RpZmljYXRpb24taGVhZGluZ1wiPlxuICAgICAgICAgICAgPGgzPk5vdGlmaWNhdGlvbnM8L2gzPlxuICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiIG9uQ2xpY2s9eygpID0+IHZvaWQgbWFya0FsbFJlYWQoKX0gZGlzYWJsZWQ9e2J1c3kgfHwgdW5yZWFkID09PSAwfT5cbiAgICAgICAgICAgICAgTWFyayBhbGwgYXMgcmVhZFxuICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAge2Vycm9yICYmIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cImVycm9yXCI+e2Vycm9yfTwvcD59XG4gICAgICAgICAge25vdGlmaWNhdGlvbnMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibG1zLW5vdGlmaWNhdGlvbi1lbXB0eVwiPk5vIG5vdGlmaWNhdGlvbnMgeWV0LjwvcD5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPHVsIGNsYXNzTmFtZT1cImxtcy1ub3RpZmljYXRpb24tbGlzdFwiPlxuICAgICAgICAgICAgICB7bm90aWZpY2F0aW9ucy5tYXAoaXRlbSA9PiAoXG4gICAgICAgICAgICAgICAgPGxpIGtleT17aXRlbS5pZH0gY2xhc3NOYW1lPXtgbG1zLW5vdGlmaWNhdGlvbi1pdGVtICR7aXRlbS5yZWFkX2F0ID09PSBudWxsID8gJ3VucmVhZCcgOiAnJ31gfT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG1zLW5vdGlmaWNhdGlvbi1pdGVtLXRpdGxlXCI+XG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e2l0ZW0udGl0bGV9PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLnJlYWRfYXQgPT09IG51bGwgJiYgPHNwYW4gY2xhc3NOYW1lPVwibG1zLW5vdGlmaWNhdGlvbi1kb3RcIiBhcmlhLWxhYmVsPVwiVW5yZWFkXCIgLz59XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxwPntpdGVtLm1lc3NhZ2V9PC9wPlxuICAgICAgICAgICAgICAgICAgPHNtYWxsPntuZXcgRGF0ZShpdGVtLmNyZWF0ZWRfYXQpLnRvTG9jYWxlU3RyaW5nKCl9PC9zbWFsbD5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibG1zLW5vdGlmaWNhdGlvbi1hY3Rpb25zXCI+XG4gICAgICAgICAgICAgICAgICAgIHtpdGVtLmNvdXJzZV9pZCAhPT0gbnVsbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgZGlzYWJsZWQ9e2xvYWRpbmcgfHwgYnVzeX0gb25DbGljaz17KCkgPT4gdm9pZCBvcGVuQXNzaWdubWVudChpdGVtKX0+XG4gICAgICAgICAgICAgICAgICAgICAgICBWaWV3IGFzc2lnbm1lbnRcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgICAgICAgICAge2l0ZW0ucmVhZF9hdCA9PT0gbnVsbCAmJiAoXG4gICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiIGRpc2FibGVkPXtidXN5fSBvbkNsaWNrPXsoKSA9PiB2b2lkIG1hcmtSZWFkKGl0ZW0uaWQpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIE1hcmsgcmVhZFxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPC9saT5cbiAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICA8L3VsPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gIClcbn1cbiJdfQ==