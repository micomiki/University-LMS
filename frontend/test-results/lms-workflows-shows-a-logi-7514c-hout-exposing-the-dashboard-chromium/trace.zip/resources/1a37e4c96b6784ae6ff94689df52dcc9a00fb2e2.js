import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AutomaticAttendanceReport.tsx");const useCallback = __vite__cjsImport0_react["useCallback"]; const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AutomaticAttendanceReport.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
export default function AutomaticAttendanceReport({ meetingId, token }) {
	_s();
	const [rows, setRows] = useState([]);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState("");
	const loadReport = useCallback(async () => {
		setLoading(true);
		setError("");
		try {
			const response = await fetch(`/api/attendance-tracking/meetings/${meetingId}/report`, { headers: { Authorization: `Bearer ${token}` } });
			if (!response.ok) {
				throw new Error(`Report request failed (${response.status}).`);
			}
			const data = await response.json();
			setRows(data);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to load report.");
		} finally {
			setLoading(false);
		}
	}, [meetingId, token]);
	useEffect(() => {
		void loadReport();
	}, [loadReport]);
	function formatTime(value) {
		return value ? new Date(value).toLocaleString() : "—";
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "attendance-manager",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "attendance-header",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Automatic Attendance Report" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 74,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Calculated from classroom connection sessions." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 75,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 73,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					onClick: () => void loadReport(),
					disabled: loading,
					children: "Refresh Report"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 78,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 72,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "error",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 87,
				columnNumber: 17
			}, this),
			loading && /* @__PURE__ */ _jsxDEV("p", { children: "Loading report..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 89,
				columnNumber: 19
			}, this),
			!loading && rows.length === 0 && /* @__PURE__ */ _jsxDEV("p", { children: "No enrolled students found." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 92,
				columnNumber: 9
			}, this),
			rows.length > 0 && /* @__PURE__ */ _jsxDEV("div", {
				className: "attendance-table-wrapper",
				children: /* @__PURE__ */ _jsxDEV("table", {
					className: "attendance-table",
					children: [/* @__PURE__ */ _jsxDEV("thead", { children: /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("th", { children: "Student" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 100,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "First Joined" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 101,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Last Activity" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 102,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Minutes" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 103,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Participation" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 104,
							columnNumber: 17
						}, this),
						/* @__PURE__ */ _jsxDEV("th", { children: "Detected Status" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 105,
							columnNumber: 17
						}, this)
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 99,
						columnNumber: 15
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("tbody", { children: rows.map((student) => /* @__PURE__ */ _jsxDEV("tr", { children: [
						/* @__PURE__ */ _jsxDEV("td", { children: student.full_name }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 112,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: formatTime(student.first_joined_at) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 113,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: formatTime(student.last_activity_at) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 116,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: student.minutes_connected }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: [student.attendance_percent, "%"] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 19
						}, this),
						/* @__PURE__ */ _jsxDEV("td", { children: /* @__PURE__ */ _jsxDEV("span", {
							className: "attendance-status",
							children: student.detected_status.replace(/_/g, " ")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 122,
							columnNumber: 21
						}, this) }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 121,
							columnNumber: 19
						}, this)
					] }, student.student_id, true, {
						fileName: _jsxFileName,
						lineNumber: 111,
						columnNumber: 17
					}, this)) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 109,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 97,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 71,
		columnNumber: 5
	}, this);
}
_s(AutomaticAttendanceReport, "UP4w+ylw59QK8sNYT0CtYMthFeI=");
_c = AutomaticAttendanceReport;
var _c;
$RefreshReg$(_c, "AutomaticAttendanceReport");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AutomaticAttendanceReport.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AutomaticAttendanceReport.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AutomaticAttendanceReport.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AutomaticAttendanceReport.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxhQUFhLFdBQVcsZ0JBQWdCOzs7O0FBaUJqRCxlQUFlLFNBQVMsMEJBQTBCLEVBQ2hELFdBQ0EsU0FDUTs7Q0FDUixNQUFNLENBQUMsTUFBTSxXQUFXLFNBQXNCLENBQUMsQ0FBQztDQUNoRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUM1QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUVyQyxNQUFNLGFBQWEsWUFBWSxZQUFZO0VBQ3pDLFdBQVcsSUFBSTtFQUNmLFNBQVMsRUFBRTtFQUVYLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxNQUNyQixxQ0FBcUMsVUFBVSxVQUMvQyxFQUNFLFNBQVMsRUFDUCxlQUFlLFVBQVUsUUFDM0IsRUFDRixDQUNGO0dBRUEsSUFBSSxDQUFDLFNBQVMsSUFBSTtJQUNoQixNQUFNLElBQUksTUFDUiwwQkFBMEIsU0FBUyxPQUFPLEdBQzVDO0dBQ0Y7R0FFQSxNQUFNLE9BQW9CLE1BQU0sU0FBUyxLQUFLO0dBQzlDLFFBQVEsSUFBSTtFQUNkLFNBQVMsS0FBSztHQUNaLFNBQ0UsZUFBZSxRQUNYLElBQUksVUFDSix3QkFDTjtFQUNGLFVBQVU7R0FDUixXQUFXLEtBQUs7RUFDbEI7Q0FDRixHQUFHLENBQUMsV0FBVyxLQUFLLENBQUM7Q0FFckIsZ0JBQWdCO0VBQ2QsS0FBSyxXQUFXO0NBQ2xCLEdBQUcsQ0FBQyxVQUFVLENBQUM7Q0FFZixTQUFTLFdBQVcsT0FBc0I7RUFDeEMsT0FBTyxRQUNILElBQUksS0FBSyxLQUFLLENBQUMsQ0FBQyxlQUFlLElBQy9CO0NBQ047Q0FFQSxPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO1lBQW5CO0dBQ0Usd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksOEJBQStCOzs7O2NBQ25DLHdCQUFDLEtBQUQsWUFBRyxpREFBaUQ7Ozs7WUFDakQ7Ozs7Y0FFTCx3QkFBQyxVQUFEO0tBQ0UsTUFBSztLQUNMLGVBQWUsS0FBSyxXQUFXO0tBQy9CLFVBQVU7ZUFDWDtJQUVPOzs7O1lBQ0w7Ozs7OztHQUVKLFNBQVMsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBUztHQUFTOzs7OztHQUV4QyxXQUFXLHdCQUFDLEtBQUQsWUFBRyxvQkFBb0I7Ozs7O0dBRWxDLENBQUMsV0FBVyxLQUFLLFdBQVcsS0FDM0Isd0JBQUMsS0FBRCxZQUFHLDhCQUE4Qjs7Ozs7R0FHbEMsS0FBSyxTQUFTLEtBQ2Isd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FDYix3QkFBQyxTQUFEO0tBQU8sV0FBVTtlQUFqQixDQUNFLHdCQUFDLFNBQUQsWUFDRSx3QkFBQyxNQUFEO01BQ0Usd0JBQUMsTUFBRCxZQUFJLFVBQVc7Ozs7O01BQ2Ysd0JBQUMsTUFBRCxZQUFJLGVBQWdCOzs7OztNQUNwQix3QkFBQyxNQUFELFlBQUksZ0JBQWlCOzs7OztNQUNyQix3QkFBQyxNQUFELFlBQUksVUFBVzs7Ozs7TUFDZix3QkFBQyxNQUFELFlBQUksZ0JBQWlCOzs7OztNQUNyQix3QkFBQyxNQUFELFlBQUksa0JBQW1COzs7OztLQUNyQjs7OztjQUNDOzs7O2VBRVAsd0JBQUMsU0FBRCxZQUNHLEtBQUssS0FBSyxZQUNULHdCQUFDLE1BQUQ7TUFDRSx3QkFBQyxNQUFELFlBQUssUUFBUSxVQUFjOzs7OztNQUMzQix3QkFBQyxNQUFELFlBQ0csV0FBVyxRQUFRLGVBQWUsRUFDakM7Ozs7O01BQ0osd0JBQUMsTUFBRCxZQUNHLFdBQVcsUUFBUSxnQkFBZ0IsRUFDbEM7Ozs7O01BQ0osd0JBQUMsTUFBRCxZQUFLLFFBQVEsa0JBQXNCOzs7OztNQUNuQyx3QkFBQyxNQUFELGFBQUssUUFBUSxvQkFBbUIsR0FBSzs7Ozs7TUFDckMsd0JBQUMsTUFBRCxZQUNFLHdCQUFDLFFBQUQ7T0FBTSxXQUFVO2lCQUNiLFFBQVEsZ0JBQWdCLFFBQ3ZCLE1BQ0EsR0FDRjtNQUNJOzs7O2VBQ0o7Ozs7O0tBQ0YsS0FsQkssUUFBUTs7OztZQWtCYixDQUNMLEVBQ0k7Ozs7YUFDRjs7Ozs7O0dBQ0o7Ozs7O0VBRUE7Ozs7OztBQUViIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkF1dG9tYXRpY0F0dGVuZGFuY2VSZXBvcnQudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5cclxudHlwZSBSZXBvcnRSb3cgPSB7XHJcbiAgc3R1ZGVudF9pZDogbnVtYmVyXHJcbiAgZnVsbF9uYW1lOiBzdHJpbmdcclxuICBmaXJzdF9qb2luZWRfYXQ6IHN0cmluZyB8IG51bGxcclxuICBsYXN0X2FjdGl2aXR5X2F0OiBzdHJpbmcgfCBudWxsXHJcbiAgbWludXRlc19jb25uZWN0ZWQ6IG51bWJlclxyXG4gIGF0dGVuZGFuY2VfcGVyY2VudDogbnVtYmVyXHJcbiAgZGV0ZWN0ZWRfc3RhdHVzOiBzdHJpbmdcclxufVxyXG5cclxudHlwZSBQcm9wcyA9IHtcclxuICBtZWV0aW5nSWQ6IG51bWJlclxyXG4gIHRva2VuOiBzdHJpbmdcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXV0b21hdGljQXR0ZW5kYW5jZVJlcG9ydCh7XHJcbiAgbWVldGluZ0lkLFxyXG4gIHRva2VuLFxyXG59OiBQcm9wcykge1xyXG4gIGNvbnN0IFtyb3dzLCBzZXRSb3dzXSA9IHVzZVN0YXRlPFJlcG9ydFJvd1tdPihbXSlcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZShmYWxzZSlcclxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxyXG5cclxuICBjb25zdCBsb2FkUmVwb3J0ID0gdXNlQ2FsbGJhY2soYXN5bmMgKCkgPT4ge1xyXG4gICAgc2V0TG9hZGluZyh0cnVlKVxyXG4gICAgc2V0RXJyb3IoJycpXHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICBgL2FwaS9hdHRlbmRhbmNlLXRyYWNraW5nL21lZXRpbmdzLyR7bWVldGluZ0lkfS9yZXBvcnRgLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG5cclxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgICAgIGBSZXBvcnQgcmVxdWVzdCBmYWlsZWQgKCR7cmVzcG9uc2Uuc3RhdHVzfSkuYFxyXG4gICAgICAgIClcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgZGF0YTogUmVwb3J0Um93W10gPSBhd2FpdCByZXNwb25zZS5qc29uKClcclxuICAgICAgc2V0Um93cyhkYXRhKVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldEVycm9yKFxyXG4gICAgICAgIGVyciBpbnN0YW5jZW9mIEVycm9yXHJcbiAgICAgICAgICA/IGVyci5tZXNzYWdlXHJcbiAgICAgICAgICA6ICdVbmFibGUgdG8gbG9hZCByZXBvcnQuJ1xyXG4gICAgICApXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXRMb2FkaW5nKGZhbHNlKVxyXG4gICAgfVxyXG4gIH0sIFttZWV0aW5nSWQsIHRva2VuXSlcclxuXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIHZvaWQgbG9hZFJlcG9ydCgpXHJcbiAgfSwgW2xvYWRSZXBvcnRdKVxyXG5cclxuICBmdW5jdGlvbiBmb3JtYXRUaW1lKHZhbHVlOiBzdHJpbmcgfCBudWxsKSB7XHJcbiAgICByZXR1cm4gdmFsdWVcclxuICAgICAgPyBuZXcgRGF0ZSh2YWx1ZSkudG9Mb2NhbGVTdHJpbmcoKVxyXG4gICAgICA6ICfigJQnXHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYXR0ZW5kYW5jZS1tYW5hZ2VyXCI+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXR0ZW5kYW5jZS1oZWFkZXJcIj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGgzPkF1dG9tYXRpYyBBdHRlbmRhbmNlIFJlcG9ydDwvaDM+XHJcbiAgICAgICAgICA8cD5DYWxjdWxhdGVkIGZyb20gY2xhc3Nyb29tIGNvbm5lY3Rpb24gc2Vzc2lvbnMuPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgbG9hZFJlcG9ydCgpfVxyXG4gICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgUmVmcmVzaCBSZXBvcnRcclxuICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgPC9kaXY+XHJcblxyXG4gICAgICB7ZXJyb3IgJiYgPHAgY2xhc3NOYW1lPVwiZXJyb3JcIj57ZXJyb3J9PC9wPn1cclxuXHJcbiAgICAgIHtsb2FkaW5nICYmIDxwPkxvYWRpbmcgcmVwb3J0Li4uPC9wPn1cclxuXHJcbiAgICAgIHshbG9hZGluZyAmJiByb3dzLmxlbmd0aCA9PT0gMCAmJiAoXHJcbiAgICAgICAgPHA+Tm8gZW5yb2xsZWQgc3R1ZGVudHMgZm91bmQuPC9wPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge3Jvd3MubGVuZ3RoID4gMCAmJiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdHRlbmRhbmNlLXRhYmxlLXdyYXBwZXJcIj5cclxuICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJhdHRlbmRhbmNlLXRhYmxlXCI+XHJcbiAgICAgICAgICAgIDx0aGVhZD5cclxuICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICA8dGg+U3R1ZGVudDwvdGg+XHJcbiAgICAgICAgICAgICAgICA8dGg+Rmlyc3QgSm9pbmVkPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aD5MYXN0IEFjdGl2aXR5PC90aD5cclxuICAgICAgICAgICAgICAgIDx0aD5NaW51dGVzPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aD5QYXJ0aWNpcGF0aW9uPC90aD5cclxuICAgICAgICAgICAgICAgIDx0aD5EZXRlY3RlZCBTdGF0dXM8L3RoPlxyXG4gICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgIDwvdGhlYWQ+XHJcblxyXG4gICAgICAgICAgICA8dGJvZHk+XHJcbiAgICAgICAgICAgICAge3Jvd3MubWFwKChzdHVkZW50KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8dHIga2V5PXtzdHVkZW50LnN0dWRlbnRfaWR9PlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+e3N0dWRlbnQuZnVsbF9uYW1lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZD5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VGltZShzdHVkZW50LmZpcnN0X2pvaW5lZF9hdCl9XHJcbiAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgIDx0ZD5cclxuICAgICAgICAgICAgICAgICAgICB7Zm9ybWF0VGltZShzdHVkZW50Lmxhc3RfYWN0aXZpdHlfYXQpfVxyXG4gICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICA8dGQ+e3N0dWRlbnQubWludXRlc19jb25uZWN0ZWR9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkPntzdHVkZW50LmF0dGVuZGFuY2VfcGVyY2VudH0lPC90ZD5cclxuICAgICAgICAgICAgICAgICAgPHRkPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImF0dGVuZGFuY2Utc3RhdHVzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICB7c3R1ZGVudC5kZXRlY3RlZF9zdGF0dXMucmVwbGFjZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgL18vZyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgJyAnXHJcbiAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG4gICAgPC9zZWN0aW9uPlxyXG4gIClcclxufVxyXG4iXX0=