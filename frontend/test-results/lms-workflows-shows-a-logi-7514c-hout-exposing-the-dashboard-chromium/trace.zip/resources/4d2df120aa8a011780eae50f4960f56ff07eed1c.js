import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AssignmentGrading.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
import AssignmentProgressBadge from "/src/components/AssignmentProgress.tsx";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentGrading.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
async function getError(response) {
	const data = await response.json().catch(() => null);
	return typeof data?.detail === "string" ? data.detail : `Request failed (${response.status}).`;
}
export default function AssignmentGrading({ assignmentId, maxScore, token }) {
	_s();
	const [submissions, setSubmissions] = useState([]);
	const [drafts, setDrafts] = useState({});
	const [editingId, setEditingId] = useState(null);
	const [loading, setLoading] = useState(true);
	const [savingId, setSavingId] = useState(null);
	const [reloadKey, setReloadKey] = useState(0);
	const [error, setError] = useState("");
	const [message, setMessage] = useState("");
	useEffect(() => {
		const controller = new AbortController();
		async function loadSubmissions() {
			setLoading(true);
			setError("");
			setEditingId(null);
			try {
				const response = await fetch(`/api/submissions/assignments/${assignmentId}`, {
					headers: { Authorization: `Bearer ${token}` },
					signal: controller.signal
				});
				if (!response.ok) {
					throw new Error(await getError(response));
				}
				const data = await response.json();
				if (controller.signal.aborted) return;
				setSubmissions(data);
				const initialDrafts = {};
				for (const submission of data) {
					initialDrafts[submission.id] = {
						score: submission.score === null ? "" : String(submission.score),
						feedback: submission.feedback ?? ""
					};
				}
				setDrafts(initialDrafts);
			} catch (err) {
				if (!controller.signal.aborted) {
					setError(err instanceof Error ? err.message : "Unable to load submissions.");
				}
			} finally {
				if (!controller.signal.aborted) {
					setLoading(false);
				}
			}
		}
		void loadSubmissions();
		return () => controller.abort();
	}, [
		assignmentId,
		token,
		reloadKey
	]);
	function updateDraft(id, field, value) {
		setDrafts((previous) => ({
			...previous,
			[id]: {
				...previous[id] ?? {
					score: "",
					feedback: ""
				},
				[field]: value
			}
		}));
	}
	function toggleEditor(submission) {
		if (editingId === submission.id) {
			cancelEditing(submission);
			return;
		}
		setError("");
		setMessage("");
		setDrafts((previous) => ({
			...previous,
			[submission.id]: {
				score: submission.score === null ? "" : String(submission.score),
				feedback: submission.feedback ?? ""
			}
		}));
		setEditingId(submission.id);
	}
	function cancelEditing(submission) {
		setEditingId(null);
		setError("");
		setDrafts((previous) => ({
			...previous,
			[submission.id]: {
				score: submission.score === null ? "" : String(submission.score),
				feedback: submission.feedback ?? ""
			}
		}));
	}
	async function saveGrade(submission) {
		const draft = drafts[submission.id];
		const scoreText = draft?.score?.trim() ?? "";
		const score = Number(scoreText);
		const maximum = Number(maxScore);
		if (!scoreText || !Number.isFinite(score) || !Number.isFinite(maximum) || score < 0 || score > maximum) {
			setError(`Enter a score between 0 and ${maxScore}.`);
			return;
		}
		setSavingId(submission.id);
		setError("");
		setMessage("");
		try {
			const response = await fetch(`/api/submissions/${submission.id}/grade`, {
				method: "PUT",
				headers: {
					Authorization: `Bearer ${token}`,
					"Content-Type": "application/json"
				},
				body: JSON.stringify({
					score,
					feedback: draft.feedback.trim() || null
				})
			});
			if (!response.ok) {
				throw new Error(await getError(response));
			}
			const updated = await response.json();
			setSubmissions((previous) => previous.map((item) => item.id === updated.id ? updated : item));
			setEditingId(null);
			setMessage(`Grade saved for student #${submission.student_id}.`);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to save grade.");
		} finally {
			setSavingId(null);
		}
	}
	async function downloadFile(submission) {
		setError("");
		try {
			const response = await fetch(`/api/submissions/${submission.id}/download`, { headers: { Authorization: `Bearer ${token}` } });
			if (!response.ok) {
				throw new Error(await getError(response));
			}
			const blob = await response.blob();
			const url = URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.href = url;
			link.download = submission.original_filename || "submission";
			document.body.appendChild(link);
			link.click();
			link.remove();
			setTimeout(() => URL.revokeObjectURL(url), 1e3);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to download file.");
		}
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "grading-section",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "grading-header",
				children: [/* @__PURE__ */ _jsxDEV("h4", { children: "Student Submissions" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 285,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "btn-secondary",
					disabled: loading,
					onClick: () => setReloadKey((n) => n + 1),
					children: "Refresh"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 287,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 284,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 298,
				columnNumber: 9
			}, this),
			message && /* @__PURE__ */ _jsxDEV("p", {
				className: "success-message",
				role: "status",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 304,
				columnNumber: 9
			}, this),
			loading ? /* @__PURE__ */ _jsxDEV("p", { children: "Loading submissions..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 310,
				columnNumber: 9
			}, this) : submissions.length === 0 ? !error && /* @__PURE__ */ _jsxDEV("p", { children: "No students have submitted yet." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 312,
				columnNumber: 19
			}, this) : submissions.map((submission) => /* @__PURE__ */ _jsxDEV("article", {
				className: "grading-card",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grading-header",
						children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h4", { children: ["Student #", submission.student_id] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 321,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: [
							"Submitted:",
							" ",
							new Date(submission.submitted_at).toLocaleString()
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 325,
							columnNumber: 17
						}, this)] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 320,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV(AssignmentProgressBadge, { status: submission.score !== null ? "graded" : "under-review" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 333,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 319,
						columnNumber: 13
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "grading-response",
						children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Written Response" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 344,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: submission.text_response || "No written response." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 346,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 343,
						columnNumber: 13
					}, this),
					submission.original_filename && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", { children: [
						/* @__PURE__ */ _jsxDEV("strong", { children: "Attached File:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 356,
							columnNumber: 19
						}, this),
						" ",
						submission.original_filename
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 355,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "btn-secondary",
						onClick: () => void downloadFile(submission),
						children: "Download Submission"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 360,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 354,
						columnNumber: 15
					}, this),
					submission.score !== null && /* @__PURE__ */ _jsxDEV("div", {
						className: "submission-summary",
						children: [/* @__PURE__ */ _jsxDEV("p", { children: [
							/* @__PURE__ */ _jsxDEV("strong", { children: "Current Grade:" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 376,
								columnNumber: 19
							}, this),
							" ",
							submission.score,
							" / ",
							maxScore
						] }, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 375,
							columnNumber: 17
						}, this), submission.feedback && /* @__PURE__ */ _jsxDEV("div", {
							className: "assignment-feedback",
							children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Professor Feedback" }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 382,
								columnNumber: 21
							}, this), /* @__PURE__ */ _jsxDEV("p", { children: submission.feedback }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 383,
								columnNumber: 21
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 381,
							columnNumber: 19
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 374,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						className: "btn-secondary",
						disabled: savingId !== null,
						onClick: () => toggleEditor(submission),
						children: submission.score !== null ? "Update Grade" : "Grade Submission"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 390,
						columnNumber: 13
					}, this),
					editingId === submission.id && /* @__PURE__ */ _jsxDEV("div", {
						className: "grading-form",
						children: [
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: `score-${submission.id}`,
								children: [
									"Score (maximum ",
									maxScore,
									")"
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 404,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("input", {
								id: `score-${submission.id}`,
								type: "number",
								min: "0",
								max: Number(maxScore),
								step: "0.01",
								value: drafts[submission.id]?.score ?? "",
								onChange: (event) => updateDraft(submission.id, "score", event.target.value)
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 410,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("label", {
								htmlFor: `feedback-${submission.id}`,
								children: "Professor Feedback"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 428,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("textarea", {
								id: `feedback-${submission.id}`,
								rows: 4,
								value: drafts[submission.id]?.feedback ?? "",
								onChange: (event) => updateDraft(submission.id, "feedback", event.target.value),
								placeholder: "Write feedback..."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 434,
								columnNumber: 17
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "grading-actions",
								children: [/* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									disabled: savingId !== null,
									onClick: () => void saveGrade(submission),
									children: savingId === submission.id ? "Saving..." : "Save Grade"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 451,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "btn-secondary",
									disabled: savingId !== null,
									onClick: () => cancelEditing(submission),
									children: "Cancel"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 463,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 450,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 403,
						columnNumber: 15
					}, this)
				]
			}, submission.id, true, {
				fileName: _jsxFileName,
				lineNumber: 315,
				columnNumber: 11
			}, this))
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 283,
		columnNumber: 5
	}, this);
}
_s(AssignmentGrading, "oaAv37ss6u7vgWJvO/LKlLkWpOY=");
_c = AssignmentGrading;
var _c;
$RefreshReg$(_c, "AssignmentGrading");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AssignmentGrading.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentGrading.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentGrading.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentGrading.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxPQUFPLDZCQUE2Qjs7OztBQXdCcEMsZUFBZSxTQUFTLFVBQXFDO0NBQzNELE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSyxDQUFDLENBQUMsWUFBWSxJQUFJO0NBRW5ELE9BQU8sT0FBTyxNQUFNLFdBQVcsV0FDM0IsS0FBSyxTQUNMLG1CQUFtQixTQUFTLE9BQU87QUFDekM7QUFFQSxlQUFlLFNBQVMsa0JBQWtCLEVBQ3hDLGNBQ0EsVUFDQSxTQUNROztDQUNSLE1BQU0sQ0FBQyxhQUFhLGtCQUNsQixTQUF1QixDQUFDLENBQUM7Q0FFM0IsTUFBTSxDQUFDLFFBQVEsYUFDYixTQUFnQyxDQUFDLENBQUM7Q0FFcEMsTUFBTSxDQUFDLFdBQVcsZ0JBQ2hCLFNBQXdCLElBQUk7Q0FFOUIsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLFVBQVUsZUFDZixTQUF3QixJQUFJO0NBRTlCLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLENBQUM7Q0FDNUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEVBQUU7Q0FFekMsZ0JBQWdCO0VBQ2QsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0VBRXZDLGVBQWUsa0JBQWtCO0dBQy9CLFdBQVcsSUFBSTtHQUNmLFNBQVMsRUFBRTtHQUNYLGFBQWEsSUFBSTtHQUVqQixJQUFJO0lBQ0YsTUFBTSxXQUFXLE1BQU0sTUFDckIsZ0NBQWdDLGdCQUNoQztLQUNFLFNBQVMsRUFDUCxlQUFlLFVBQVUsUUFDM0I7S0FDQSxRQUFRLFdBQVc7SUFDckIsQ0FDRjtJQUVBLElBQUksQ0FBQyxTQUFTLElBQUk7S0FDaEIsTUFBTSxJQUFJLE1BQU0sTUFBTSxTQUFTLFFBQVEsQ0FBQztJQUMxQztJQUVBLE1BQU0sT0FBcUIsTUFBTSxTQUFTLEtBQUs7SUFFL0MsSUFBSSxXQUFXLE9BQU8sU0FBUztJQUUvQixlQUFlLElBQUk7SUFFbkIsTUFBTSxnQkFBdUMsQ0FBQztJQUU5QyxLQUFLLE1BQU0sY0FBYyxNQUFNO0tBQzdCLGNBQWMsV0FBVyxNQUFNO01BQzdCLE9BQ0UsV0FBVyxVQUFVLE9BQ2pCLEtBQ0EsT0FBTyxXQUFXLEtBQUs7TUFDN0IsVUFBVSxXQUFXLFlBQVk7S0FDbkM7SUFDRjtJQUVBLFVBQVUsYUFBYTtHQUN6QixTQUFTLEtBQUs7SUFDWixJQUFJLENBQUMsV0FBVyxPQUFPLFNBQVM7S0FDOUIsU0FDRSxlQUFlLFFBQ1gsSUFBSSxVQUNKLDZCQUNOO0lBQ0Y7R0FDRixVQUFVO0lBQ1IsSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUFTO0tBQzlCLFdBQVcsS0FBSztJQUNsQjtHQUNGO0VBQ0Y7RUFFQSxLQUFLLGdCQUFnQjtFQUVyQixhQUFhLFdBQVcsTUFBTTtDQUNoQyxHQUFHO0VBQUM7RUFBYztFQUFPO0NBQVMsQ0FBQztDQUVuQyxTQUFTLFlBQ1AsSUFDQSxPQUNBLE9BQ0E7RUFDQSxXQUFXLGNBQWM7R0FDdkIsR0FBRztJQUNGLEtBQUs7SUFDSixHQUFJLFNBQVMsT0FBTztLQUNsQixPQUFPO0tBQ1AsVUFBVTtJQUNaO0tBQ0MsUUFBUTtHQUNYO0VBQ0YsRUFBRTtDQUNKO0NBRUEsU0FBUyxhQUFhLFlBQXdCO0VBQzVDLElBQUksY0FBYyxXQUFXLElBQUk7R0FDL0IsY0FBYyxVQUFVO0dBQ3hCO0VBQ0Y7RUFFQSxTQUFTLEVBQUU7RUFDWCxXQUFXLEVBQUU7RUFFYixXQUFXLGNBQWM7R0FDdkIsR0FBRztJQUNGLFdBQVcsS0FBSztJQUNmLE9BQ0UsV0FBVyxVQUFVLE9BQ2pCLEtBQ0EsT0FBTyxXQUFXLEtBQUs7SUFDN0IsVUFBVSxXQUFXLFlBQVk7R0FDbkM7RUFDRixFQUFFO0VBRUYsYUFBYSxXQUFXLEVBQUU7Q0FDNUI7Q0FFQSxTQUFTLGNBQWMsWUFBd0I7RUFDN0MsYUFBYSxJQUFJO0VBQ2pCLFNBQVMsRUFBRTtFQUVYLFdBQVcsY0FBYztHQUN2QixHQUFHO0lBQ0YsV0FBVyxLQUFLO0lBQ2YsT0FDRSxXQUFXLFVBQVUsT0FDakIsS0FDQSxPQUFPLFdBQVcsS0FBSztJQUM3QixVQUFVLFdBQVcsWUFBWTtHQUNuQztFQUNGLEVBQUU7Q0FDSjtDQUVBLGVBQWUsVUFBVSxZQUF3QjtFQUMvQyxNQUFNLFFBQVEsT0FBTyxXQUFXO0VBRWhDLE1BQU0sWUFBWSxPQUFPLE9BQU8sS0FBSyxLQUFLO0VBQzFDLE1BQU0sUUFBUSxPQUFPLFNBQVM7RUFDOUIsTUFBTSxVQUFVLE9BQU8sUUFBUTtFQUUvQixJQUNFLENBQUMsYUFDRCxDQUFDLE9BQU8sU0FBUyxLQUFLLEtBQ3RCLENBQUMsT0FBTyxTQUFTLE9BQU8sS0FDeEIsUUFBUSxLQUNSLFFBQVEsU0FDUjtHQUNBLFNBQ0UsK0JBQStCLFNBQVMsRUFDMUM7R0FDQTtFQUNGO0VBRUEsWUFBWSxXQUFXLEVBQUU7RUFDekIsU0FBUyxFQUFFO0VBQ1gsV0FBVyxFQUFFO0VBRWIsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQ3JCLG9CQUFvQixXQUFXLEdBQUcsU0FDbEM7SUFDRSxRQUFRO0lBQ1IsU0FBUztLQUNQLGVBQWUsVUFBVTtLQUN6QixnQkFBZ0I7SUFDbEI7SUFDQSxNQUFNLEtBQUssVUFBVTtLQUNuQjtLQUNBLFVBQVUsTUFBTSxTQUFTLEtBQUssS0FBSztJQUNyQyxDQUFDO0dBQ0gsQ0FDRjtHQUVBLElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsTUFBTSxJQUFJLE1BQU0sTUFBTSxTQUFTLFFBQVEsQ0FBQztHQUMxQztHQUVBLE1BQU0sVUFBc0IsTUFBTSxTQUFTLEtBQUs7R0FFaEQsZ0JBQWdCLGFBQ2QsU0FBUyxLQUFLLFNBQ1osS0FBSyxPQUFPLFFBQVEsS0FBSyxVQUFVLElBQ3JDLENBQ0Y7R0FFQSxhQUFhLElBQUk7R0FFakIsV0FDRSw0QkFBNEIsV0FBVyxXQUFXLEVBQ3BEO0VBQ0YsU0FBUyxLQUFLO0dBQ1osU0FDRSxlQUFlLFFBQ1gsSUFBSSxVQUNKLHVCQUNOO0VBQ0YsVUFBVTtHQUNSLFlBQVksSUFBSTtFQUNsQjtDQUNGO0NBRUEsZUFBZSxhQUFhLFlBQXdCO0VBQ2xELFNBQVMsRUFBRTtFQUVYLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxNQUNyQixvQkFBb0IsV0FBVyxHQUFHLFlBQ2xDLEVBQ0UsU0FBUyxFQUNQLGVBQWUsVUFBVSxRQUMzQixFQUNGLENBQ0Y7R0FFQSxJQUFJLENBQUMsU0FBUyxJQUFJO0lBQ2hCLE1BQU0sSUFBSSxNQUFNLE1BQU0sU0FBUyxRQUFRLENBQUM7R0FDMUM7R0FFQSxNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUs7R0FDakMsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7R0FFcEMsTUFBTSxPQUFPLFNBQVMsY0FBYyxHQUFHO0dBQ3ZDLEtBQUssT0FBTztHQUNaLEtBQUssV0FDSCxXQUFXLHFCQUFxQjtHQUVsQyxTQUFTLEtBQUssWUFBWSxJQUFJO0dBQzlCLEtBQUssTUFBTTtHQUNYLEtBQUssT0FBTztHQUVaLGlCQUFpQixJQUFJLGdCQUFnQixHQUFHLEdBQUcsR0FBSTtFQUNqRCxTQUFTLEtBQUs7R0FDWixTQUNFLGVBQWUsUUFDWCxJQUFJLFVBQ0osMEJBQ047RUFDRjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxXQUFEO0VBQVMsV0FBVTtZQUFuQjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxNQUFELFlBQUksc0JBQXVCOzs7O2NBRTNCLHdCQUFDLFVBQUQ7S0FDRSxNQUFLO0tBQ0wsV0FBVTtLQUNWLFVBQVU7S0FDVixlQUFlLGNBQWMsTUFBTSxJQUFJLENBQUM7ZUFDekM7SUFFTzs7OztZQUNMOzs7Ozs7R0FFSixTQUNDLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO0lBQVEsTUFBSztjQUN2QjtHQUNBOzs7OztHQUdKLFdBQ0Msd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBa0IsTUFBSztjQUNqQztHQUNBOzs7OztHQUdKLFVBQ0Msd0JBQUMsS0FBRCxZQUFHLHlCQUF5Qjs7OztjQUMxQixZQUFZLFdBQVcsSUFDekIsQ0FBQyxTQUFTLHdCQUFDLEtBQUQsWUFBRyxrQ0FBa0M7Ozs7Y0FFL0MsWUFBWSxLQUFLLGVBQ2Ysd0JBQUMsV0FBRDtJQUVFLFdBQVU7Y0FGWjtLQUlFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQsYUFBSSxhQUNRLFdBQVcsVUFDbkI7Ozs7Z0JBRUosd0JBQUMsS0FBRDtPQUFHO09BQ1U7T0FDVixJQUFJLEtBQ0gsV0FBVyxZQUNiLENBQUMsQ0FBQyxlQUFlO01BQ2hCOzs7O2NBQ0E7Ozs7Z0JBRUwsd0JBQUMseUJBQUQsRUFDWixRQUNFLFdBQVcsVUFBVSxPQUNqQixXQUNBLGVBRVA7Ozs7Y0FDZ0I7Ozs7OztLQUdMLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRCxZQUFRLG1CQUF3Qjs7OztnQkFFaEMsd0JBQUMsS0FBRCxZQUNHLFdBQVcsaUJBQ1YsdUJBQ0Q7Ozs7Y0FDQTs7Ozs7O0tBR0osV0FBVyxxQkFDVix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtNQUNFLHdCQUFDLFVBQUQsWUFBUSxpQkFBc0I7Ozs7O01BQUU7TUFDL0IsV0FBVztLQUNYOzs7O2VBRUgsd0JBQUMsVUFBRDtNQUNFLE1BQUs7TUFDTCxXQUFVO01BQ1YsZUFDRSxLQUFLLGFBQWEsVUFBVTtnQkFFL0I7S0FFTzs7OzthQUNMOzs7OztLQUlOLFdBQVcsVUFBVSxRQUNwQix3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLEtBQUQ7T0FDRSx3QkFBQyxVQUFELFlBQVEsaUJBQXNCOzs7OztPQUFFO09BQy9CLFdBQVc7T0FBTTtPQUFJO01BQ3JCOzs7O2dCQUVGLFdBQVcsWUFDVix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFBZixDQUNFLHdCQUFDLFVBQUQsWUFBUSxxQkFBMEI7Ozs7aUJBQ2xDLHdCQUFDLEtBQUQsWUFBSSxXQUFXLFNBQVk7Ozs7ZUFDeEI7Ozs7O2NBRUo7Ozs7OztLQUlQLHdCQUFDLFVBQUQ7TUFDRSxNQUFLO01BQ0wsV0FBVTtNQUNWLFVBQVUsYUFBYTtNQUN2QixlQUFlLGFBQWEsVUFBVTtnQkFFckMsV0FBVyxVQUFVLE9BQ2xCLGlCQUNBO0tBQ0U7Ozs7O0tBR1AsY0FBYyxXQUFXLE1BQ3hCLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmO09BQ0Usd0JBQUMsU0FBRDtRQUNFLFNBQVMsU0FBUyxXQUFXO2tCQUQvQjtTQUVDO1NBQ2lCO1NBQVM7UUFDcEI7Ozs7OztPQUVQLHdCQUFDLFNBQUQ7UUFDRSxJQUFJLFNBQVMsV0FBVztRQUN4QixNQUFLO1FBQ0wsS0FBSTtRQUNKLEtBQUssT0FBTyxRQUFRO1FBQ3BCLE1BQUs7UUFDTCxPQUNFLE9BQU8sV0FBVyxHQUFHLEVBQUUsU0FBUztRQUVsQyxXQUFXLFVBQ1QsWUFDRSxXQUFXLElBQ1gsU0FDQSxNQUFNLE9BQU8sS0FDZjtPQUVIOzs7OztPQUVELHdCQUFDLFNBQUQ7UUFDRSxTQUFTLFlBQVksV0FBVztrQkFDakM7T0FFTTs7Ozs7T0FFUCx3QkFBQyxZQUFEO1FBQ0UsSUFBSSxZQUFZLFdBQVc7UUFDM0IsTUFBTTtRQUNOLE9BQ0UsT0FBTyxXQUFXLEdBQUcsRUFBRSxZQUFZO1FBRXJDLFdBQVcsVUFDVCxZQUNFLFdBQVcsSUFDWCxZQUNBLE1BQU0sT0FBTyxLQUNmO1FBRUYsYUFBWTtPQUNiOzs7OztPQUVELHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsVUFBRDtTQUNFLE1BQUs7U0FDTCxVQUFVLGFBQWE7U0FDdkIsZUFDRSxLQUFLLFVBQVUsVUFBVTttQkFHMUIsYUFBYSxXQUFXLEtBQ3JCLGNBQ0E7UUFDRTs7OztrQkFFUix3QkFBQyxVQUFEO1NBQ0UsTUFBSztTQUNMLFdBQVU7U0FDVixVQUFVLGFBQWE7U0FDdkIsZUFDRSxjQUFjLFVBQVU7bUJBRTNCO1FBRU87Ozs7Z0JBQ0w7Ozs7OztNQUNGOzs7Ozs7SUFFQTtNQWhLRixXQUFXOzs7O1VBZ0tULENBQ1Y7RUFFSTs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXNzaWdubWVudEdyYWRpbmcudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCBBc3NpZ25tZW50UHJvZ3Jlc3NCYWRnZSBmcm9tICcuL0Fzc2lnbm1lbnRQcm9ncmVzcydcclxudHlwZSBTdWJtaXNzaW9uID0ge1xyXG4gIGlkOiBudW1iZXJcclxuICBhc3NpZ25tZW50X2lkOiBudW1iZXJcclxuICBzdHVkZW50X2lkOiBudW1iZXJcclxuICB0ZXh0X3Jlc3BvbnNlOiBzdHJpbmcgfCBudWxsXHJcbiAgb3JpZ2luYWxfZmlsZW5hbWU6IHN0cmluZyB8IG51bGxcclxuICBzdWJtaXR0ZWRfYXQ6IHN0cmluZ1xyXG4gIHNjb3JlOiBudW1iZXIgfCBzdHJpbmcgfCBudWxsXHJcbiAgZmVlZGJhY2s6IHN0cmluZyB8IG51bGxcclxuICBncmFkZWRfYXQ6IHN0cmluZyB8IG51bGxcclxufVxyXG5cclxudHlwZSBEcmFmdCA9IHtcclxuICBzY29yZTogc3RyaW5nXHJcbiAgZmVlZGJhY2s6IHN0cmluZ1xyXG59XHJcblxyXG50eXBlIFByb3BzID0ge1xyXG4gIGFzc2lnbm1lbnRJZDogbnVtYmVyXHJcbiAgbWF4U2NvcmU6IG51bWJlciB8IHN0cmluZ1xyXG4gIHRva2VuOiBzdHJpbmdcclxufVxyXG5cclxuYXN5bmMgZnVuY3Rpb24gZ2V0RXJyb3IocmVzcG9uc2U6IFJlc3BvbnNlKTogUHJvbWlzZTxzdHJpbmc+IHtcclxuICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+IG51bGwpXHJcblxyXG4gIHJldHVybiB0eXBlb2YgZGF0YT8uZGV0YWlsID09PSAnc3RyaW5nJ1xyXG4gICAgPyBkYXRhLmRldGFpbFxyXG4gICAgOiBgUmVxdWVzdCBmYWlsZWQgKCR7cmVzcG9uc2Uuc3RhdHVzfSkuYFxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBBc3NpZ25tZW50R3JhZGluZyh7XHJcbiAgYXNzaWdubWVudElkLFxyXG4gIG1heFNjb3JlLFxyXG4gIHRva2VuLFxyXG59OiBQcm9wcykge1xyXG4gIGNvbnN0IFtzdWJtaXNzaW9ucywgc2V0U3VibWlzc2lvbnNdID1cclxuICAgIHVzZVN0YXRlPFN1Ym1pc3Npb25bXT4oW10pXHJcblxyXG4gIGNvbnN0IFtkcmFmdHMsIHNldERyYWZ0c10gPVxyXG4gICAgdXNlU3RhdGU8UmVjb3JkPG51bWJlciwgRHJhZnQ+Pih7fSlcclxuXHJcbiAgY29uc3QgW2VkaXRpbmdJZCwgc2V0RWRpdGluZ0lkXSA9XHJcbiAgICB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKVxyXG5cclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKVxyXG4gIGNvbnN0IFtzYXZpbmdJZCwgc2V0U2F2aW5nSWRdID1cclxuICAgIHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpXHJcblxyXG4gIGNvbnN0IFtyZWxvYWRLZXksIHNldFJlbG9hZEtleV0gPSB1c2VTdGF0ZSgwKVxyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpXHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gbG9hZFN1Ym1pc3Npb25zKCkge1xyXG4gICAgICBzZXRMb2FkaW5nKHRydWUpXHJcbiAgICAgIHNldEVycm9yKCcnKVxyXG4gICAgICBzZXRFZGl0aW5nSWQobnVsbClcclxuXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgIGAvYXBpL3N1Ym1pc3Npb25zL2Fzc2lnbm1lbnRzLyR7YXNzaWdubWVudElkfWAsXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCxcclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcblxyXG4gICAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihhd2FpdCBnZXRFcnJvcihyZXNwb25zZSkpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBjb25zdCBkYXRhOiBTdWJtaXNzaW9uW10gPSBhd2FpdCByZXNwb25zZS5qc29uKClcclxuXHJcbiAgICAgICAgaWYgKGNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHJldHVyblxyXG5cclxuICAgICAgICBzZXRTdWJtaXNzaW9ucyhkYXRhKVxyXG5cclxuICAgICAgICBjb25zdCBpbml0aWFsRHJhZnRzOiBSZWNvcmQ8bnVtYmVyLCBEcmFmdD4gPSB7fVxyXG5cclxuICAgICAgICBmb3IgKGNvbnN0IHN1Ym1pc3Npb24gb2YgZGF0YSkge1xyXG4gICAgICAgICAgaW5pdGlhbERyYWZ0c1tzdWJtaXNzaW9uLmlkXSA9IHtcclxuICAgICAgICAgICAgc2NvcmU6XHJcbiAgICAgICAgICAgICAgc3VibWlzc2lvbi5zY29yZSA9PT0gbnVsbFxyXG4gICAgICAgICAgICAgICAgPyAnJ1xyXG4gICAgICAgICAgICAgICAgOiBTdHJpbmcoc3VibWlzc2lvbi5zY29yZSksXHJcbiAgICAgICAgICAgIGZlZWRiYWNrOiBzdWJtaXNzaW9uLmZlZWRiYWNrID8/ICcnLFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgc2V0RHJhZnRzKGluaXRpYWxEcmFmdHMpXHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGlmICghY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xyXG4gICAgICAgICAgc2V0RXJyb3IoXHJcbiAgICAgICAgICAgIGVyciBpbnN0YW5jZW9mIEVycm9yXHJcbiAgICAgICAgICAgICAgPyBlcnIubWVzc2FnZVxyXG4gICAgICAgICAgICAgIDogJ1VuYWJsZSB0byBsb2FkIHN1Ym1pc3Npb25zLidcclxuICAgICAgICAgIClcclxuICAgICAgICB9XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgaWYgKCFjb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSB7XHJcbiAgICAgICAgICBzZXRMb2FkaW5nKGZhbHNlKVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHZvaWQgbG9hZFN1Ym1pc3Npb25zKClcclxuXHJcbiAgICByZXR1cm4gKCkgPT4gY29udHJvbGxlci5hYm9ydCgpXHJcbiAgfSwgW2Fzc2lnbm1lbnRJZCwgdG9rZW4sIHJlbG9hZEtleV0pXHJcblxyXG4gIGZ1bmN0aW9uIHVwZGF0ZURyYWZ0KFxyXG4gICAgaWQ6IG51bWJlcixcclxuICAgIGZpZWxkOiBrZXlvZiBEcmFmdCxcclxuICAgIHZhbHVlOiBzdHJpbmdcclxuICApIHtcclxuICAgIHNldERyYWZ0cygocHJldmlvdXMpID0+ICh7XHJcbiAgICAgIC4uLnByZXZpb3VzLFxyXG4gICAgICBbaWRdOiB7XHJcbiAgICAgICAgLi4uKHByZXZpb3VzW2lkXSA/PyB7XHJcbiAgICAgICAgICBzY29yZTogJycsXHJcbiAgICAgICAgICBmZWVkYmFjazogJycsXHJcbiAgICAgICAgfSksXHJcbiAgICAgICAgW2ZpZWxkXTogdmFsdWUsXHJcbiAgICAgIH0sXHJcbiAgICB9KSlcclxuICB9XHJcblxyXG4gIGZ1bmN0aW9uIHRvZ2dsZUVkaXRvcihzdWJtaXNzaW9uOiBTdWJtaXNzaW9uKSB7XHJcbiAgICBpZiAoZWRpdGluZ0lkID09PSBzdWJtaXNzaW9uLmlkKSB7XHJcbiAgICAgIGNhbmNlbEVkaXRpbmcoc3VibWlzc2lvbilcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcblxyXG4gICAgc2V0RXJyb3IoJycpXHJcbiAgICBzZXRNZXNzYWdlKCcnKVxyXG5cclxuICAgIHNldERyYWZ0cygocHJldmlvdXMpID0+ICh7XHJcbiAgICAgIC4uLnByZXZpb3VzLFxyXG4gICAgICBbc3VibWlzc2lvbi5pZF06IHtcclxuICAgICAgICBzY29yZTpcclxuICAgICAgICAgIHN1Ym1pc3Npb24uc2NvcmUgPT09IG51bGxcclxuICAgICAgICAgICAgPyAnJ1xyXG4gICAgICAgICAgICA6IFN0cmluZyhzdWJtaXNzaW9uLnNjb3JlKSxcclxuICAgICAgICBmZWVkYmFjazogc3VibWlzc2lvbi5mZWVkYmFjayA/PyAnJyxcclxuICAgICAgfSxcclxuICAgIH0pKVxyXG5cclxuICAgIHNldEVkaXRpbmdJZChzdWJtaXNzaW9uLmlkKVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gY2FuY2VsRWRpdGluZyhzdWJtaXNzaW9uOiBTdWJtaXNzaW9uKSB7XHJcbiAgICBzZXRFZGl0aW5nSWQobnVsbClcclxuICAgIHNldEVycm9yKCcnKVxyXG5cclxuICAgIHNldERyYWZ0cygocHJldmlvdXMpID0+ICh7XHJcbiAgICAgIC4uLnByZXZpb3VzLFxyXG4gICAgICBbc3VibWlzc2lvbi5pZF06IHtcclxuICAgICAgICBzY29yZTpcclxuICAgICAgICAgIHN1Ym1pc3Npb24uc2NvcmUgPT09IG51bGxcclxuICAgICAgICAgICAgPyAnJ1xyXG4gICAgICAgICAgICA6IFN0cmluZyhzdWJtaXNzaW9uLnNjb3JlKSxcclxuICAgICAgICBmZWVkYmFjazogc3VibWlzc2lvbi5mZWVkYmFjayA/PyAnJyxcclxuICAgICAgfSxcclxuICAgIH0pKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gc2F2ZUdyYWRlKHN1Ym1pc3Npb246IFN1Ym1pc3Npb24pIHtcclxuICAgIGNvbnN0IGRyYWZ0ID0gZHJhZnRzW3N1Ym1pc3Npb24uaWRdXHJcblxyXG4gICAgY29uc3Qgc2NvcmVUZXh0ID0gZHJhZnQ/LnNjb3JlPy50cmltKCkgPz8gJydcclxuICAgIGNvbnN0IHNjb3JlID0gTnVtYmVyKHNjb3JlVGV4dClcclxuICAgIGNvbnN0IG1heGltdW0gPSBOdW1iZXIobWF4U2NvcmUpXHJcblxyXG4gICAgaWYgKFxyXG4gICAgICAhc2NvcmVUZXh0IHx8XHJcbiAgICAgICFOdW1iZXIuaXNGaW5pdGUoc2NvcmUpIHx8XHJcbiAgICAgICFOdW1iZXIuaXNGaW5pdGUobWF4aW11bSkgfHxcclxuICAgICAgc2NvcmUgPCAwIHx8XHJcbiAgICAgIHNjb3JlID4gbWF4aW11bVxyXG4gICAgKSB7XHJcbiAgICAgIHNldEVycm9yKFxyXG4gICAgICAgIGBFbnRlciBhIHNjb3JlIGJldHdlZW4gMCBhbmQgJHttYXhTY29yZX0uYFxyXG4gICAgICApXHJcbiAgICAgIHJldHVyblxyXG4gICAgfVxyXG5cclxuICAgIHNldFNhdmluZ0lkKHN1Ym1pc3Npb24uaWQpXHJcbiAgICBzZXRFcnJvcignJylcclxuICAgIHNldE1lc3NhZ2UoJycpXHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICBgL2FwaS9zdWJtaXNzaW9ucy8ke3N1Ym1pc3Npb24uaWR9L2dyYWRlYCxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBtZXRob2Q6ICdQVVQnLFxyXG4gICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCxcclxuICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgIHNjb3JlLFxyXG4gICAgICAgICAgICBmZWVkYmFjazogZHJhZnQuZmVlZGJhY2sudHJpbSgpIHx8IG51bGwsXHJcbiAgICAgICAgICB9KSxcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuXHJcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYXdhaXQgZ2V0RXJyb3IocmVzcG9uc2UpKVxyXG4gICAgICB9XHJcblxyXG4gICAgICBjb25zdCB1cGRhdGVkOiBTdWJtaXNzaW9uID0gYXdhaXQgcmVzcG9uc2UuanNvbigpXHJcblxyXG4gICAgICBzZXRTdWJtaXNzaW9ucygocHJldmlvdXMpID0+XHJcbiAgICAgICAgcHJldmlvdXMubWFwKChpdGVtKSA9PlxyXG4gICAgICAgICAgaXRlbS5pZCA9PT0gdXBkYXRlZC5pZCA/IHVwZGF0ZWQgOiBpdGVtXHJcbiAgICAgICAgKVxyXG4gICAgICApXHJcblxyXG4gICAgICBzZXRFZGl0aW5nSWQobnVsbClcclxuXHJcbiAgICAgIHNldE1lc3NhZ2UoXHJcbiAgICAgICAgYEdyYWRlIHNhdmVkIGZvciBzdHVkZW50ICMke3N1Ym1pc3Npb24uc3R1ZGVudF9pZH0uYFxyXG4gICAgICApXHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJyb3IoXHJcbiAgICAgICAgZXJyIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICAgID8gZXJyLm1lc3NhZ2VcclxuICAgICAgICAgIDogJ1VuYWJsZSB0byBzYXZlIGdyYWRlLidcclxuICAgICAgKVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0U2F2aW5nSWQobnVsbClcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGRvd25sb2FkRmlsZShzdWJtaXNzaW9uOiBTdWJtaXNzaW9uKSB7XHJcbiAgICBzZXRFcnJvcignJylcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgIGAvYXBpL3N1Ym1pc3Npb25zLyR7c3VibWlzc2lvbi5pZH0vZG93bmxvYWRgLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG5cclxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihhd2FpdCBnZXRFcnJvcihyZXNwb25zZSkpXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXNwb25zZS5ibG9iKClcclxuICAgICAgY29uc3QgdXJsID0gVVJMLmNyZWF0ZU9iamVjdFVSTChibG9iKVxyXG5cclxuICAgICAgY29uc3QgbGluayA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKVxyXG4gICAgICBsaW5rLmhyZWYgPSB1cmxcclxuICAgICAgbGluay5kb3dubG9hZCA9XHJcbiAgICAgICAgc3VibWlzc2lvbi5vcmlnaW5hbF9maWxlbmFtZSB8fCAnc3VibWlzc2lvbidcclxuXHJcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluaylcclxuICAgICAgbGluay5jbGljaygpXHJcbiAgICAgIGxpbmsucmVtb3ZlKClcclxuXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4gVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpLCAxMDAwKVxyXG4gICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgIHNldEVycm9yKFxyXG4gICAgICAgIGVyciBpbnN0YW5jZW9mIEVycm9yXHJcbiAgICAgICAgICA/IGVyci5tZXNzYWdlXHJcbiAgICAgICAgICA6ICdVbmFibGUgdG8gZG93bmxvYWQgZmlsZS4nXHJcbiAgICAgIClcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJncmFkaW5nLXNlY3Rpb25cIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmFkaW5nLWhlYWRlclwiPlxyXG4gICAgICAgIDxoND5TdHVkZW50IFN1Ym1pc3Npb25zPC9oND5cclxuXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBjbGFzc05hbWU9XCJidG4tc2Vjb25kYXJ5XCJcclxuICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxyXG4gICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0UmVsb2FkS2V5KChuKSA9PiBuICsgMSl9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgUmVmcmVzaFxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cclxuICAgICAgICAgIHtlcnJvcn1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7bWVzc2FnZSAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwic3VjY2Vzcy1tZXNzYWdlXCIgcm9sZT1cInN0YXR1c1wiPlxyXG4gICAgICAgICAge21lc3NhZ2V9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge2xvYWRpbmcgPyAoXHJcbiAgICAgICAgPHA+TG9hZGluZyBzdWJtaXNzaW9ucy4uLjwvcD5cclxuICAgICAgKSA6IHN1Ym1pc3Npb25zLmxlbmd0aCA9PT0gMCA/IChcclxuICAgICAgICAhZXJyb3IgJiYgPHA+Tm8gc3R1ZGVudHMgaGF2ZSBzdWJtaXR0ZWQgeWV0LjwvcD5cclxuICAgICAgKSA6IChcclxuICAgICAgICBzdWJtaXNzaW9ucy5tYXAoKHN1Ym1pc3Npb24pID0+IChcclxuICAgICAgICAgIDxhcnRpY2xlXHJcbiAgICAgICAgICAgIGtleT17c3VibWlzc2lvbi5pZH1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiZ3JhZGluZy1jYXJkXCJcclxuICAgICAgICAgID5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmFkaW5nLWhlYWRlclwiPlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8aDQ+XHJcbiAgICAgICAgICAgICAgICAgIFN0dWRlbnQgI3tzdWJtaXNzaW9uLnN0dWRlbnRfaWR9XHJcbiAgICAgICAgICAgICAgICA8L2g0PlxyXG5cclxuICAgICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAgICBTdWJtaXR0ZWQ6eycgJ31cclxuICAgICAgICAgICAgICAgICAge25ldyBEYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgIHN1Ym1pc3Npb24uc3VibWl0dGVkX2F0XHJcbiAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPEFzc2lnbm1lbnRQcm9ncmVzc0JhZGdlXHJcbiAgc3RhdHVzPXtcclxuICAgIHN1Ym1pc3Npb24uc2NvcmUgIT09IG51bGxcclxuICAgICAgPyAnZ3JhZGVkJ1xyXG4gICAgICA6ICd1bmRlci1yZXZpZXcnXHJcbiAgfVxyXG4vPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBTdHVkZW50J3Mgc3VibWl0dGVkIHJlc3BvbnNlICovfVxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyYWRpbmctcmVzcG9uc2VcIj5cclxuICAgICAgICAgICAgICA8c3Ryb25nPldyaXR0ZW4gUmVzcG9uc2U8L3N0cm9uZz5cclxuXHJcbiAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICB7c3VibWlzc2lvbi50ZXh0X3Jlc3BvbnNlIHx8XHJcbiAgICAgICAgICAgICAgICAgICdObyB3cml0dGVuIHJlc3BvbnNlLid9XHJcbiAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBBdHRhY2hlZCBmaWxlICovfVxyXG4gICAgICAgICAgICB7c3VibWlzc2lvbi5vcmlnaW5hbF9maWxlbmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAgICA8c3Ryb25nPkF0dGFjaGVkIEZpbGU6PC9zdHJvbmc+eycgJ31cclxuICAgICAgICAgICAgICAgICAge3N1Ym1pc3Npb24ub3JpZ2luYWxfZmlsZW5hbWV9XHJcbiAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgdm9pZCBkb3dubG9hZEZpbGUoc3VibWlzc2lvbilcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICBEb3dubG9hZCBTdWJtaXNzaW9uXHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgIHsvKiBSZWFkLW9ubHkgZ3JhZGUgc3VtbWFyeSAqL31cclxuICAgICAgICAgICAge3N1Ym1pc3Npb24uc2NvcmUgIT09IG51bGwgJiYgKFxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VibWlzc2lvbi1zdW1tYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICAgICAgPHN0cm9uZz5DdXJyZW50IEdyYWRlOjwvc3Ryb25nPnsnICd9XHJcbiAgICAgICAgICAgICAgICAgIHtzdWJtaXNzaW9uLnNjb3JlfSAvIHttYXhTY29yZX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICAgICAgICB7c3VibWlzc2lvbi5mZWVkYmFjayAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXNzaWdubWVudC1mZWVkYmFja1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+UHJvZmVzc29yIEZlZWRiYWNrPC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgICAgPHA+e3N1Ym1pc3Npb24uZmVlZGJhY2t9PC9wPlxyXG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7LyogR3JhZGUgLyBVcGRhdGUgR3JhZGUgYnV0dG9uICovfVxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZ0lkICE9PSBudWxsfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHRvZ2dsZUVkaXRvcihzdWJtaXNzaW9uKX1cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIHtzdWJtaXNzaW9uLnNjb3JlICE9PSBudWxsXHJcbiAgICAgICAgICAgICAgICA/ICdVcGRhdGUgR3JhZGUnXHJcbiAgICAgICAgICAgICAgICA6ICdHcmFkZSBTdWJtaXNzaW9uJ31cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICB7LyogR3JhZGluZyBmb3JtIGhpZGRlbiBieSBkZWZhdWx0ICovfVxyXG4gICAgICAgICAgICB7ZWRpdGluZ0lkID09PSBzdWJtaXNzaW9uLmlkICYmIChcclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyYWRpbmctZm9ybVwiPlxyXG4gICAgICAgICAgICAgICAgPGxhYmVsXHJcbiAgICAgICAgICAgICAgICAgIGh0bWxGb3I9e2BzY29yZS0ke3N1Ym1pc3Npb24uaWR9YH1cclxuICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgU2NvcmUgKG1heGltdW0ge21heFNjb3JlfSlcclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIGlkPXtgc2NvcmUtJHtzdWJtaXNzaW9uLmlkfWB9XHJcbiAgICAgICAgICAgICAgICAgIHR5cGU9XCJudW1iZXJcIlxyXG4gICAgICAgICAgICAgICAgICBtaW49XCIwXCJcclxuICAgICAgICAgICAgICAgICAgbWF4PXtOdW1iZXIobWF4U2NvcmUpfVxyXG4gICAgICAgICAgICAgICAgICBzdGVwPVwiMC4wMVwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXtcclxuICAgICAgICAgICAgICAgICAgICBkcmFmdHNbc3VibWlzc2lvbi5pZF0/LnNjb3JlID8/ICcnXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT5cclxuICAgICAgICAgICAgICAgICAgICB1cGRhdGVEcmFmdChcclxuICAgICAgICAgICAgICAgICAgICAgIHN1Ym1pc3Npb24uaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICAnc2NvcmUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgZXZlbnQudGFyZ2V0LnZhbHVlXHJcbiAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgIDxsYWJlbFxyXG4gICAgICAgICAgICAgICAgICBodG1sRm9yPXtgZmVlZGJhY2stJHtzdWJtaXNzaW9uLmlkfWB9XHJcbiAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgIFByb2Zlc3NvciBGZWVkYmFja1xyXG4gICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuXHJcbiAgICAgICAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICAgICAgaWQ9e2BmZWVkYmFjay0ke3N1Ym1pc3Npb24uaWR9YH1cclxuICAgICAgICAgICAgICAgICAgcm93cz17NH1cclxuICAgICAgICAgICAgICAgICAgdmFsdWU9e1xyXG4gICAgICAgICAgICAgICAgICAgIGRyYWZ0c1tzdWJtaXNzaW9uLmlkXT8uZmVlZGJhY2sgPz8gJydcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50KSA9PlxyXG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZURyYWZ0KFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3VibWlzc2lvbi5pZCxcclxuICAgICAgICAgICAgICAgICAgICAgICdmZWVkYmFjaycsXHJcbiAgICAgICAgICAgICAgICAgICAgICBldmVudC50YXJnZXQudmFsdWVcclxuICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJXcml0ZSBmZWVkYmFjay4uLlwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JhZGluZy1hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxidXR0b25cclxuICAgICAgICAgICAgICAgICAgICB0eXBlPVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZD17c2F2aW5nSWQgIT09IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT5cclxuICAgICAgICAgICAgICAgICAgICAgIHZvaWQgc2F2ZUdyYWRlKHN1Ym1pc3Npb24pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAge3NhdmluZ0lkID09PSBzdWJtaXNzaW9uLmlkXHJcbiAgICAgICAgICAgICAgICAgICAgICA/ICdTYXZpbmcuLi4nXHJcbiAgICAgICAgICAgICAgICAgICAgICA6ICdTYXZlIEdyYWRlJ31cclxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3NhdmluZ0lkICE9PSBudWxsfVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICBjYW5jZWxFZGl0aW5nKHN1Ym1pc3Npb24pXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICl9XHJcbiAgICAgICAgICA8L2FydGljbGU+XHJcbiAgICAgICAgKSlcclxuICAgICAgKX1cclxuICAgIDwvc2VjdGlvbj5cclxuICApXHJcbn1cclxuIl19