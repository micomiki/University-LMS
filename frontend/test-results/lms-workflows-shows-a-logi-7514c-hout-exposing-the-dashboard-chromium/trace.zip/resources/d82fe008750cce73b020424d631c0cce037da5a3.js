import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CreateAssignmentForm.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CreateAssignmentForm.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
export default function CreateAssignmentForm({ courseId, token, onCreated }) {
	_s();
	const [open, setOpen] = useState(false);
	const [title, setTitle] = useState("");
	const [description, setDescription] = useState("");
	const [instructions, setInstructions] = useState("");
	const [dueAt, setDueAt] = useState("");
	const [maxScore, setMaxScore] = useState("100");
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState("");
	const [message, setMessage] = useState("");
	const [allowMultipleSubmissions, setAllowMultipleSubmissions] = useState(false);
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		setMessage("");
		const deadline = new Date(dueAt);
		const score = Number(maxScore);
		if (!title.trim()) {
			setError("Assignment title is required.");
			return;
		}
		if (!Number.isFinite(deadline.getTime()) || deadline <= new Date()) {
			setError("Select a future deadline.");
			return;
		}
		if (!Number.isFinite(score) || score <= 0) {
			setError("Maximum score must be greater than zero.");
			return;
		}
		setLoading(true);
		try {
			const response = await fetch(`/api/assignments/courses/${courseId}`, {
				method: "POST",
				headers: {
					Authorization: `Bearer ${token}`,
					"Content-Type": "application/json"
				},
				body: JSON.stringify({
					title: title.trim(),
					description: description.trim() || null,
					instructions: instructions.trim() || null,
					due_at: deadline.toISOString(),
					max_score: score,
					allow_multiple_submissions: allowMultipleSubmissions
				})
			});
			if (!response.ok) {
				const data = await response.json().catch(() => null);
				throw new Error(typeof data?.detail === "string" ? data.detail : `Unable to create assignment (${response.status}).`);
			}
			setTitle("");
			setDescription("");
			setInstructions("");
			setDueAt("");
			setMaxScore("100");
			setAllowMultipleSubmissions(false);
			setOpen(false);
			setMessage("Assignment created successfully.");
			onCreated();
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to create assignment.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "create-assignment",
		children: [
			!open && /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: () => {
					setOpen(true);
					setMessage("");
				},
				children: "+ Create Assignment"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 110,
				columnNumber: 9
			}, this),
			message && /* @__PURE__ */ _jsxDEV("p", {
				className: "success-message",
				role: "status",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 122,
				columnNumber: 9
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 128,
				columnNumber: 9
			}, this),
			open && /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit,
				children: [
					/* @__PURE__ */ _jsxDEV("h3", { children: "Create New Assignment" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 135,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "new-assignment-title",
						children: "Title"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 137,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "new-assignment-title",
						required: true,
						maxLength: 200,
						value: title,
						onChange: (e) => setTitle(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 140,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "new-assignment-description",
						children: "Description"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 148,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("textarea", {
						id: "new-assignment-description",
						rows: 3,
						value: description,
						onChange: (e) => setDescription(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 151,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "new-assignment-instructions",
						children: "Instructions"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 158,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("textarea", {
						id: "new-assignment-instructions",
						rows: 5,
						value: instructions,
						onChange: (e) => setInstructions(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 161,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "new-assignment-deadline",
						children: "Submission Deadline"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 168,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "new-assignment-deadline",
						type: "datetime-local",
						value: dueAt,
						onChange: (e) => setDueAt(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 171,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "new-assignment-score",
						children: "Maximum Score"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 179,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						id: "new-assignment-score",
						type: "number",
						min: "0.01",
						step: "0.01",
						value: maxScore,
						onChange: (e) => setMaxScore(e.target.value),
						required: true
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 182,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("fieldset", {
						className: "submission-policy",
						children: [/* @__PURE__ */ _jsxDEV("legend", { children: "Submission Policy" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 194,
							columnNumber: 3
						}, this), /* @__PURE__ */ _jsxDEV("div", {
							className: "policy-options",
							children: [/* @__PURE__ */ _jsxDEV("label", {
								className: `policy-option ${!allowMultipleSubmissions ? "selected" : ""}`,
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "radio",
									name: "submissionPolicy",
									value: "single",
									checked: !allowMultipleSubmissions,
									onChange: () => setAllowMultipleSubmissions(false)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 202,
									columnNumber: 7
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "policy-option-content",
									children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Single Submission" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 213,
										columnNumber: 9
									}, this), /* @__PURE__ */ _jsxDEV("small", { children: "One active submission. Students can edit or remove it before the deadline." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 214,
										columnNumber: 9
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 212,
									columnNumber: 7
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 197,
								columnNumber: 5
							}, this), /* @__PURE__ */ _jsxDEV("label", {
								className: `policy-option ${allowMultipleSubmissions ? "selected" : ""}`,
								children: [/* @__PURE__ */ _jsxDEV("input", {
									type: "radio",
									name: "submissionPolicy",
									value: "multiple",
									checked: allowMultipleSubmissions,
									onChange: () => setAllowMultipleSubmissions(true)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 226,
									columnNumber: 7
								}, this), /* @__PURE__ */ _jsxDEV("span", {
									className: "policy-option-content",
									children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Multiple Submissions" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 237,
										columnNumber: 9
									}, this), /* @__PURE__ */ _jsxDEV("small", { children: "Students can submit additional attempts until the deadline. Earlier attempts are preserved." }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 238,
										columnNumber: 9
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 236,
									columnNumber: 7
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 221,
								columnNumber: 5
							}, this)]
						}, void 0, true, {
							fileName: _jsxFileName,
							lineNumber: 196,
							columnNumber: 3
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 193,
						columnNumber: 1
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "submission-actions",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: loading,
							children: loading ? "Creating..." : "Create Assignment"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 249,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "btn-secondary",
							disabled: loading,
							onClick: () => {
								setOpen(false);
								setError("");
							},
							children: "Cancel"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 255,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 248,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 134,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 108,
		columnNumber: 5
	}, this);
}
_s(CreateAssignmentForm, "1C0QACFfdAs4qIYyuVs4TXM09Hs=");
_c = CreateAssignmentForm;
var _c;
$RefreshReg$(_c, "CreateAssignmentForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/CreateAssignmentForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CreateAssignmentForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CreateAssignmentForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CreateAssignmentForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxnQkFBZ0M7Ozs7QUFRekMsZUFBZSxTQUFTLHFCQUFxQixFQUMzQyxVQUNBLE9BQ0EsYUFDUTs7Q0FDUixNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsS0FBSztDQUN0QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsYUFBYSxrQkFBa0IsU0FBUyxFQUFFO0NBQ2pELE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLEVBQUU7Q0FDbkQsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEtBQUs7Q0FDOUMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7Q0FDNUMsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLEVBQUU7Q0FDekMsTUFBTSxDQUFDLDBCQUEwQiwrQkFDakMsU0FBUyxLQUFLO0NBQ2QsZUFBZSxhQUNiLE9BQ0E7RUFDQSxNQUFNLGVBQWU7RUFDckIsU0FBUyxFQUFFO0VBQ1gsV0FBVyxFQUFFO0VBRWIsTUFBTSxXQUFXLElBQUksS0FBSyxLQUFLO0VBQy9CLE1BQU0sUUFBUSxPQUFPLFFBQVE7RUFFN0IsSUFBSSxDQUFDLE1BQU0sS0FBSyxHQUFHO0dBQ2pCLFNBQVMsK0JBQStCO0dBQ3hDO0VBQ0Y7RUFFQSxJQUNFLENBQUMsT0FBTyxTQUFTLFNBQVMsUUFBUSxDQUFDLEtBQ25DLFlBQVksSUFBSSxLQUFLLEdBQ3JCO0dBQ0EsU0FBUywyQkFBMkI7R0FDcEM7RUFDRjtFQUVBLElBQUksQ0FBQyxPQUFPLFNBQVMsS0FBSyxLQUFLLFNBQVMsR0FBRztHQUN6QyxTQUFTLDBDQUEwQztHQUNuRDtFQUNGO0VBRUEsV0FBVyxJQUFJO0VBRWYsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLE1BQ3JCLDRCQUE0QixZQUM1QjtJQUNFLFFBQVE7SUFDUixTQUFTO0tBQ1AsZUFBZSxVQUFVO0tBQ3pCLGdCQUFnQjtJQUNsQjtJQUNBLE1BQU0sS0FBSyxVQUFVO0tBQ25CLE9BQU8sTUFBTSxLQUFLO0tBQ2xCLGFBQWEsWUFBWSxLQUFLLEtBQUs7S0FDbkMsY0FBYyxhQUFhLEtBQUssS0FBSztLQUNyQyxRQUFRLFNBQVMsWUFBWTtLQUM3QixXQUFXO0tBQ1gsNEJBQTRCO0lBQzlCLENBQUM7R0FDSCxDQUNGO0dBRUEsSUFBSSxDQUFDLFNBQVMsSUFBSTtJQUNoQixNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUssQ0FBQyxDQUFDLFlBQVksSUFBSTtJQUVuRCxNQUFNLElBQUksTUFDUixPQUFPLE1BQU0sV0FBVyxXQUNwQixLQUFLLFNBQ0wsZ0NBQWdDLFNBQVMsT0FBTyxHQUN0RDtHQUNGO0dBRUEsU0FBUyxFQUFFO0dBQ1gsZUFBZSxFQUFFO0dBQ2pCLGdCQUFnQixFQUFFO0dBQ2xCLFNBQVMsRUFBRTtHQUNYLFlBQVksS0FBSztHQUNqQiw0QkFBNEIsS0FBSztHQUNqQyxRQUFRLEtBQUs7R0FDYixXQUFXLGtDQUFrQztHQUU3QyxVQUFVO0VBQ1osU0FBUyxLQUFLO0dBQ1osU0FDRSxlQUFlLFFBQ1gsSUFBSSxVQUNKLDhCQUNOO0VBQ0YsVUFBVTtHQUNSLFdBQVcsS0FBSztFQUNsQjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0csQ0FBQyxRQUNBLHdCQUFDLFVBQUQ7SUFDRSxNQUFLO0lBQ0wsZUFBZTtLQUNiLFFBQVEsSUFBSTtLQUNaLFdBQVcsRUFBRTtJQUNmO2NBQ0Q7R0FFTzs7Ozs7R0FHVCxXQUNDLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO0lBQWtCLE1BQUs7Y0FDakM7R0FDQTs7Ozs7R0FHSixTQUNDLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO0lBQVEsTUFBSztjQUN2QjtHQUNBOzs7OztHQUdKLFFBQ0Msd0JBQUMsUUFBRDtJQUFNLFVBQVU7Y0FBaEI7S0FDRSx3QkFBQyxNQUFELFlBQUksd0JBQXlCOzs7OztLQUU3Qix3QkFBQyxTQUFEO01BQU8sU0FBUTtnQkFBdUI7S0FFL0I7Ozs7O0tBQ1Asd0JBQUMsU0FBRDtNQUNFLElBQUc7TUFDSDtNQUNBLFdBQVc7TUFDWCxPQUFPO01BQ1AsV0FBVyxNQUFNLFNBQVMsRUFBRSxPQUFPLEtBQUs7S0FDekM7Ozs7O0tBRUQsd0JBQUMsU0FBRDtNQUFPLFNBQVE7Z0JBQTZCO0tBRXJDOzs7OztLQUNQLHdCQUFDLFlBQUQ7TUFDRSxJQUFHO01BQ0gsTUFBTTtNQUNOLE9BQU87TUFDUCxXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBSztLQUMvQzs7Ozs7S0FFRCx3QkFBQyxTQUFEO01BQU8sU0FBUTtnQkFBOEI7S0FFdEM7Ozs7O0tBQ1Asd0JBQUMsWUFBRDtNQUNFLElBQUc7TUFDSCxNQUFNO01BQ04sT0FBTztNQUNQLFdBQVcsTUFBTSxnQkFBZ0IsRUFBRSxPQUFPLEtBQUs7S0FDaEQ7Ozs7O0tBRUQsd0JBQUMsU0FBRDtNQUFPLFNBQVE7Z0JBQTBCO0tBRWxDOzs7OztLQUNQLHdCQUFDLFNBQUQ7TUFDRSxJQUFHO01BQ0gsTUFBSztNQUNMLE9BQU87TUFDUCxXQUFXLE1BQU0sU0FBUyxFQUFFLE9BQU8sS0FBSztNQUN4QztLQUNEOzs7OztLQUVELHdCQUFDLFNBQUQ7TUFBTyxTQUFRO2dCQUF1QjtLQUUvQjs7Ozs7S0FDUCx3QkFBQyxTQUFEO01BQ0UsSUFBRztNQUNILE1BQUs7TUFDTCxLQUFJO01BQ0osTUFBSztNQUNMLE9BQU87TUFDUCxXQUFXLE1BQU0sWUFBWSxFQUFFLE9BQU8sS0FBSztNQUMzQztLQUNEOzs7OztLQUdYLHdCQUFDLFlBQUQ7TUFBVSxXQUFVO2dCQUFwQixDQUNFLHdCQUFDLFVBQUQsWUFBUSxvQkFBeUI7Ozs7Z0JBRWpDLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUFmLENBQ0Usd0JBQUMsU0FBRDtRQUNFLFdBQVcsaUJBQ1QsQ0FBQywyQkFBMkIsYUFBYTtrQkFGN0MsQ0FLRSx3QkFBQyxTQUFEO1NBQ0UsTUFBSztTQUNMLE1BQUs7U0FDTCxPQUFNO1NBQ04sU0FBUyxDQUFDO1NBQ1YsZ0JBQ0UsNEJBQTRCLEtBQUs7UUFFcEM7Ozs7a0JBRUQsd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQWhCLENBQ0Usd0JBQUMsVUFBRCxZQUFRLG9CQUF5Qjs7OzttQkFDakMsd0JBQUMsU0FBRCxZQUFPLDZFQUdBOzs7O2lCQUNIOzs7OztnQkFDRDs7Ozs7aUJBRVAsd0JBQUMsU0FBRDtRQUNFLFdBQVcsaUJBQ1QsMkJBQTJCLGFBQWE7a0JBRjVDLENBS0Usd0JBQUMsU0FBRDtTQUNFLE1BQUs7U0FDTCxNQUFLO1NBQ0wsT0FBTTtTQUNOLFNBQVM7U0FDVCxnQkFDRSw0QkFBNEIsSUFBSTtRQUVuQzs7OztrQkFFRCx3QkFBQyxRQUFEO1NBQU0sV0FBVTttQkFBaEIsQ0FDRSx3QkFBQyxVQUFELFlBQVEsdUJBQTRCOzs7O21CQUNwQyx3QkFBQyxTQUFELFlBQU8sOEZBR0E7Ozs7aUJBQ0g7Ozs7O2dCQUNEOzs7OztlQUNKOzs7OztjQUNHOzs7Ozs7S0FHQSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZixDQUNFLHdCQUFDLFVBQUQ7T0FBUSxNQUFLO09BQVMsVUFBVTtpQkFDN0IsVUFDRyxnQkFDQTtNQUNFOzs7O2dCQUVSLHdCQUFDLFVBQUQ7T0FDRSxNQUFLO09BQ0wsV0FBVTtPQUNWLFVBQVU7T0FDVixlQUFlO1FBQ2IsUUFBUSxLQUFLO1FBQ2IsU0FBUyxFQUFFO09BQ2I7aUJBQ0Q7TUFFTzs7OztjQUNMOzs7Ozs7SUFDRDs7Ozs7O0VBRUw7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkNyZWF0ZUFzc2lnbm1lbnRGb3JtLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IHsgdXNlU3RhdGUsIHR5cGUgRm9ybUV2ZW50IH0gZnJvbSAncmVhY3QnXHJcblxyXG50eXBlIFByb3BzID0ge1xyXG4gIGNvdXJzZUlkOiBudW1iZXJcclxuICB0b2tlbjogc3RyaW5nXHJcbiAgb25DcmVhdGVkOiAoKSA9PiB2b2lkXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENyZWF0ZUFzc2lnbm1lbnRGb3JtKHtcclxuICBjb3Vyc2VJZCxcclxuICB0b2tlbixcclxuICBvbkNyZWF0ZWQsXHJcbn06IFByb3BzKSB7XHJcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbZGVzY3JpcHRpb24sIHNldERlc2NyaXB0aW9uXSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtpbnN0cnVjdGlvbnMsIHNldEluc3RydWN0aW9uc10gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbZHVlQXQsIHNldER1ZUF0XSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFttYXhTY29yZSwgc2V0TWF4U2NvcmVdID0gdXNlU3RhdGUoJzEwMCcpXHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZSgnJylcclxuICBjb25zdCBbYWxsb3dNdWx0aXBsZVN1Ym1pc3Npb25zLCBzZXRBbGxvd011bHRpcGxlU3VibWlzc2lvbnNdID1cclxuICB1c2VTdGF0ZShmYWxzZSlcclxuICBhc3luYyBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoXHJcbiAgICBldmVudDogRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD5cclxuICApIHtcclxuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgIHNldEVycm9yKCcnKVxyXG4gICAgc2V0TWVzc2FnZSgnJylcclxuXHJcbiAgICBjb25zdCBkZWFkbGluZSA9IG5ldyBEYXRlKGR1ZUF0KVxyXG4gICAgY29uc3Qgc2NvcmUgPSBOdW1iZXIobWF4U2NvcmUpXHJcblxyXG4gICAgaWYgKCF0aXRsZS50cmltKCkpIHtcclxuICAgICAgc2V0RXJyb3IoJ0Fzc2lnbm1lbnQgdGl0bGUgaXMgcmVxdWlyZWQuJylcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcblxyXG4gICAgaWYgKFxyXG4gICAgICAhTnVtYmVyLmlzRmluaXRlKGRlYWRsaW5lLmdldFRpbWUoKSkgfHxcclxuICAgICAgZGVhZGxpbmUgPD0gbmV3IERhdGUoKVxyXG4gICAgKSB7XHJcbiAgICAgIHNldEVycm9yKCdTZWxlY3QgYSBmdXR1cmUgZGVhZGxpbmUuJylcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcblxyXG4gICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoc2NvcmUpIHx8IHNjb3JlIDw9IDApIHtcclxuICAgICAgc2V0RXJyb3IoJ01heGltdW0gc2NvcmUgbXVzdCBiZSBncmVhdGVyIHRoYW4gemVyby4nKVxyXG4gICAgICByZXR1cm5cclxuICAgIH1cclxuXHJcbiAgICBzZXRMb2FkaW5nKHRydWUpXHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICBgL2FwaS9hc3NpZ25tZW50cy9jb3Vyc2VzLyR7Y291cnNlSWR9YCxcclxuICAgICAgICB7XHJcbiAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAsXHJcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICB0aXRsZTogdGl0bGUudHJpbSgpLFxyXG4gICAgICAgICAgICBkZXNjcmlwdGlvbjogZGVzY3JpcHRpb24udHJpbSgpIHx8IG51bGwsXHJcbiAgICAgICAgICAgIGluc3RydWN0aW9uczogaW5zdHJ1Y3Rpb25zLnRyaW0oKSB8fCBudWxsLFxyXG4gICAgICAgICAgICBkdWVfYXQ6IGRlYWRsaW5lLnRvSVNPU3RyaW5nKCksXHJcbiAgICAgICAgICAgIG1heF9zY29yZTogc2NvcmUsXHJcbiAgICAgICAgICAgIGFsbG93X211bHRpcGxlX3N1Ym1pc3Npb25zOiBhbGxvd011bHRpcGxlU3VibWlzc2lvbnMsXHJcbiAgICAgICAgICB9KSxcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuXHJcbiAgICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+IG51bGwpXHJcblxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgICAgIHR5cGVvZiBkYXRhPy5kZXRhaWwgPT09ICdzdHJpbmcnXHJcbiAgICAgICAgICAgID8gZGF0YS5kZXRhaWxcclxuICAgICAgICAgICAgOiBgVW5hYmxlIHRvIGNyZWF0ZSBhc3NpZ25tZW50ICgke3Jlc3BvbnNlLnN0YXR1c30pLmBcclxuICAgICAgICApXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHNldFRpdGxlKCcnKVxyXG4gICAgICBzZXREZXNjcmlwdGlvbignJylcclxuICAgICAgc2V0SW5zdHJ1Y3Rpb25zKCcnKVxyXG4gICAgICBzZXREdWVBdCgnJylcclxuICAgICAgc2V0TWF4U2NvcmUoJzEwMCcpXHJcbiAgICAgIHNldEFsbG93TXVsdGlwbGVTdWJtaXNzaW9ucyhmYWxzZSlcclxuICAgICAgc2V0T3BlbihmYWxzZSlcclxuICAgICAgc2V0TWVzc2FnZSgnQXNzaWdubWVudCBjcmVhdGVkIHN1Y2Nlc3NmdWxseS4nKVxyXG5cclxuICAgICAgb25DcmVhdGVkKClcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvcihcclxuICAgICAgICBlcnIgaW5zdGFuY2VvZiBFcnJvclxyXG4gICAgICAgICAgPyBlcnIubWVzc2FnZVxyXG4gICAgICAgICAgOiAnVW5hYmxlIHRvIGNyZWF0ZSBhc3NpZ25tZW50LidcclxuICAgICAgKVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImNyZWF0ZS1hc3NpZ25tZW50XCI+XHJcbiAgICAgIHshb3BlbiAmJiAoXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldE9wZW4odHJ1ZSlcclxuICAgICAgICAgICAgc2V0TWVzc2FnZSgnJylcclxuICAgICAgICAgIH19XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgKyBDcmVhdGUgQXNzaWdubWVudFxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICApfVxyXG5cclxuICAgICAge21lc3NhZ2UgJiYgKFxyXG4gICAgICAgIDxwIGNsYXNzTmFtZT1cInN1Y2Nlc3MtbWVzc2FnZVwiIHJvbGU9XCJzdGF0dXNcIj5cclxuICAgICAgICAgIHttZXNzYWdlfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cclxuICAgICAgICAgIHtlcnJvcn1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7b3BlbiAmJiAoXHJcbiAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XHJcbiAgICAgICAgICA8aDM+Q3JlYXRlIE5ldyBBc3NpZ25tZW50PC9oMz5cclxuXHJcbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm5ldy1hc3NpZ25tZW50LXRpdGxlXCI+XHJcbiAgICAgICAgICAgIFRpdGxlXHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgIGlkPVwibmV3LWFzc2lnbm1lbnQtdGl0bGVcIlxyXG4gICAgICAgICAgICByZXF1aXJlZFxyXG4gICAgICAgICAgICBtYXhMZW5ndGg9ezIwMH1cclxuICAgICAgICAgICAgdmFsdWU9e3RpdGxlfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRpdGxlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJuZXctYXNzaWdubWVudC1kZXNjcmlwdGlvblwiPlxyXG4gICAgICAgICAgICBEZXNjcmlwdGlvblxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDx0ZXh0YXJlYVxyXG4gICAgICAgICAgICBpZD1cIm5ldy1hc3NpZ25tZW50LWRlc2NyaXB0aW9uXCJcclxuICAgICAgICAgICAgcm93cz17M31cclxuICAgICAgICAgICAgdmFsdWU9e2Rlc2NyaXB0aW9ufVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldERlc2NyaXB0aW9uKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJuZXctYXNzaWdubWVudC1pbnN0cnVjdGlvbnNcIj5cclxuICAgICAgICAgICAgSW5zdHJ1Y3Rpb25zXHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG4gICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgIGlkPVwibmV3LWFzc2lnbm1lbnQtaW5zdHJ1Y3Rpb25zXCJcclxuICAgICAgICAgICAgcm93cz17NX1cclxuICAgICAgICAgICAgdmFsdWU9e2luc3RydWN0aW9uc31cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRJbnN0cnVjdGlvbnMoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm5ldy1hc3NpZ25tZW50LWRlYWRsaW5lXCI+XHJcbiAgICAgICAgICAgIFN1Ym1pc3Npb24gRGVhZGxpbmVcclxuICAgICAgICAgIDwvbGFiZWw+XHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgaWQ9XCJuZXctYXNzaWdubWVudC1kZWFkbGluZVwiXHJcbiAgICAgICAgICAgIHR5cGU9XCJkYXRldGltZS1sb2NhbFwiXHJcbiAgICAgICAgICAgIHZhbHVlPXtkdWVBdH1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXREdWVBdChlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwibmV3LWFzc2lnbm1lbnQtc2NvcmVcIj5cclxuICAgICAgICAgICAgTWF4aW11bSBTY29yZVxyXG4gICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICBpZD1cIm5ldy1hc3NpZ25tZW50LXNjb3JlXCJcclxuICAgICAgICAgICAgdHlwZT1cIm51bWJlclwiXHJcbiAgICAgICAgICAgIG1pbj1cIjAuMDFcIlxyXG4gICAgICAgICAgICBzdGVwPVwiMC4wMVwiXHJcbiAgICAgICAgICAgIHZhbHVlPXttYXhTY29yZX1cclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRNYXhTY29yZShlLnRhcmdldC52YWx1ZSl9XHJcbiAgICAgICAgICAgIHJlcXVpcmVkXHJcbiAgICAgICAgICAvPlxyXG4gICAgICAgICAgXHJcblxyXG48ZmllbGRzZXQgY2xhc3NOYW1lPVwic3VibWlzc2lvbi1wb2xpY3lcIj5cclxuICA8bGVnZW5kPlN1Ym1pc3Npb24gUG9saWN5PC9sZWdlbmQ+XHJcblxyXG4gIDxkaXYgY2xhc3NOYW1lPVwicG9saWN5LW9wdGlvbnNcIj5cclxuICAgIDxsYWJlbFxyXG4gICAgICBjbGFzc05hbWU9e2Bwb2xpY3ktb3B0aW9uICR7XHJcbiAgICAgICAgIWFsbG93TXVsdGlwbGVTdWJtaXNzaW9ucyA/ICdzZWxlY3RlZCcgOiAnJ1xyXG4gICAgICB9YH1cclxuICAgID5cclxuICAgICAgPGlucHV0XHJcbiAgICAgICAgdHlwZT1cInJhZGlvXCJcclxuICAgICAgICBuYW1lPVwic3VibWlzc2lvblBvbGljeVwiXHJcbiAgICAgICAgdmFsdWU9XCJzaW5nbGVcIlxyXG4gICAgICAgIGNoZWNrZWQ9eyFhbGxvd011bHRpcGxlU3VibWlzc2lvbnN9XHJcbiAgICAgICAgb25DaGFuZ2U9eygpID0+XHJcbiAgICAgICAgICBzZXRBbGxvd011bHRpcGxlU3VibWlzc2lvbnMoZmFsc2UpXHJcbiAgICAgICAgfVxyXG4gICAgICAvPlxyXG5cclxuICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicG9saWN5LW9wdGlvbi1jb250ZW50XCI+XHJcbiAgICAgICAgPHN0cm9uZz5TaW5nbGUgU3VibWlzc2lvbjwvc3Ryb25nPlxyXG4gICAgICAgIDxzbWFsbD5cclxuICAgICAgICAgIE9uZSBhY3RpdmUgc3VibWlzc2lvbi4gU3R1ZGVudHMgY2FuIGVkaXQgb3JcclxuICAgICAgICAgIHJlbW92ZSBpdCBiZWZvcmUgdGhlIGRlYWRsaW5lLlxyXG4gICAgICAgIDwvc21hbGw+XHJcbiAgICAgIDwvc3Bhbj5cclxuICAgIDwvbGFiZWw+XHJcblxyXG4gICAgPGxhYmVsXHJcbiAgICAgIGNsYXNzTmFtZT17YHBvbGljeS1vcHRpb24gJHtcclxuICAgICAgICBhbGxvd011bHRpcGxlU3VibWlzc2lvbnMgPyAnc2VsZWN0ZWQnIDogJydcclxuICAgICAgfWB9XHJcbiAgICA+XHJcbiAgICAgIDxpbnB1dFxyXG4gICAgICAgIHR5cGU9XCJyYWRpb1wiXHJcbiAgICAgICAgbmFtZT1cInN1Ym1pc3Npb25Qb2xpY3lcIlxyXG4gICAgICAgIHZhbHVlPVwibXVsdGlwbGVcIlxyXG4gICAgICAgIGNoZWNrZWQ9e2FsbG93TXVsdGlwbGVTdWJtaXNzaW9uc31cclxuICAgICAgICBvbkNoYW5nZT17KCkgPT5cclxuICAgICAgICAgIHNldEFsbG93TXVsdGlwbGVTdWJtaXNzaW9ucyh0cnVlKVxyXG4gICAgICAgIH1cclxuICAgICAgLz5cclxuXHJcbiAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInBvbGljeS1vcHRpb24tY29udGVudFwiPlxyXG4gICAgICAgIDxzdHJvbmc+TXVsdGlwbGUgU3VibWlzc2lvbnM8L3N0cm9uZz5cclxuICAgICAgICA8c21hbGw+XHJcbiAgICAgICAgICBTdHVkZW50cyBjYW4gc3VibWl0IGFkZGl0aW9uYWwgYXR0ZW1wdHMgdW50aWxcclxuICAgICAgICAgIHRoZSBkZWFkbGluZS4gRWFybGllciBhdHRlbXB0cyBhcmUgcHJlc2VydmVkLlxyXG4gICAgICAgIDwvc21hbGw+XHJcbiAgICAgIDwvc3Bhbj5cclxuICAgIDwvbGFiZWw+XHJcbiAgPC9kaXY+XHJcbjwvZmllbGRzZXQ+XHJcblxyXG5cclxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic3VibWlzc2lvbi1hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgIDxidXR0b24gdHlwZT1cInN1Ym1pdFwiIGRpc2FibGVkPXtsb2FkaW5nfT5cclxuICAgICAgICAgICAgICB7bG9hZGluZ1xyXG4gICAgICAgICAgICAgICAgPyAnQ3JlYXRpbmcuLi4nXHJcbiAgICAgICAgICAgICAgICA6ICdDcmVhdGUgQXNzaWdubWVudCd9XHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgIGRpc2FibGVkPXtsb2FkaW5nfVxyXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgIHNldE9wZW4oZmFsc2UpXHJcbiAgICAgICAgICAgICAgICBzZXRFcnJvcignJylcclxuICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgQ2FuY2VsXHJcbiAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9mb3JtPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcbiJdfQ==