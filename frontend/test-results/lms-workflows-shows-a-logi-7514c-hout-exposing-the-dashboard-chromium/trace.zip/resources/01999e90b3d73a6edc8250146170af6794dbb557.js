import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CourseSubNav.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CourseSubNav.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
const sections = [
	{
		id: "overview",
		label: "Overview",
		icon: "🏠"
	},
	{
		id: "materials",
		label: "Course Materials",
		icon: "📚"
	},
	{
		id: "assignments",
		label: "Assignments",
		icon: "📝"
	},
	{
		id: "meetings",
		label: "Meetings",
		icon: "📹"
	}
];
export default function CourseSubNav({ activeSection, onChange }) {
	return /* @__PURE__ */ _jsxDEV("nav", {
		className: "course-subnav",
		"aria-label": "Course navigation",
		children: sections.map((section) => /* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			className: "course-subnav-button " + (activeSection === section.id ? "active" : ""),
			"aria-current": activeSection === section.id ? "page" : undefined,
			onClick: () => onChange(section.id),
			children: [/* @__PURE__ */ _jsxDEV("span", {
				"aria-hidden": "true",
				children: section.icon
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 66,
				columnNumber: 11
			}, this), section.label]
		}, section.id, true, {
			fileName: _jsxFileName,
			lineNumber: 50,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 45,
		columnNumber: 5
	}, this);
}
_c = CourseSubNav;
var _c;
$RefreshReg$(_c, "CourseSubNav");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/CourseSubNav.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CourseSubNav.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CourseSubNav.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CourseSubNav.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFZQSxNQUFNLFdBSUE7Q0FDSjtFQUNFLElBQUk7RUFDSixPQUFPO0VBQ1AsTUFBTTtDQUNSO0NBQ0E7RUFDRSxJQUFJO0VBQ0osT0FBTztFQUNQLE1BQU07Q0FDUjtDQUNBO0VBQ0UsSUFBSTtFQUNKLE9BQU87RUFDUCxNQUFNO0NBQ1I7Q0FDQTtFQUNFLElBQUk7RUFDSixPQUFPO0VBQ1AsTUFBTTtDQUNSO0FBQ0Y7QUFFQSxlQUFlLFNBQVMsYUFBYSxFQUNuQyxlQUNBLFlBQ1E7Q0FDUixPQUNFLHdCQUFDLE9BQUQ7RUFDRSxXQUFVO0VBQ1YsY0FBVztZQUVWLFNBQVMsS0FBSyxZQUNiLHdCQUFDLFVBQUQ7R0FFRSxNQUFLO0dBQ0wsV0FDRSwyQkFDQyxrQkFBa0IsUUFBUSxLQUN2QixXQUNBO0dBRU4sZ0JBQ0Usa0JBQWtCLFFBQVEsS0FDdEIsU0FDQTtHQUVOLGVBQWUsU0FBUyxRQUFRLEVBQUU7YUFkcEMsQ0FnQkUsd0JBQUMsUUFBRDtJQUFNLGVBQVk7Y0FDZixRQUFRO0dBQ0w7Ozs7YUFFTCxRQUFRLEtBQ0g7S0FwQkQsUUFBUTs7OztTQW9CUCxDQUNUO0NBQ0U7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ291cnNlU3ViTmF2LnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJcclxuZXhwb3J0IHR5cGUgQ291cnNlU2VjdGlvbiA9XHJcbiAgfCAnb3ZlcnZpZXcnXHJcbiAgfCAnbWF0ZXJpYWxzJ1xyXG4gIHwgJ2Fzc2lnbm1lbnRzJ1xyXG4gIHwgJ21lZXRpbmdzJ1xyXG5cclxudHlwZSBQcm9wcyA9IHtcclxuICBhY3RpdmVTZWN0aW9uOiBDb3Vyc2VTZWN0aW9uXHJcbiAgb25DaGFuZ2U6IChzZWN0aW9uOiBDb3Vyc2VTZWN0aW9uKSA9PiB2b2lkXHJcbn1cclxuXHJcbmNvbnN0IHNlY3Rpb25zOiB7XHJcbiAgaWQ6IENvdXJzZVNlY3Rpb25cclxuICBsYWJlbDogc3RyaW5nXHJcbiAgaWNvbjogc3RyaW5nXHJcbn1bXSA9IFtcclxuICB7XHJcbiAgICBpZDogJ292ZXJ2aWV3JyxcclxuICAgIGxhYmVsOiAnT3ZlcnZpZXcnLFxyXG4gICAgaWNvbjogJ/Cfj6AnLFxyXG4gIH0sXHJcbiAge1xyXG4gICAgaWQ6ICdtYXRlcmlhbHMnLFxyXG4gICAgbGFiZWw6ICdDb3Vyc2UgTWF0ZXJpYWxzJyxcclxuICAgIGljb246ICfwn5OaJyxcclxuICB9LFxyXG4gIHtcclxuICAgIGlkOiAnYXNzaWdubWVudHMnLFxyXG4gICAgbGFiZWw6ICdBc3NpZ25tZW50cycsXHJcbiAgICBpY29uOiAn8J+TnScsXHJcbiAgfSxcclxuICB7XHJcbiAgICBpZDogJ21lZXRpbmdzJyxcclxuICAgIGxhYmVsOiAnTWVldGluZ3MnLFxyXG4gICAgaWNvbjogJ/Cfk7knLFxyXG4gIH0sXHJcbl1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvdXJzZVN1Yk5hdih7XHJcbiAgYWN0aXZlU2VjdGlvbixcclxuICBvbkNoYW5nZSxcclxufTogUHJvcHMpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPG5hdlxyXG4gICAgICBjbGFzc05hbWU9XCJjb3Vyc2Utc3VibmF2XCJcclxuICAgICAgYXJpYS1sYWJlbD1cIkNvdXJzZSBuYXZpZ2F0aW9uXCJcclxuICAgID5cclxuICAgICAge3NlY3Rpb25zLm1hcCgoc2VjdGlvbikgPT4gKFxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIGtleT17c2VjdGlvbi5pZH1cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPXtcclxuICAgICAgICAgICAgJ2NvdXJzZS1zdWJuYXYtYnV0dG9uICcgK1xyXG4gICAgICAgICAgICAoYWN0aXZlU2VjdGlvbiA9PT0gc2VjdGlvbi5pZFxyXG4gICAgICAgICAgICAgID8gJ2FjdGl2ZSdcclxuICAgICAgICAgICAgICA6ICcnKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgYXJpYS1jdXJyZW50PXtcclxuICAgICAgICAgICAgYWN0aXZlU2VjdGlvbiA9PT0gc2VjdGlvbi5pZFxyXG4gICAgICAgICAgICAgID8gJ3BhZ2UnXHJcbiAgICAgICAgICAgICAgOiB1bmRlZmluZWRcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIG9uQ2xpY2s9eygpID0+IG9uQ2hhbmdlKHNlY3Rpb24uaWQpfVxyXG4gICAgICAgID5cclxuICAgICAgICAgIDxzcGFuIGFyaWEtaGlkZGVuPVwidHJ1ZVwiPlxyXG4gICAgICAgICAgICB7c2VjdGlvbi5pY29ufVxyXG4gICAgICAgICAgPC9zcGFuPlxyXG5cclxuICAgICAgICAgIHtzZWN0aW9uLmxhYmVsfVxyXG4gICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICApKX1cclxuICAgIDwvbmF2PlxyXG4gIClcclxufVxyXG4iXX0=