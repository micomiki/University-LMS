import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/TrackedClassroom.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
import { JitsiMeeting } from "/node_modules/.vite/deps/@jitsi_react-sdk.js?v=99f28945";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/TrackedClassroom.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
export default function TrackedClassroom({ meetingId, roomName, token, role, displayName, onClose }) {
	_s();
	const sessionRef = useRef(null);
	const timerRef = useRef(null);
	const joiningRef = useRef(false);
	const closedRef = useRef(false);
	const [trackingError, setTrackingError] = useState("");
	const isStudent = role.toLowerCase() === "student";
	function stopHeartbeat() {
		if (timerRef.current !== null) {
			clearInterval(timerRef.current);
			timerRef.current = null;
		}
	}
	function sendLeave(sessionId) {
		void fetch(`/api/attendance-tracking/sessions/${sessionId}/leave`, {
			method: "POST",
			headers: { Authorization: `Bearer ${token}` },
			keepalive: true
		}).catch(() => {
			// The server will stop counting at the
			// last successful heartbeat if this fails.
		});
	}
	async function startTracking() {
		if (!isStudent || closedRef.current || joiningRef.current || sessionRef.current !== null) {
			return;
		}
		joiningRef.current = true;
		setTrackingError("");
		try {
			const response = await fetch(`/api/attendance-tracking/meetings/${meetingId}/join`, {
				method: "POST",
				headers: { Authorization: `Bearer ${token}` }
			});
			if (!response.ok) {
				throw new Error(`Attendance tracking failed (${response.status}).`);
			}
			const data = await response.json();
			if (closedRef.current) {
				sendLeave(data.session_id);
				return;
			}
			sessionRef.current = data.session_id;
			timerRef.current = setInterval(() => {
				const sessionId = sessionRef.current;
				if (sessionId === null || closedRef.current) {
					return;
				}
				void fetch(`/api/attendance-tracking/sessions/${sessionId}/heartbeat`, {
					method: "POST",
					headers: { Authorization: `Bearer ${token}` }
				}).then((heartbeatResponse) => {
					if (heartbeatResponse.status === 409 && !closedRef.current) {
						stopHeartbeat();
						sessionRef.current = null;
						void startTracking();
					} else if (!heartbeatResponse.ok) {
						setTrackingError("Attendance connection could not be verified.");
					}
				}).catch(() => {
					if (!closedRef.current) {
						setTrackingError("Attendance heartbeat connection failed.");
					}
				});
			}, 2e4);
		} catch (error) {
			if (!closedRef.current) {
				setTrackingError(error instanceof Error ? error.message : "Attendance tracking unavailable.");
			}
		} finally {
			joiningRef.current = false;
		}
	}
	function closeTracking() {
		if (closedRef.current) return;
		closedRef.current = true;
		stopHeartbeat();
		const sessionId = sessionRef.current;
		sessionRef.current = null;
		if (sessionId !== null) {
			sendLeave(sessionId);
		}
		onClose();
	}
	useEffect(() => {
		closedRef.current = false;
		function handlePageHide() {
			closedRef.current = true;
			stopHeartbeat();
			const sessionId = sessionRef.current;
			sessionRef.current = null;
			if (sessionId !== null) {
				sendLeave(sessionId);
			}
		}
		window.addEventListener("pagehide", handlePageHide);
		return () => {
			window.removeEventListener("pagehide", handlePageHide);
			handlePageHide();
		};
	}, [meetingId, token]);
	return /* @__PURE__ */ _jsxDEV("div", { children: [
		isStudent && /* @__PURE__ */ _jsxDEV("p", { children: "Automatic attendance tracking is enabled." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 187,
			columnNumber: 9
		}, this),
		trackingError && /* @__PURE__ */ _jsxDEV("p", {
			className: "error",
			role: "alert",
			children: trackingError
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 193,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV(JitsiMeeting, {
			domain: "meet.jit.si",
			roomName,
			userInfo: {
				displayName,
				email: ""
			},
			configOverwrite: {
				startWithAudioMuted: true,
				startWithVideoMuted: true
			},
			onApiReady: (api) => {
				api.addListener("videoConferenceJoined", () => {
					void startTracking();
				});
				api.addListener("videoConferenceLeft", closeTracking);
			},
			onReadyToClose: closeTracking,
			getIFrameRef: (element) => {
				element.style.width = "100%";
				element.style.height = "70vh";
			}
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 198,
			columnNumber: 7
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 185,
		columnNumber: 5
	}, this);
}
_s(TrackedClassroom, "VkTjEgQNwrV/I31vH8nBT50A/7s=");
_c = TrackedClassroom;
var _c;
$RefreshReg$(_c, "TrackedClassroom");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/TrackedClassroom.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/TrackedClassroom.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/TrackedClassroom.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/TrackedClassroom.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxXQUFXLFFBQVEsZ0JBQWdCO0FBQzVDLFNBQVMsb0JBQW9COzs7O0FBVzdCLGVBQWUsU0FBUyxpQkFBaUIsRUFDdkMsV0FDQSxVQUNBLE9BQ0EsTUFDQSxhQUNBLFdBQ1E7O0NBQ1IsTUFBTSxhQUFhLE9BQXNCLElBQUk7Q0FDN0MsTUFBTSxXQUFXLE9BQThDLElBQUk7Q0FDbkUsTUFBTSxhQUFhLE9BQU8sS0FBSztDQUMvQixNQUFNLFlBQVksT0FBTyxLQUFLO0NBRTlCLE1BQU0sQ0FBQyxlQUFlLG9CQUFvQixTQUFTLEVBQUU7Q0FFckQsTUFBTSxZQUFZLEtBQUssWUFBWSxNQUFNO0NBRXpDLFNBQVMsZ0JBQWdCO0VBQ3ZCLElBQUksU0FBUyxZQUFZLE1BQU07R0FDN0IsY0FBYyxTQUFTLE9BQU87R0FDOUIsU0FBUyxVQUFVO0VBQ3JCO0NBQ0Y7Q0FFQSxTQUFTLFVBQVUsV0FBbUI7RUFDcEMsS0FBSyxNQUNILHFDQUFxQyxVQUFVLFNBQy9DO0dBQ0UsUUFBUTtHQUNSLFNBQVMsRUFDUCxlQUFlLFVBQVUsUUFDM0I7R0FDQSxXQUFXO0VBQ2IsQ0FDRixDQUFDLENBQUMsWUFBWTs7O0VBR2QsQ0FBQztDQUNIO0NBRUEsZUFBZSxnQkFBZ0I7RUFDN0IsSUFDRSxDQUFDLGFBQ0QsVUFBVSxXQUNWLFdBQVcsV0FDWCxXQUFXLFlBQVksTUFDdkI7R0FDQTtFQUNGO0VBRUEsV0FBVyxVQUFVO0VBQ3JCLGlCQUFpQixFQUFFO0VBRW5CLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxNQUNyQixxQ0FBcUMsVUFBVSxRQUMvQztJQUNFLFFBQVE7SUFDUixTQUFTLEVBQ1AsZUFBZSxVQUFVLFFBQzNCO0dBQ0YsQ0FDRjtHQUVBLElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsTUFBTSxJQUFJLE1BQ1IsK0JBQStCLFNBQVMsT0FBTyxHQUNqRDtHQUNGO0dBRUEsTUFBTSxPQUNKLE1BQU0sU0FBUyxLQUFLO0dBRXRCLElBQUksVUFBVSxTQUFTO0lBQ3JCLFVBQVUsS0FBSyxVQUFVO0lBQ3pCO0dBQ0Y7R0FFQSxXQUFXLFVBQVUsS0FBSztHQUUxQixTQUFTLFVBQVUsa0JBQWtCO0lBQ25DLE1BQU0sWUFBWSxXQUFXO0lBRTdCLElBQUksY0FBYyxRQUFRLFVBQVUsU0FBUztLQUMzQztJQUNGO0lBRUEsS0FBSyxNQUNILHFDQUFxQyxVQUFVLGFBQy9DO0tBQ0UsUUFBUTtLQUNSLFNBQVMsRUFDUCxlQUFlLFVBQVUsUUFDM0I7SUFDRixDQUNGLENBQUMsQ0FDRSxNQUFNLHNCQUFzQjtLQUMzQixJQUNFLGtCQUFrQixXQUFXLE9BQzdCLENBQUMsVUFBVSxTQUNYO01BQ0EsY0FBYztNQUNkLFdBQVcsVUFBVTtNQUNyQixLQUFLLGNBQWM7S0FDckIsT0FBTyxJQUFJLENBQUMsa0JBQWtCLElBQUk7TUFDaEMsaUJBQ0UsOENBQ0Y7S0FDRjtJQUNGLENBQUMsQ0FBQyxDQUNELFlBQVk7S0FDWCxJQUFJLENBQUMsVUFBVSxTQUFTO01BQ3RCLGlCQUNFLHlDQUNGO0tBQ0Y7SUFDRixDQUFDO0dBQ0wsR0FBRyxHQUFLO0VBQ1YsU0FBUyxPQUFPO0dBQ2QsSUFBSSxDQUFDLFVBQVUsU0FBUztJQUN0QixpQkFDRSxpQkFBaUIsUUFDYixNQUFNLFVBQ04sa0NBQ047R0FDRjtFQUNGLFVBQVU7R0FDUixXQUFXLFVBQVU7RUFDdkI7Q0FDRjtDQUVBLFNBQVMsZ0JBQWdCO0VBQ3ZCLElBQUksVUFBVSxTQUFTO0VBRXZCLFVBQVUsVUFBVTtFQUNwQixjQUFjO0VBRWQsTUFBTSxZQUFZLFdBQVc7RUFDN0IsV0FBVyxVQUFVO0VBRXJCLElBQUksY0FBYyxNQUFNO0dBQ3RCLFVBQVUsU0FBUztFQUNyQjtFQUVBLFFBQVE7Q0FDVjtDQUVBLGdCQUFnQjtFQUNkLFVBQVUsVUFBVTtFQUVwQixTQUFTLGlCQUFpQjtHQUN4QixVQUFVLFVBQVU7R0FDcEIsY0FBYztHQUVkLE1BQU0sWUFBWSxXQUFXO0dBQzdCLFdBQVcsVUFBVTtHQUVyQixJQUFJLGNBQWMsTUFBTTtJQUN0QixVQUFVLFNBQVM7R0FDckI7RUFDRjtFQUVBLE9BQU8saUJBQWlCLFlBQVksY0FBYztFQUVsRCxhQUFhO0dBQ1gsT0FBTyxvQkFBb0IsWUFBWSxjQUFjO0dBQ3JELGVBQWU7RUFDakI7Q0FDRixHQUFHLENBQUMsV0FBVyxLQUFLLENBQUM7Q0FFckIsT0FDRSx3QkFBQyxPQUFEO0VBQ0csYUFDQyx3QkFBQyxLQUFELFlBQUcsNENBRUE7Ozs7O0VBR0osaUJBQ0Msd0JBQUMsS0FBRDtHQUFHLFdBQVU7R0FBUSxNQUFLO2FBQ3ZCO0VBQ0E7Ozs7O0VBR0wsd0JBQUMsY0FBRDtHQUNFLFFBQU87R0FDRztHQUNWLFVBQVU7SUFDUjtJQUNBLE9BQU87R0FDVDtHQUNBLGlCQUFpQjtJQUNmLHFCQUFxQjtJQUNyQixxQkFBcUI7R0FDdkI7R0FDQSxhQUFhLFFBQVE7SUFDbkIsSUFBSSxZQUNGLCtCQUNNO0tBQ0osS0FBSyxjQUFjO0lBQ3JCLENBQ0Y7SUFFQSxJQUFJLFlBQ0YsdUJBQ0EsYUFDRjtHQUNGO0dBQ0EsZ0JBQWdCO0dBQ2hCLGVBQWUsWUFBWTtJQUN6QixRQUFRLE1BQU0sUUFBUTtJQUN0QixRQUFRLE1BQU0sU0FBUztHQUN6QjtFQUNEOzs7OztDQUNFOzs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlRyYWNrZWRDbGFzc3Jvb20udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgSml0c2lNZWV0aW5nIH0gZnJvbSAnQGppdHNpL3JlYWN0LXNkaydcclxuXHJcbnR5cGUgUHJvcHMgPSB7XHJcbiAgbWVldGluZ0lkOiBudW1iZXJcclxuICByb29tTmFtZTogc3RyaW5nXHJcbiAgdG9rZW46IHN0cmluZ1xyXG4gIHJvbGU6IHN0cmluZ1xyXG4gIGRpc3BsYXlOYW1lOiBzdHJpbmdcclxuICBvbkNsb3NlOiAoKSA9PiB2b2lkXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIFRyYWNrZWRDbGFzc3Jvb20oe1xyXG4gIG1lZXRpbmdJZCxcclxuICByb29tTmFtZSxcclxuICB0b2tlbixcclxuICByb2xlLFxyXG4gIGRpc3BsYXlOYW1lLFxyXG4gIG9uQ2xvc2UsXHJcbn06IFByb3BzKSB7XHJcbiAgY29uc3Qgc2Vzc2lvblJlZiA9IHVzZVJlZjxudW1iZXIgfCBudWxsPihudWxsKVxyXG4gIGNvbnN0IHRpbWVyUmVmID0gdXNlUmVmPFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGw+KG51bGwpXHJcbiAgY29uc3Qgam9pbmluZ1JlZiA9IHVzZVJlZihmYWxzZSlcclxuICBjb25zdCBjbG9zZWRSZWYgPSB1c2VSZWYoZmFsc2UpXHJcblxyXG4gIGNvbnN0IFt0cmFja2luZ0Vycm9yLCBzZXRUcmFja2luZ0Vycm9yXSA9IHVzZVN0YXRlKCcnKVxyXG5cclxuICBjb25zdCBpc1N0dWRlbnQgPSByb2xlLnRvTG93ZXJDYXNlKCkgPT09ICdzdHVkZW50J1xyXG5cclxuICBmdW5jdGlvbiBzdG9wSGVhcnRiZWF0KCkge1xyXG4gICAgaWYgKHRpbWVyUmVmLmN1cnJlbnQgIT09IG51bGwpIHtcclxuICAgICAgY2xlYXJJbnRlcnZhbCh0aW1lclJlZi5jdXJyZW50KVxyXG4gICAgICB0aW1lclJlZi5jdXJyZW50ID0gbnVsbFxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gc2VuZExlYXZlKHNlc3Npb25JZDogbnVtYmVyKSB7XHJcbiAgICB2b2lkIGZldGNoKFxyXG4gICAgICBgL2FwaS9hdHRlbmRhbmNlLXRyYWNraW5nL3Nlc3Npb25zLyR7c2Vzc2lvbklkfS9sZWF2ZWAsXHJcbiAgICAgIHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGtlZXBhbGl2ZTogdHJ1ZSxcclxuICAgICAgfVxyXG4gICAgKS5jYXRjaCgoKSA9PiB7XHJcbiAgICAgIC8vIFRoZSBzZXJ2ZXIgd2lsbCBzdG9wIGNvdW50aW5nIGF0IHRoZVxyXG4gICAgICAvLyBsYXN0IHN1Y2Nlc3NmdWwgaGVhcnRiZWF0IGlmIHRoaXMgZmFpbHMuXHJcbiAgICB9KVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZnVuY3Rpb24gc3RhcnRUcmFja2luZygpIHtcclxuICAgIGlmIChcclxuICAgICAgIWlzU3R1ZGVudCB8fFxyXG4gICAgICBjbG9zZWRSZWYuY3VycmVudCB8fFxyXG4gICAgICBqb2luaW5nUmVmLmN1cnJlbnQgfHxcclxuICAgICAgc2Vzc2lvblJlZi5jdXJyZW50ICE9PSBudWxsXHJcbiAgICApIHtcclxuICAgICAgcmV0dXJuXHJcbiAgICB9XHJcblxyXG4gICAgam9pbmluZ1JlZi5jdXJyZW50ID0gdHJ1ZVxyXG4gICAgc2V0VHJhY2tpbmdFcnJvcignJylcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgIGAvYXBpL2F0dGVuZGFuY2UtdHJhY2tpbmcvbWVldGluZ3MvJHttZWV0aW5nSWR9L2pvaW5gLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCxcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcblxyXG4gICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICAgICAgYEF0dGVuZGFuY2UgdHJhY2tpbmcgZmFpbGVkICgke3Jlc3BvbnNlLnN0YXR1c30pLmBcclxuICAgICAgICApXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IGRhdGE6IHsgc2Vzc2lvbl9pZDogbnVtYmVyIH0gPVxyXG4gICAgICAgIGF3YWl0IHJlc3BvbnNlLmpzb24oKVxyXG5cclxuICAgICAgaWYgKGNsb3NlZFJlZi5jdXJyZW50KSB7XHJcbiAgICAgICAgc2VuZExlYXZlKGRhdGEuc2Vzc2lvbl9pZClcclxuICAgICAgICByZXR1cm5cclxuICAgICAgfVxyXG5cclxuICAgICAgc2Vzc2lvblJlZi5jdXJyZW50ID0gZGF0YS5zZXNzaW9uX2lkXHJcblxyXG4gICAgICB0aW1lclJlZi5jdXJyZW50ID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHNlc3Npb25JZCA9IHNlc3Npb25SZWYuY3VycmVudFxyXG5cclxuICAgICAgICBpZiAoc2Vzc2lvbklkID09PSBudWxsIHx8IGNsb3NlZFJlZi5jdXJyZW50KSB7XHJcbiAgICAgICAgICByZXR1cm5cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHZvaWQgZmV0Y2goXHJcbiAgICAgICAgICBgL2FwaS9hdHRlbmRhbmNlLXRyYWNraW5nL3Nlc3Npb25zLyR7c2Vzc2lvbklkfS9oZWFydGJlYXRgLFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0b2tlbn1gLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICAgIC50aGVuKChoZWFydGJlYXRSZXNwb25zZSkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoXHJcbiAgICAgICAgICAgICAgaGVhcnRiZWF0UmVzcG9uc2Uuc3RhdHVzID09PSA0MDkgJiZcclxuICAgICAgICAgICAgICAhY2xvc2VkUmVmLmN1cnJlbnRcclxuICAgICAgICAgICAgKSB7XHJcbiAgICAgICAgICAgICAgc3RvcEhlYXJ0YmVhdCgpXHJcbiAgICAgICAgICAgICAgc2Vzc2lvblJlZi5jdXJyZW50ID0gbnVsbFxyXG4gICAgICAgICAgICAgIHZvaWQgc3RhcnRUcmFja2luZygpXHJcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoIWhlYXJ0YmVhdFJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgICAgICAgc2V0VHJhY2tpbmdFcnJvcihcclxuICAgICAgICAgICAgICAgICdBdHRlbmRhbmNlIGNvbm5lY3Rpb24gY291bGQgbm90IGJlIHZlcmlmaWVkLidcclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgICAuY2F0Y2goKCkgPT4ge1xyXG4gICAgICAgICAgICBpZiAoIWNsb3NlZFJlZi5jdXJyZW50KSB7XHJcbiAgICAgICAgICAgICAgc2V0VHJhY2tpbmdFcnJvcihcclxuICAgICAgICAgICAgICAgICdBdHRlbmRhbmNlIGhlYXJ0YmVhdCBjb25uZWN0aW9uIGZhaWxlZC4nXHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KVxyXG4gICAgICB9LCAyMDAwMClcclxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgIGlmICghY2xvc2VkUmVmLmN1cnJlbnQpIHtcclxuICAgICAgICBzZXRUcmFja2luZ0Vycm9yKFxyXG4gICAgICAgICAgZXJyb3IgaW5zdGFuY2VvZiBFcnJvclxyXG4gICAgICAgICAgICA/IGVycm9yLm1lc3NhZ2VcclxuICAgICAgICAgICAgOiAnQXR0ZW5kYW5jZSB0cmFja2luZyB1bmF2YWlsYWJsZS4nXHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBqb2luaW5nUmVmLmN1cnJlbnQgPSBmYWxzZVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZnVuY3Rpb24gY2xvc2VUcmFja2luZygpIHtcclxuICAgIGlmIChjbG9zZWRSZWYuY3VycmVudCkgcmV0dXJuXHJcblxyXG4gICAgY2xvc2VkUmVmLmN1cnJlbnQgPSB0cnVlXHJcbiAgICBzdG9wSGVhcnRiZWF0KClcclxuXHJcbiAgICBjb25zdCBzZXNzaW9uSWQgPSBzZXNzaW9uUmVmLmN1cnJlbnRcclxuICAgIHNlc3Npb25SZWYuY3VycmVudCA9IG51bGxcclxuXHJcbiAgICBpZiAoc2Vzc2lvbklkICE9PSBudWxsKSB7XHJcbiAgICAgIHNlbmRMZWF2ZShzZXNzaW9uSWQpXHJcbiAgICB9XHJcblxyXG4gICAgb25DbG9zZSgpXHJcbiAgfVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY2xvc2VkUmVmLmN1cnJlbnQgPSBmYWxzZVxyXG5cclxuICAgIGZ1bmN0aW9uIGhhbmRsZVBhZ2VIaWRlKCkge1xyXG4gICAgICBjbG9zZWRSZWYuY3VycmVudCA9IHRydWVcclxuICAgICAgc3RvcEhlYXJ0YmVhdCgpXHJcblxyXG4gICAgICBjb25zdCBzZXNzaW9uSWQgPSBzZXNzaW9uUmVmLmN1cnJlbnRcclxuICAgICAgc2Vzc2lvblJlZi5jdXJyZW50ID0gbnVsbFxyXG5cclxuICAgICAgaWYgKHNlc3Npb25JZCAhPT0gbnVsbCkge1xyXG4gICAgICAgIHNlbmRMZWF2ZShzZXNzaW9uSWQpXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncGFnZWhpZGUnLCBoYW5kbGVQYWdlSGlkZSlcclxuXHJcbiAgICByZXR1cm4gKCkgPT4ge1xyXG4gICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcigncGFnZWhpZGUnLCBoYW5kbGVQYWdlSGlkZSlcclxuICAgICAgaGFuZGxlUGFnZUhpZGUoKVxyXG4gICAgfVxyXG4gIH0sIFttZWV0aW5nSWQsIHRva2VuXSlcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIHtpc1N0dWRlbnQgJiYgKFxyXG4gICAgICAgIDxwPlxyXG4gICAgICAgICAgQXV0b21hdGljIGF0dGVuZGFuY2UgdHJhY2tpbmcgaXMgZW5hYmxlZC5cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7dHJhY2tpbmdFcnJvciAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cclxuICAgICAgICAgIHt0cmFja2luZ0Vycm9yfVxyXG4gICAgICAgIDwvcD5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIDxKaXRzaU1lZXRpbmdcclxuICAgICAgICBkb21haW49XCJtZWV0LmppdC5zaVwiXHJcbiAgICAgICAgcm9vbU5hbWU9e3Jvb21OYW1lfVxyXG4gICAgICAgIHVzZXJJbmZvPXt7XHJcbiAgICAgICAgICBkaXNwbGF5TmFtZSxcclxuICAgICAgICAgIGVtYWlsOiAnJyxcclxuICAgICAgICB9fVxyXG4gICAgICAgIGNvbmZpZ092ZXJ3cml0ZT17e1xyXG4gICAgICAgICAgc3RhcnRXaXRoQXVkaW9NdXRlZDogdHJ1ZSxcclxuICAgICAgICAgIHN0YXJ0V2l0aFZpZGVvTXV0ZWQ6IHRydWUsXHJcbiAgICAgICAgfX1cclxuICAgICAgICBvbkFwaVJlYWR5PXsoYXBpKSA9PiB7XHJcbiAgICAgICAgICBhcGkuYWRkTGlzdGVuZXIoXHJcbiAgICAgICAgICAgICd2aWRlb0NvbmZlcmVuY2VKb2luZWQnLFxyXG4gICAgICAgICAgICAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgdm9pZCBzdGFydFRyYWNraW5nKClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKVxyXG5cclxuICAgICAgICAgIGFwaS5hZGRMaXN0ZW5lcihcclxuICAgICAgICAgICAgJ3ZpZGVvQ29uZmVyZW5jZUxlZnQnLFxyXG4gICAgICAgICAgICBjbG9zZVRyYWNraW5nXHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfX1cclxuICAgICAgICBvblJlYWR5VG9DbG9zZT17Y2xvc2VUcmFja2luZ31cclxuICAgICAgICBnZXRJRnJhbWVSZWY9eyhlbGVtZW50KSA9PiB7XHJcbiAgICAgICAgICBlbGVtZW50LnN0eWxlLndpZHRoID0gJzEwMCUnXHJcbiAgICAgICAgICBlbGVtZW50LnN0eWxlLmhlaWdodCA9ICc3MHZoJ1xyXG4gICAgICAgIH19XHJcbiAgICAgIC8+XHJcbiAgICA8L2Rpdj5cclxuICApXHJcbn1cclxuIl19