import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AssignmentSubmissionForm.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useRef = __vite__cjsImport0_react["useRef"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentSubmissionForm.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
const MAX_FILE_SIZE = 20 * 1024 * 1024;
export default function AssignmentSubmissionForm({ assignmentId, token, existing, onSubmitted }) {
	_s();
	const [text, setText] = useState("");
	const [file, setFile] = useState(null);
	const [isEditing, setIsEditing] = useState(false);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState("");
	const [message, setMessage] = useState("");
	const fileInput = useRef(null);
	useEffect(() => {
		setText(existing?.text_response ?? "");
		setFile(null);
	}, [assignmentId, existing?.text_response]);
	function cancelEditing() {
		setIsEditing(false);
		setText(existing?.text_response ?? "");
		setFile(null);
		setError("");
		if (fileInput.current) {
			fileInput.current.value = "";
		}
	}
	async function handleSubmit(event) {
		event.preventDefault();
		setError("");
		setMessage("");
		if (!text.trim() && !file && !existing?.original_filename) {
			setError("Please enter a response or choose a file.");
			return;
		}
		if (file && file.size > MAX_FILE_SIZE) {
			setError("Maximum file size is 20 MB.");
			return;
		}
		setLoading(true);
		try {
			const formData = new FormData();
			formData.append("text_response", text.trim());
			if (file) {
				formData.append("file", file);
			}
			const url = existing ? `/api/submissions/${existing.id}` : `/api/submissions/assignments/${assignmentId}`;
			const response = await fetch(url, {
				method: existing ? "PUT" : "POST",
				headers: { Authorization: `Bearer ${token}` },
				body: formData
			});
			if (!response.ok) {
				const data = await response.json().catch(() => null);
				throw new Error(typeof data?.detail === "string" ? data.detail : `Submission failed (${response.status}).`);
			}
			await onSubmitted();
			setFile(null);
			setIsEditing(false);
			if (fileInput.current) {
				fileInput.current.value = "";
			}
			setMessage(existing ? "Submission updated successfully." : "Assignment submitted successfully.");
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to submit assignment.");
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "submission-form",
		children: [
			/* @__PURE__ */ _jsxDEV("h4", { children: "Your Assignment Submission" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 145,
				columnNumber: 7
			}, this),
			existing && /* @__PURE__ */ _jsxDEV("div", {
				className: "submission-summary",
				children: [
					/* @__PURE__ */ _jsxDEV("p", { children: [
						/* @__PURE__ */ _jsxDEV("strong", { children: "Status:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 151,
							columnNumber: 13
						}, this),
						" ",
						existing.score !== null ? "Graded" : "Submitted"
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 150,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", { children: [
						/* @__PURE__ */ _jsxDEV("strong", { children: "Submitted:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 158,
							columnNumber: 13
						}, this),
						" ",
						new Date(existing.submitted_at).toLocaleString()
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 157,
						columnNumber: 11
					}, this),
					existing.text_response && /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Written Response:" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 166,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						style: { whiteSpace: "pre-wrap" },
						children: existing.text_response
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 167,
						columnNumber: 15
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 165,
						columnNumber: 13
					}, this),
					existing.original_filename && /* @__PURE__ */ _jsxDEV("p", { children: [
						/* @__PURE__ */ _jsxDEV("strong", { children: "Uploaded File:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 175,
							columnNumber: 15
						}, this),
						" ",
						existing.original_filename
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 174,
						columnNumber: 13
					}, this),
					existing.score !== null && /* @__PURE__ */ _jsxDEV("p", { children: [
						/* @__PURE__ */ _jsxDEV("strong", { children: "Score:" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 182,
							columnNumber: 15
						}, this),
						" ",
						existing.score
					] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 181,
						columnNumber: 13
					}, this),
					existing.feedback && /* @__PURE__ */ _jsxDEV("div", {
						className: "assignment-feedback",
						children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Professor Feedback" }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 188,
							columnNumber: 15
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: existing.feedback }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 189,
							columnNumber: 15
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 187,
						columnNumber: 13
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 149,
				columnNumber: 9
			}, this),
			!isEditing && /* @__PURE__ */ _jsxDEV("button", {
				type: "button",
				onClick: () => {
					setMessage("");
					setIsEditing(true);
				},
				children: existing ? "Edit Submission" : "Submit Assignment"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 197,
				columnNumber: 9
			}, this),
			isEditing && /* @__PURE__ */ _jsxDEV("form", {
				onSubmit: handleSubmit,
				children: [
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: `response-${assignmentId}`,
						children: "Written Response"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 213,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("textarea", {
						id: `response-${assignmentId}`,
						rows: 5,
						value: text,
						onChange: (event) => setText(event.target.value),
						placeholder: "Write your assignment response..."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 217,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: `file-${assignmentId}`,
						children: existing ? "Replace / Upload File" : "Upload File"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 227,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						ref: fileInput,
						id: `file-${assignmentId}`,
						type: "file",
						accept: ".pdf,.doc,.docx,.ppt,.pptx,.txt,.csv,.xls,.xlsx,.png,.jpg,.jpeg",
						onChange: (event) => setFile(event.target.files?.[0] ?? null)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 233,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("p", {
						className: "submission-note",
						children: "Maximum file size: 20 MB."
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 243,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "submission-actions",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							type: "submit",
							disabled: loading,
							children: loading ? "Saving..." : existing ? "Save Changes" : "Submit Assignment"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 248,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							type: "button",
							className: "btn-secondary",
							disabled: loading,
							onClick: cancelEditing,
							children: "Cancel"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 259,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 247,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 212,
				columnNumber: 9
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 272,
				columnNumber: 9
			}, this),
			message && /* @__PURE__ */ _jsxDEV("p", {
				className: "success-message",
				role: "status",
				children: message
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 278,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 144,
		columnNumber: 5
	}, this);
}
_s(AssignmentSubmissionForm, "wzphv5S+BPbpYp6eUdemTRUV/is=");
_c = AssignmentSubmissionForm;
var _c;
$RefreshReg$(_c, "AssignmentSubmissionForm");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AssignmentSubmissionForm.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentSubmissionForm.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentSubmissionForm.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentSubmissionForm.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FDRSxXQUNBLFFBQ0EsZ0JBRUs7Ozs7QUFzQlAsTUFBTSxnQkFBZ0IsS0FBSyxPQUFPO0FBRWxDLGVBQWUsU0FBUyx5QkFBeUIsRUFDL0MsY0FDQSxPQUNBLFVBQ0EsZUFDUTs7Q0FDUixNQUFNLENBQUMsTUFBTSxXQUFXLFNBQVMsRUFBRTtDQUNuQyxNQUFNLENBQUMsTUFBTSxXQUFXLFNBQXNCLElBQUk7Q0FFbEQsTUFBTSxDQUFDLFdBQVcsZ0JBQWdCLFNBQVMsS0FBSztDQUNoRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztDQUU1QyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsRUFBRTtDQUV6QyxNQUFNLFlBQVksT0FBeUIsSUFBSTtDQUUvQyxnQkFBZ0I7RUFDZCxRQUFRLFVBQVUsaUJBQWlCLEVBQUU7RUFDckMsUUFBUSxJQUFJO0NBQ2QsR0FBRyxDQUFDLGNBQWMsVUFBVSxhQUFhLENBQUM7Q0FFMUMsU0FBUyxnQkFBZ0I7RUFDdkIsYUFBYSxLQUFLO0VBQ2xCLFFBQVEsVUFBVSxpQkFBaUIsRUFBRTtFQUNyQyxRQUFRLElBQUk7RUFDWixTQUFTLEVBQUU7RUFFWCxJQUFJLFVBQVUsU0FBUztHQUNyQixVQUFVLFFBQVEsUUFBUTtFQUM1QjtDQUNGO0NBRUEsZUFBZSxhQUNiLE9BQ0E7RUFDQSxNQUFNLGVBQWU7RUFDckIsU0FBUyxFQUFFO0VBQ1gsV0FBVyxFQUFFO0VBRWIsSUFDRSxDQUFDLEtBQUssS0FBSyxLQUNYLENBQUMsUUFDRCxDQUFDLFVBQVUsbUJBQ1g7R0FDQSxTQUFTLDJDQUEyQztHQUNwRDtFQUNGO0VBRUEsSUFBSSxRQUFRLEtBQUssT0FBTyxlQUFlO0dBQ3JDLFNBQVMsNkJBQTZCO0dBQ3RDO0VBQ0Y7RUFFQSxXQUFXLElBQUk7RUFFZixJQUFJO0dBQ0YsTUFBTSxXQUFXLElBQUksU0FBUztHQUU5QixTQUFTLE9BQU8saUJBQWlCLEtBQUssS0FBSyxDQUFDO0dBRTVDLElBQUksTUFBTTtJQUNSLFNBQVMsT0FBTyxRQUFRLElBQUk7R0FDOUI7R0FFQSxNQUFNLE1BQU0sV0FDUixvQkFBb0IsU0FBUyxPQUM3QixnQ0FBZ0M7R0FFcEMsTUFBTSxXQUFXLE1BQU0sTUFBTSxLQUFLO0lBQ2hDLFFBQVEsV0FBVyxRQUFRO0lBQzNCLFNBQVMsRUFDUCxlQUFlLFVBQVUsUUFDM0I7SUFDQSxNQUFNO0dBQ1IsQ0FBQztHQUVELElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQyxZQUFZLElBQUk7SUFFbkQsTUFBTSxJQUFJLE1BQ1IsT0FBTyxNQUFNLFdBQVcsV0FDcEIsS0FBSyxTQUNMLHNCQUFzQixTQUFTLE9BQU8sR0FDNUM7R0FDRjtHQUVBLE1BQU0sWUFBWTtHQUVsQixRQUFRLElBQUk7R0FDWixhQUFhLEtBQUs7R0FFbEIsSUFBSSxVQUFVLFNBQVM7SUFDckIsVUFBVSxRQUFRLFFBQVE7R0FDNUI7R0FFQSxXQUNFLFdBQ0kscUNBQ0Esb0NBQ047RUFDRixTQUFTLEtBQUs7R0FDWixTQUNFLGVBQWUsUUFDWCxJQUFJLFVBQ0osOEJBQ047RUFDRixVQUFVO0dBQ1IsV0FBVyxLQUFLO0VBQ2xCO0NBQ0Y7Q0FFQSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWY7R0FDRSx3QkFBQyxNQUFELFlBQUksNkJBQThCOzs7OztHQUdqQyxZQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxLQUFEO01BQ0Usd0JBQUMsVUFBRCxZQUFRLFVBQWU7Ozs7O01BQUU7TUFDeEIsU0FBUyxVQUFVLE9BQ2hCLFdBQ0E7S0FDSDs7Ozs7S0FFSCx3QkFBQyxLQUFEO01BQ0Usd0JBQUMsVUFBRCxZQUFRLGFBQWtCOzs7OztNQUFFO01BQzNCLElBQUksS0FDSCxTQUFTLFlBQ1gsQ0FBQyxDQUFDLGVBQWU7S0FDaEI7Ozs7O0tBRUYsU0FBUyxpQkFDUix3QkFBQyxPQUFELGFBQ0Usd0JBQUMsVUFBRCxZQUFRLG9CQUF5Qjs7OztlQUNqQyx3QkFBQyxLQUFEO01BQUcsT0FBTyxFQUFFLFlBQVksV0FBVztnQkFDaEMsU0FBUztLQUNUOzs7O2FBQ0E7Ozs7O0tBR04sU0FBUyxxQkFDUix3QkFBQyxLQUFEO01BQ0Usd0JBQUMsVUFBRCxZQUFRLGlCQUFzQjs7Ozs7TUFBRTtNQUMvQixTQUFTO0tBQ1Q7Ozs7O0tBR0osU0FBUyxVQUFVLFFBQ2xCLHdCQUFDLEtBQUQ7TUFDRSx3QkFBQyxVQUFELFlBQVEsU0FBYzs7Ozs7TUFBQztNQUFFLFNBQVM7S0FDakM7Ozs7O0tBR0osU0FBUyxZQUNSLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRCxZQUFRLHFCQUEwQjs7OztnQkFDbEMsd0JBQUMsS0FBRCxZQUFJLFNBQVMsU0FBWTs7OztjQUN0Qjs7Ozs7O0lBRUo7Ozs7OztHQUlOLENBQUMsYUFDQSx3QkFBQyxVQUFEO0lBQ0UsTUFBSztJQUNMLGVBQWU7S0FDYixXQUFXLEVBQUU7S0FDYixhQUFhLElBQUk7SUFDbkI7Y0FFQyxXQUNHLG9CQUNBO0dBQ0U7Ozs7O0dBSVQsYUFDQyx3QkFBQyxRQUFEO0lBQU0sVUFBVTtjQUFoQjtLQUNFLHdCQUFDLFNBQUQ7TUFBTyxTQUFTLFlBQVk7Z0JBQWdCO0tBRXJDOzs7OztLQUVQLHdCQUFDLFlBQUQ7TUFDRSxJQUFJLFlBQVk7TUFDaEIsTUFBTTtNQUNOLE9BQU87TUFDUCxXQUFXLFVBQ1QsUUFBUSxNQUFNLE9BQU8sS0FBSztNQUU1QixhQUFZO0tBQ2I7Ozs7O0tBRUQsd0JBQUMsU0FBRDtNQUFPLFNBQVMsUUFBUTtnQkFDckIsV0FDRywwQkFDQTtLQUNDOzs7OztLQUVQLHdCQUFDLFNBQUQ7TUFDRSxLQUFLO01BQ0wsSUFBSSxRQUFRO01BQ1osTUFBSztNQUNMLFFBQU87TUFDUCxXQUFXLFVBQ1QsUUFBUSxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQUk7S0FFMUM7Ozs7O0tBRUQsd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWtCO0tBRTVCOzs7OztLQUVILHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxVQUFVO2lCQUVULFVBQ0csY0FDQSxXQUNFLGlCQUNBO01BQ0E7Ozs7Z0JBRVIsd0JBQUMsVUFBRDtPQUNFLE1BQUs7T0FDTCxXQUFVO09BQ1YsVUFBVTtPQUNWLFNBQVM7aUJBQ1Y7TUFFTzs7OztjQUNMOzs7Ozs7SUFDRDs7Ozs7O0dBR1AsU0FDQyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtJQUFRLE1BQUs7Y0FDdkI7R0FDQTs7Ozs7R0FHSixXQUNDLHdCQUFDLEtBQUQ7SUFBRyxXQUFVO0lBQWtCLE1BQUs7Y0FDakM7R0FDQTs7Ozs7RUFFRjs7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXNzaWdubWVudFN1Ym1pc3Npb25Gb3JtLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJcclxuaW1wb3J0IHtcclxuICB1c2VFZmZlY3QsXHJcbiAgdXNlUmVmLFxyXG4gIHVzZVN0YXRlLFxyXG4gIHR5cGUgRm9ybUV2ZW50LFxyXG59IGZyb20gJ3JlYWN0J1xyXG5cclxuZXhwb3J0IHR5cGUgU3R1ZGVudFN1Ym1pc3Npb24gPSB7XHJcbiAgaWQ6IG51bWJlclxyXG4gIGFzc2lnbm1lbnRfaWQ6IG51bWJlclxyXG4gIHN0dWRlbnRfaWQ6IG51bWJlclxyXG4gIHRleHRfcmVzcG9uc2U6IHN0cmluZyB8IG51bGxcclxuICBvcmlnaW5hbF9maWxlbmFtZTogc3RyaW5nIHwgbnVsbFxyXG4gIHN1Ym1pdHRlZF9hdDogc3RyaW5nXHJcbiAgdXBkYXRlZF9hdDogc3RyaW5nIHwgbnVsbFxyXG4gIHNjb3JlOiBudW1iZXIgfCBzdHJpbmcgfCBudWxsXHJcbiAgZmVlZGJhY2s6IHN0cmluZyB8IG51bGxcclxuICBncmFkZWRfYXQ6IHN0cmluZyB8IG51bGxcclxufVxyXG5cclxudHlwZSBQcm9wcyA9IHtcclxuICBhc3NpZ25tZW50SWQ6IG51bWJlclxyXG4gIHRva2VuOiBzdHJpbmdcclxuICBleGlzdGluZzogU3R1ZGVudFN1Ym1pc3Npb24gfCBudWxsXHJcbiAgb25TdWJtaXR0ZWQ6ICgpID0+IFByb21pc2U8dm9pZD5cclxufVxyXG5cclxuY29uc3QgTUFYX0ZJTEVfU0laRSA9IDIwICogMTAyNCAqIDEwMjRcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFzc2lnbm1lbnRTdWJtaXNzaW9uRm9ybSh7XHJcbiAgYXNzaWdubWVudElkLFxyXG4gIHRva2VuLFxyXG4gIGV4aXN0aW5nLFxyXG4gIG9uU3VibWl0dGVkLFxyXG59OiBQcm9wcykge1xyXG4gIGNvbnN0IFt0ZXh0LCBzZXRUZXh0XSA9IHVzZVN0YXRlKCcnKVxyXG4gIGNvbnN0IFtmaWxlLCBzZXRGaWxlXSA9IHVzZVN0YXRlPEZpbGUgfCBudWxsPihudWxsKVxyXG5cclxuICBjb25zdCBbaXNFZGl0aW5nLCBzZXRJc0VkaXRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUoZmFsc2UpXHJcblxyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpXHJcblxyXG4gIGNvbnN0IGZpbGVJbnB1dCA9IHVzZVJlZjxIVE1MSW5wdXRFbGVtZW50PihudWxsKVxyXG5cclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgc2V0VGV4dChleGlzdGluZz8udGV4dF9yZXNwb25zZSA/PyAnJylcclxuICAgIHNldEZpbGUobnVsbClcclxuICB9LCBbYXNzaWdubWVudElkLCBleGlzdGluZz8udGV4dF9yZXNwb25zZV0pXHJcblxyXG4gIGZ1bmN0aW9uIGNhbmNlbEVkaXRpbmcoKSB7XHJcbiAgICBzZXRJc0VkaXRpbmcoZmFsc2UpXHJcbiAgICBzZXRUZXh0KGV4aXN0aW5nPy50ZXh0X3Jlc3BvbnNlID8/ICcnKVxyXG4gICAgc2V0RmlsZShudWxsKVxyXG4gICAgc2V0RXJyb3IoJycpXHJcblxyXG4gICAgaWYgKGZpbGVJbnB1dC5jdXJyZW50KSB7XHJcbiAgICAgIGZpbGVJbnB1dC5jdXJyZW50LnZhbHVlID0gJydcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVN1Ym1pdChcclxuICAgIGV2ZW50OiBGb3JtRXZlbnQ8SFRNTEZvcm1FbGVtZW50PlxyXG4gICkge1xyXG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgc2V0RXJyb3IoJycpXHJcbiAgICBzZXRNZXNzYWdlKCcnKVxyXG5cclxuICAgIGlmIChcclxuICAgICAgIXRleHQudHJpbSgpICYmXHJcbiAgICAgICFmaWxlICYmXHJcbiAgICAgICFleGlzdGluZz8ub3JpZ2luYWxfZmlsZW5hbWVcclxuICAgICkge1xyXG4gICAgICBzZXRFcnJvcignUGxlYXNlIGVudGVyIGEgcmVzcG9uc2Ugb3IgY2hvb3NlIGEgZmlsZS4nKVxyXG4gICAgICByZXR1cm5cclxuICAgIH1cclxuXHJcbiAgICBpZiAoZmlsZSAmJiBmaWxlLnNpemUgPiBNQVhfRklMRV9TSVpFKSB7XHJcbiAgICAgIHNldEVycm9yKCdNYXhpbXVtIGZpbGUgc2l6ZSBpcyAyMCBNQi4nKVxyXG4gICAgICByZXR1cm5cclxuICAgIH1cclxuXHJcbiAgICBzZXRMb2FkaW5nKHRydWUpXHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgZm9ybURhdGEgPSBuZXcgRm9ybURhdGEoKVxyXG5cclxuICAgICAgZm9ybURhdGEuYXBwZW5kKCd0ZXh0X3Jlc3BvbnNlJywgdGV4dC50cmltKCkpXHJcblxyXG4gICAgICBpZiAoZmlsZSkge1xyXG4gICAgICAgIGZvcm1EYXRhLmFwcGVuZCgnZmlsZScsIGZpbGUpXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHVybCA9IGV4aXN0aW5nXHJcbiAgICAgICAgPyBgL2FwaS9zdWJtaXNzaW9ucy8ke2V4aXN0aW5nLmlkfWBcclxuICAgICAgICA6IGAvYXBpL3N1Ym1pc3Npb25zL2Fzc2lnbm1lbnRzLyR7YXNzaWdubWVudElkfWBcclxuXHJcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2godXJsLCB7XHJcbiAgICAgICAgbWV0aG9kOiBleGlzdGluZyA/ICdQVVQnIDogJ1BPU1QnLFxyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgIEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0b2tlbn1gLFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYm9keTogZm9ybURhdGEsXHJcbiAgICAgIH0pXHJcblxyXG4gICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKS5jYXRjaCgoKSA9PiBudWxsKVxyXG5cclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXHJcbiAgICAgICAgICB0eXBlb2YgZGF0YT8uZGV0YWlsID09PSAnc3RyaW5nJ1xyXG4gICAgICAgICAgICA/IGRhdGEuZGV0YWlsXHJcbiAgICAgICAgICAgIDogYFN1Ym1pc3Npb24gZmFpbGVkICgke3Jlc3BvbnNlLnN0YXR1c30pLmBcclxuICAgICAgICApXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGF3YWl0IG9uU3VibWl0dGVkKClcclxuXHJcbiAgICAgIHNldEZpbGUobnVsbClcclxuICAgICAgc2V0SXNFZGl0aW5nKGZhbHNlKVxyXG5cclxuICAgICAgaWYgKGZpbGVJbnB1dC5jdXJyZW50KSB7XHJcbiAgICAgICAgZmlsZUlucHV0LmN1cnJlbnQudmFsdWUgPSAnJ1xyXG4gICAgICB9XHJcblxyXG4gICAgICBzZXRNZXNzYWdlKFxyXG4gICAgICAgIGV4aXN0aW5nXHJcbiAgICAgICAgICA/ICdTdWJtaXNzaW9uIHVwZGF0ZWQgc3VjY2Vzc2Z1bGx5LidcclxuICAgICAgICAgIDogJ0Fzc2lnbm1lbnQgc3VibWl0dGVkIHN1Y2Nlc3NmdWxseS4nXHJcbiAgICAgIClcclxuICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICBzZXRFcnJvcihcclxuICAgICAgICBlcnIgaW5zdGFuY2VvZiBFcnJvclxyXG4gICAgICAgICAgPyBlcnIubWVzc2FnZVxyXG4gICAgICAgICAgOiAnVW5hYmxlIHRvIHN1Ym1pdCBhc3NpZ25tZW50LidcclxuICAgICAgKVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgc2V0TG9hZGluZyhmYWxzZSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInN1Ym1pc3Npb24tZm9ybVwiPlxyXG4gICAgICA8aDQ+WW91ciBBc3NpZ25tZW50IFN1Ym1pc3Npb248L2g0PlxyXG5cclxuICAgICAgey8qIFN1Ym1pc3Npb24gc3VtbWFyeSAqL31cclxuICAgICAge2V4aXN0aW5nICYmIChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1Ym1pc3Npb24tc3VtbWFyeVwiPlxyXG4gICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgIDxzdHJvbmc+U3RhdHVzOjwvc3Ryb25nPnsnICd9XHJcbiAgICAgICAgICAgIHtleGlzdGluZy5zY29yZSAhPT0gbnVsbFxyXG4gICAgICAgICAgICAgID8gJ0dyYWRlZCdcclxuICAgICAgICAgICAgICA6ICdTdWJtaXR0ZWQnfVxyXG4gICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICA8c3Ryb25nPlN1Ym1pdHRlZDo8L3N0cm9uZz57JyAnfVxyXG4gICAgICAgICAgICB7bmV3IERhdGUoXHJcbiAgICAgICAgICAgICAgZXhpc3Rpbmcuc3VibWl0dGVkX2F0XHJcbiAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICB7ZXhpc3RpbmcudGV4dF9yZXNwb25zZSAmJiAoXHJcbiAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgPHN0cm9uZz5Xcml0dGVuIFJlc3BvbnNlOjwvc3Ryb25nPlxyXG4gICAgICAgICAgICAgIDxwIHN0eWxlPXt7IHdoaXRlU3BhY2U6ICdwcmUtd3JhcCcgfX0+XHJcbiAgICAgICAgICAgICAgICB7ZXhpc3RpbmcudGV4dF9yZXNwb25zZX1cclxuICAgICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICB7ZXhpc3Rpbmcub3JpZ2luYWxfZmlsZW5hbWUgJiYgKFxyXG4gICAgICAgICAgICA8cD5cclxuICAgICAgICAgICAgICA8c3Ryb25nPlVwbG9hZGVkIEZpbGU6PC9zdHJvbmc+eycgJ31cclxuICAgICAgICAgICAgICB7ZXhpc3Rpbmcub3JpZ2luYWxfZmlsZW5hbWV9XHJcbiAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAge2V4aXN0aW5nLnNjb3JlICE9PSBudWxsICYmIChcclxuICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgPHN0cm9uZz5TY29yZTo8L3N0cm9uZz4ge2V4aXN0aW5nLnNjb3JlfVxyXG4gICAgICAgICAgICA8L3A+XHJcbiAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgIHtleGlzdGluZy5mZWVkYmFjayAmJiAoXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXNzaWdubWVudC1mZWVkYmFja1wiPlxyXG4gICAgICAgICAgICAgIDxzdHJvbmc+UHJvZmVzc29yIEZlZWRiYWNrPC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgPHA+e2V4aXN0aW5nLmZlZWRiYWNrfTwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICApfVxyXG5cclxuICAgICAgey8qIEJ1dHRvbiB2aXNpYmxlIHdoZW4gdGhlIGZvcm0gaXMgY2xvc2VkICovfVxyXG4gICAgICB7IWlzRWRpdGluZyAmJiAoXHJcbiAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldE1lc3NhZ2UoJycpXHJcbiAgICAgICAgICAgIHNldElzRWRpdGluZyh0cnVlKVxyXG4gICAgICAgICAgfX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7ZXhpc3RpbmdcclxuICAgICAgICAgICAgPyAnRWRpdCBTdWJtaXNzaW9uJ1xyXG4gICAgICAgICAgICA6ICdTdWJtaXQgQXNzaWdubWVudCd9XHJcbiAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7LyogRWRpdGluZyBmb3JtICovfVxyXG4gICAgICB7aXNFZGl0aW5nICYmIChcclxuICAgICAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlU3VibWl0fT5cclxuICAgICAgICAgIDxsYWJlbCBodG1sRm9yPXtgcmVzcG9uc2UtJHthc3NpZ25tZW50SWR9YH0+XHJcbiAgICAgICAgICAgIFdyaXR0ZW4gUmVzcG9uc2VcclxuICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgPHRleHRhcmVhXHJcbiAgICAgICAgICAgIGlkPXtgcmVzcG9uc2UtJHthc3NpZ25tZW50SWR9YH1cclxuICAgICAgICAgICAgcm93cz17NX1cclxuICAgICAgICAgICAgdmFsdWU9e3RleHR9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+XHJcbiAgICAgICAgICAgICAgc2V0VGV4dChldmVudC50YXJnZXQudmFsdWUpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJXcml0ZSB5b3VyIGFzc2lnbm1lbnQgcmVzcG9uc2UuLi5cIlxyXG4gICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICA8bGFiZWwgaHRtbEZvcj17YGZpbGUtJHthc3NpZ25tZW50SWR9YH0+XHJcbiAgICAgICAgICAgIHtleGlzdGluZ1xyXG4gICAgICAgICAgICAgID8gJ1JlcGxhY2UgLyBVcGxvYWQgRmlsZSdcclxuICAgICAgICAgICAgICA6ICdVcGxvYWQgRmlsZSd9XHJcbiAgICAgICAgICA8L2xhYmVsPlxyXG5cclxuICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICByZWY9e2ZpbGVJbnB1dH1cclxuICAgICAgICAgICAgaWQ9e2BmaWxlLSR7YXNzaWdubWVudElkfWB9XHJcbiAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgYWNjZXB0PVwiLnBkZiwuZG9jLC5kb2N4LC5wcHQsLnBwdHgsLnR4dCwuY3N2LC54bHMsLnhsc3gsLnBuZywuanBnLC5qcGVnXCJcclxuICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT5cclxuICAgICAgICAgICAgICBzZXRGaWxlKGV2ZW50LnRhcmdldC5maWxlcz8uWzBdID8/IG51bGwpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwic3VibWlzc2lvbi1ub3RlXCI+XHJcbiAgICAgICAgICAgIE1heGltdW0gZmlsZSBzaXplOiAyMCBNQi5cclxuICAgICAgICAgIDwvcD5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInN1Ym1pc3Npb24tYWN0aW9uc1wiPlxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cInN1Ym1pdFwiXHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XHJcbiAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICB7bG9hZGluZ1xyXG4gICAgICAgICAgICAgICAgPyAnU2F2aW5nLi4uJ1xyXG4gICAgICAgICAgICAgICAgOiBleGlzdGluZ1xyXG4gICAgICAgICAgICAgICAgICA/ICdTYXZlIENoYW5nZXMnXHJcbiAgICAgICAgICAgICAgICAgIDogJ1N1Ym1pdCBBc3NpZ25tZW50J31cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgZGlzYWJsZWQ9e2xvYWRpbmd9XHJcbiAgICAgICAgICAgICAgb25DbGljaz17Y2FuY2VsRWRpdGluZ31cclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIENhbmNlbFxyXG4gICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvZm9ybT5cclxuICAgICAgKX1cclxuXHJcbiAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cclxuICAgICAgICAgIHtlcnJvcn1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7bWVzc2FnZSAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwic3VjY2Vzcy1tZXNzYWdlXCIgcm9sZT1cInN0YXR1c1wiPlxyXG4gICAgICAgICAge21lc3NhZ2V9XHJcbiAgICAgICAgPC9wPlxyXG4gICAgICApfVxyXG4gICAgPC9kaXY+XHJcbiAgKVxyXG59XHJcbiJdfQ==