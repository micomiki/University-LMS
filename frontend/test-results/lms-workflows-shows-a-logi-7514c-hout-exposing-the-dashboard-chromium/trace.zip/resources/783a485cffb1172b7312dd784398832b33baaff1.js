import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Sidebar.tsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/Sidebar.tsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
export default function Sidebar({ page, role, onNavigate }) {
	const courseLabel = role.toLowerCase() === "professor" ? "Teaching Courses" : role.toLowerCase() === "admin" ? "Manage Courses" : "Courses";
	const items = [
		{
			id: "dashboard",
			label: "Dashboard",
			icon: "▦"
		},
		{
			id: "courses",
			label: courseLabel,
			icon: "▤"
		},
		{
			id: "classroom",
			label: "Live Classroom",
			icon: "▶"
		}
	];
	return /* @__PURE__ */ _jsxDEV("aside", {
		className: "lms-sidebar",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "lms-brand",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "lms-brand-icon",
					children: "U"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 50,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: "University LMS" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("small", { children: "Learning Management" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 51,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 49,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "lms-menu-title",
				children: "MAIN MENU"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 57,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("nav", {
				"aria-label": "Main navigation",
				children: items.map((item) => /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "lms-nav-button " + (page === item.id ? "active" : ""),
					"aria-current": page === item.id ? "page" : undefined,
					onClick: () => onNavigate(item.id),
					children: [/* @__PURE__ */ _jsxDEV("span", {
						"aria-hidden": "true",
						children: item.icon
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 73,
						columnNumber: 13
					}, this), item.label]
				}, item.id, true, {
					fileName: _jsxFileName,
					lineNumber: 61,
					columnNumber: 11
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 59,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "lms-sidebar-footer",
				children: [/* @__PURE__ */ _jsxDEV("span", { children: "Logged in as" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 80,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("strong", { children: role.toUpperCase() }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 81,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 79,
				columnNumber: 7
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 48,
		columnNumber: 5
	}, this);
}
_c = Sidebar;
var _c;
$RefreshReg$(_c, "Sidebar");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/Sidebar.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/Sidebar.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/Sidebar.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/Sidebar.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFZQSxlQUFlLFNBQVMsUUFBUSxFQUM5QixNQUNBLE1BQ0EsY0FDZTtDQUNmLE1BQU0sY0FDSixLQUFLLFlBQVksTUFBTSxjQUNuQixxQkFDQSxLQUFLLFlBQVksTUFBTSxVQUNyQixtQkFDQTtDQUVSLE1BQU0sUUFJQTtFQUNKO0dBQ0UsSUFBSTtHQUNKLE9BQU87R0FDUCxNQUFNO0VBQ1I7RUFDQTtHQUNFLElBQUk7R0FDSixPQUFPO0dBQ1AsTUFBTTtFQUNSO0VBQ0E7R0FDRSxJQUFJO0dBQ0osT0FBTztHQUNQLE1BQU07RUFDUjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxTQUFEO0VBQU8sV0FBVTtZQUFqQjtHQUNFLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFpQjtJQUFNOzs7O2NBQ3RDLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxVQUFELFlBQVEsaUJBQXNCOzs7O2NBQzlCLHdCQUFDLFNBQUQsWUFBTyxzQkFBMEI7Ozs7WUFDOUI7Ozs7WUFDRjs7Ozs7O0dBRUwsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBaUI7R0FBWTs7Ozs7R0FFMUMsd0JBQUMsT0FBRDtJQUFLLGNBQVc7Y0FDYixNQUFNLEtBQUssU0FDVix3QkFBQyxVQUFEO0tBRUUsTUFBSztLQUNMLFdBQ0UscUJBQ0MsU0FBUyxLQUFLLEtBQUssV0FBVztLQUVqQyxnQkFDRSxTQUFTLEtBQUssS0FBSyxTQUFTO0tBRTlCLGVBQWUsV0FBVyxLQUFLLEVBQUU7ZUFWbkMsQ0FZRSx3QkFBQyxRQUFEO01BQU0sZUFBWTtnQkFBUSxLQUFLO0tBQVc7Ozs7ZUFDekMsS0FBSyxLQUNBO09BYkQsS0FBSzs7OztXQWFKLENBQ1Q7R0FDRTs7Ozs7R0FFTCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLGVBQWtCOzs7O2NBQ3hCLHdCQUFDLFVBQUQsWUFBUyxLQUFLLFlBQVksRUFBVTs7OztZQUNqQzs7Ozs7O0VBQ0E7Ozs7OztBQUVYIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlNpZGViYXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIlxyXG5leHBvcnQgdHlwZSBEYXNoYm9hcmRQYWdlID1cclxuICB8ICdkYXNoYm9hcmQnXHJcbiAgfCAnY291cnNlcydcclxuICB8ICdjbGFzc3Jvb20nXHJcblxyXG50eXBlIFNpZGViYXJQcm9wcyA9IHtcclxuICBwYWdlOiBEYXNoYm9hcmRQYWdlXHJcbiAgcm9sZTogc3RyaW5nXHJcbiAgb25OYXZpZ2F0ZTogKHBhZ2U6IERhc2hib2FyZFBhZ2UpID0+IHZvaWRcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gU2lkZWJhcih7XHJcbiAgcGFnZSxcclxuICByb2xlLFxyXG4gIG9uTmF2aWdhdGUsXHJcbn06IFNpZGViYXJQcm9wcykge1xyXG4gIGNvbnN0IGNvdXJzZUxhYmVsID1cclxuICAgIHJvbGUudG9Mb3dlckNhc2UoKSA9PT0gJ3Byb2Zlc3NvcidcclxuICAgICAgPyAnVGVhY2hpbmcgQ291cnNlcydcclxuICAgICAgOiByb2xlLnRvTG93ZXJDYXNlKCkgPT09ICdhZG1pbidcclxuICAgICAgICA/ICdNYW5hZ2UgQ291cnNlcydcclxuICAgICAgICA6ICdDb3Vyc2VzJ1xyXG5cclxuICBjb25zdCBpdGVtczoge1xyXG4gICAgaWQ6IERhc2hib2FyZFBhZ2VcclxuICAgIGxhYmVsOiBzdHJpbmdcclxuICAgIGljb246IHN0cmluZ1xyXG4gIH1bXSA9IFtcclxuICAgIHtcclxuICAgICAgaWQ6ICdkYXNoYm9hcmQnLFxyXG4gICAgICBsYWJlbDogJ0Rhc2hib2FyZCcsXHJcbiAgICAgIGljb246ICfilqYnLFxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgaWQ6ICdjb3Vyc2VzJyxcclxuICAgICAgbGFiZWw6IGNvdXJzZUxhYmVsLFxyXG4gICAgICBpY29uOiAn4pakJyxcclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGlkOiAnY2xhc3Nyb29tJyxcclxuICAgICAgbGFiZWw6ICdMaXZlIENsYXNzcm9vbScsXHJcbiAgICAgIGljb246ICfilrYnLFxyXG4gICAgfSxcclxuICBdXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8YXNpZGUgY2xhc3NOYW1lPVwibG1zLXNpZGViYXJcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJsbXMtYnJhbmRcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxtcy1icmFuZC1pY29uXCI+VTwvZGl2PlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8c3Ryb25nPlVuaXZlcnNpdHkgTE1TPC9zdHJvbmc+XHJcbiAgICAgICAgICA8c21hbGw+TGVhcm5pbmcgTWFuYWdlbWVudDwvc21hbGw+XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgPHAgY2xhc3NOYW1lPVwibG1zLW1lbnUtdGl0bGVcIj5NQUlOIE1FTlU8L3A+XHJcblxyXG4gICAgICA8bmF2IGFyaWEtbGFiZWw9XCJNYWluIG5hdmlnYXRpb25cIj5cclxuICAgICAgICB7aXRlbXMubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICA8YnV0dG9uXHJcbiAgICAgICAgICAgIGtleT17aXRlbS5pZH1cclxuICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgJ2xtcy1uYXYtYnV0dG9uICcgK1xyXG4gICAgICAgICAgICAgIChwYWdlID09PSBpdGVtLmlkID8gJ2FjdGl2ZScgOiAnJylcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBhcmlhLWN1cnJlbnQ9e1xyXG4gICAgICAgICAgICAgIHBhZ2UgPT09IGl0ZW0uaWQgPyAncGFnZScgOiB1bmRlZmluZWRcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBvbk5hdmlnYXRlKGl0ZW0uaWQpfVxyXG4gICAgICAgICAgPlxyXG4gICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cInRydWVcIj57aXRlbS5pY29ufTwvc3Bhbj5cclxuICAgICAgICAgICAge2l0ZW0ubGFiZWx9XHJcbiAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICApKX1cclxuICAgICAgPC9uYXY+XHJcblxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImxtcy1zaWRlYmFyLWZvb3RlclwiPlxyXG4gICAgICAgIDxzcGFuPkxvZ2dlZCBpbiBhczwvc3Bhbj5cclxuICAgICAgICA8c3Ryb25nPntyb2xlLnRvVXBwZXJDYXNlKCl9PC9zdHJvbmc+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9hc2lkZT5cclxuICApXHJcbn1cclxuIl19