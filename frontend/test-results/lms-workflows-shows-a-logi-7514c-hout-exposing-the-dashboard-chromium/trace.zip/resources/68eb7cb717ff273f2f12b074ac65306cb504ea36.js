import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AssignmentAttemptReviewPanel.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport2_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport2_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
import "/src/components/AssignmentAttemptReviewPanel.css";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentAttemptReviewPanel.tsx";
import __vite__cjsImport2_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
async function responseOrThrow(response) {
	if (!response.ok) {
		const data = await response.json().catch(() => null);
		const detail = data && typeof data === "object" && "detail" in data ? data.detail : null;
		throw new Error(typeof detail === "string" ? detail : `Request failed (HTTP ${response.status}).`);
	}
	return response;
}
function formatDate(value) {
	const date = new Date(value);
	return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
}
export default function AssignmentAttemptReviewPanel({ assignmentId, token, mode }) {
	_s();
	const [open, setOpen] = useState(false);
	const [submissions, setSubmissions] = useState([]);
	const [submissionId, setSubmissionId] = useState(null);
	const [attempts, setAttempts] = useState([]);
	const [drafts, setDrafts] = useState({});
	const [loadingSubmissions, setLoadingSubmissions] = useState(false);
	const [loadingAttempts, setLoadingAttempts] = useState(false);
	const [savingId, setSavingId] = useState(null);
	const [downloadingId, setDownloadingId] = useState(null);
	const [error, setError] = useState("");
	const [notice, setNotice] = useState("");
	const canReview = mode === "professor" || mode === "admin";
	useEffect(() => {
		if (!open) return;
		const controller = new AbortController();
		async function loadSubmissions() {
			setLoadingSubmissions(true);
			setError("");
			setNotice("");
			setSubmissions([]);
			setSubmissionId(null);
			setAttempts([]);
			try {
				const endpoint = canReview ? `/api/submissions/assignments/${assignmentId}` : "/api/submissions/my-submissions";
				const response = await responseOrThrow(await fetch(endpoint, {
					headers: { Authorization: `Bearer ${token}` },
					signal: controller.signal
				}));
				const data = await response.json();
				const matching = canReview ? data : data.filter((item) => item.assignment_id === assignmentId);
				if (!controller.signal.aborted) {
					setSubmissions(matching);
					setSubmissionId(matching.length > 0 ? matching[0].id : null);
				}
			} catch (err) {
				if (!controller.signal.aborted) {
					setError(err instanceof Error ? err.message : "Unable to load submissions.");
				}
			} finally {
				if (!controller.signal.aborted) setLoadingSubmissions(false);
			}
		}
		void loadSubmissions();
		return () => controller.abort();
	}, [
		open,
		assignmentId,
		token,
		canReview
	]);
	useEffect(() => {
		if (!open || submissionId === null) return;
		const controller = new AbortController();
		async function loadAttempts() {
			setLoadingAttempts(true);
			setError("");
			setNotice("");
			setAttempts([]);
			try {
				const response = await responseOrThrow(await fetch(`/api/submission-attempts/submissions/${submissionId}`, {
					headers: { Authorization: `Bearer ${token}` },
					signal: controller.signal
				}));
				const data = await response.json();
				if (!controller.signal.aborted) {
					setAttempts(data);
					setDrafts(Object.fromEntries(data.map((attempt) => [attempt.id, attempt.feedback ?? ""])));
				}
			} catch (err) {
				if (!controller.signal.aborted) {
					setError(err instanceof Error ? err.message : "Unable to load attempts.");
				}
			} finally {
				if (!controller.signal.aborted) setLoadingAttempts(false);
			}
		}
		void loadAttempts();
		return () => controller.abort();
	}, [
		open,
		submissionId,
		token
	]);
	async function saveFeedback(attempt) {
		const feedback = (drafts[attempt.id] ?? "").trim();
		if (!feedback) {
			setError("Write a comment before saving.");
			return;
		}
		setSavingId(attempt.id);
		setError("");
		setNotice("");
		try {
			const response = await responseOrThrow(await fetch(`/api/submission-attempts/${attempt.id}/feedback`, {
				method: "PUT",
				headers: {
					Authorization: `Bearer ${token}`,
					"Content-Type": "application/json"
				},
				body: JSON.stringify({ feedback })
			}));
			const updated = await response.json();
			setAttempts((previous) => previous.map((item) => item.id === updated.id ? updated : item));
			setDrafts((previous) => ({
				...previous,
				[attempt.id]: updated.feedback ?? ""
			}));
			setNotice(`Feedback saved for Attempt ${attempt.attempt_number}.`);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to save feedback.");
		} finally {
			setSavingId(null);
		}
	}
	async function downloadAttempt(attempt) {
		if (!attempt.original_filename) return;
		setDownloadingId(attempt.id);
		setError("");
		try {
			const response = await responseOrThrow(await fetch(`/api/submission-attempts/${attempt.id}/download`, { headers: { Authorization: `Bearer ${token}` } }));
			const blob = await response.blob();
			const url = URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.href = url;
			link.download = attempt.original_filename;
			document.body.appendChild(link);
			link.click();
			link.remove();
			window.setTimeout(() => URL.revokeObjectURL(url), 1e3);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to download the file.");
		} finally {
			setDownloadingId(null);
		}
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "attempt-review-panel",
		children: [/* @__PURE__ */ _jsxDEV("button", {
			type: "button",
			className: "attempt-review-toggle",
			"aria-expanded": open,
			onClick: () => setOpen((previous) => !previous),
			children: open ? "Hide submission history" : "View submission attempts and feedback"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 209,
			columnNumber: 7
		}, this), open && /* @__PURE__ */ _jsxDEV("div", {
			className: "attempt-review-body",
			children: [
				/* @__PURE__ */ _jsxDEV("h4", { children: canReview ? "Student submissions and reviews" : "My submission history" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 220,
					columnNumber: 11
				}, this),
				error && /* @__PURE__ */ _jsxDEV("p", {
					className: "attempt-review-error",
					role: "alert",
					children: error
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 221,
					columnNumber: 21
				}, this),
				notice && /* @__PURE__ */ _jsxDEV("p", {
					className: "attempt-review-success",
					role: "status",
					children: notice
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 222,
					columnNumber: 22
				}, this),
				loadingSubmissions ? /* @__PURE__ */ _jsxDEV("p", { children: "Loading submissions..." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 224,
					columnNumber: 13
				}, this) : submissions.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
					className: "attempt-review-muted",
					children: "No submissions have been recorded for this assignment."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 226,
					columnNumber: 13
				}, this) : /* @__PURE__ */ _jsxDEV(_Fragment, { children: [canReview && /* @__PURE__ */ _jsxDEV("label", {
					className: "attempt-review-student-selector",
					children: ["Select student", /* @__PURE__ */ _jsxDEV("select", {
						value: submissionId ?? "",
						onChange: (event) => setSubmissionId(Number(event.target.value)),
						children: submissions.map((submission) => /* @__PURE__ */ _jsxDEV("option", {
							value: submission.id,
							children: [
								"Student #",
								submission.student_id,
								" — Submission #",
								submission.id
							]
						}, submission.id, true, {
							fileName: _jsxFileName,
							lineNumber: 237,
							columnNumber: 23
						}, this))
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 232,
						columnNumber: 19
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 230,
					columnNumber: 17
				}, this), loadingAttempts ? /* @__PURE__ */ _jsxDEV("p", { children: "Loading attempts..." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 246,
					columnNumber: 17
				}, this) : attempts.length === 0 ? /* @__PURE__ */ _jsxDEV("p", {
					className: "attempt-review-muted",
					children: "No attempt records found for this submission."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 248,
					columnNumber: 17
				}, this) : /* @__PURE__ */ _jsxDEV("div", {
					className: "attempt-review-list",
					children: attempts.map((attempt, index) => /* @__PURE__ */ _jsxDEV("article", {
						className: "attempt-review-card",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "attempt-review-heading",
								children: [
									/* @__PURE__ */ _jsxDEV("strong", { children: ["Attempt ", attempt.attempt_number] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 254,
										columnNumber: 25
									}, this),
									index === attempts.length - 1 && /* @__PURE__ */ _jsxDEV("span", {
										className: "attempt-review-latest",
										children: "Latest"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 256,
										columnNumber: 27
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "attempt-review-date",
										children: formatDate(attempt.submitted_at)
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 258,
										columnNumber: 25
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 253,
								columnNumber: 23
							}, this),
							attempt.text_response && /* @__PURE__ */ _jsxDEV("div", {
								className: "attempt-review-response",
								children: [/* @__PURE__ */ _jsxDEV("span", {
									className: "attempt-review-caption",
									children: "Student response"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 263,
									columnNumber: 27
								}, this), /* @__PURE__ */ _jsxDEV("p", { children: attempt.text_response }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 264,
									columnNumber: 27
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 262,
								columnNumber: 25
							}, this),
							attempt.original_filename && /* @__PURE__ */ _jsxDEV("button", {
								type: "button",
								className: "attempt-review-download",
								disabled: downloadingId === attempt.id,
								onClick: () => void downloadAttempt(attempt),
								children: downloadingId === attempt.id ? "Downloading..." : `Download: ${attempt.original_filename}`
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 269,
								columnNumber: 25
							}, this),
							canReview ? /* @__PURE__ */ _jsxDEV("div", {
								className: "attempt-review-feedback",
								children: [
									/* @__PURE__ */ _jsxDEV("label", {
										htmlFor: `attempt-feedback-${attempt.id}`,
										children: ["Professor feedback for Attempt ", attempt.attempt_number]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 283,
										columnNumber: 27
									}, this),
									/* @__PURE__ */ _jsxDEV("textarea", {
										id: `attempt-feedback-${attempt.id}`,
										value: drafts[attempt.id] ?? "",
										onChange: (event) => setDrafts((previous) => ({
											...previous,
											[attempt.id]: event.target.value
										})),
										maxLength: 5e3,
										rows: 3,
										placeholder: "Write feedback for this attempt..."
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 286,
										columnNumber: 27
									}, this),
									/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "attempt-review-save",
										disabled: savingId !== null || !(drafts[attempt.id] ?? "").trim() || (drafts[attempt.id] ?? "").trim() === (attempt.feedback ?? "").trim(),
										onClick: () => void saveFeedback(attempt),
										children: savingId === attempt.id ? "Saving..." : "Save Feedback"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 300,
										columnNumber: 1
									}, this),
									attempt.reviewed_at && /* @__PURE__ */ _jsxDEV("small", {
										className: "attempt-review-date",
										children: ["Reviewed ", formatDate(attempt.reviewed_at)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 317,
										columnNumber: 29
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 282,
								columnNumber: 25
							}, this) : /* @__PURE__ */ _jsxDEV("div", {
								className: "attempt-review-feedback attempt-review-readonly",
								children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Professor feedback" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 324,
									columnNumber: 27
								}, this), /* @__PURE__ */ _jsxDEV("p", { children: attempt.feedback || "Not reviewed yet." }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 325,
									columnNumber: 27
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 323,
								columnNumber: 25
							}, this)
						]
					}, attempt.id, true, {
						fileName: _jsxFileName,
						lineNumber: 252,
						columnNumber: 21
					}, this))
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 250,
					columnNumber: 17
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 228,
					columnNumber: 13
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 219,
			columnNumber: 9
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 208,
		columnNumber: 5
	}, this);
}
_s(AssignmentAttemptReviewPanel, "SCYbqKLDwi0KDmbMfmJfDIL6iVM=");
_c = AssignmentAttemptReviewPanel;
var _c;
$RefreshReg$(_c, "AssignmentAttemptReviewPanel");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AssignmentAttemptReviewPanel.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentAttemptReviewPanel.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentAttemptReviewPanel.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentAttemptReviewPanel.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFrQztBQUN0RCxPQUFPOzs7O0FBNEJQLGVBQWUsZ0JBQWdCLFVBQXVDO0NBQ3BFLElBQUksQ0FBQyxTQUFTLElBQUk7RUFDaEIsTUFBTSxPQUFnQixNQUFNLFNBQVMsS0FBSyxDQUFDLENBQUMsWUFBWSxJQUFJO0VBQzVELE1BQU0sU0FDSixRQUFRLE9BQU8sU0FBUyxZQUFZLFlBQVksT0FDM0MsS0FBNkIsU0FDOUI7RUFDTixNQUFNLElBQUksTUFDUixPQUFPLFdBQVcsV0FDZCxTQUNBLHdCQUF3QixTQUFTLE9BQU8sR0FDOUM7Q0FDRjtDQUNBLE9BQU87QUFDVDtBQUVBLFNBQVMsV0FBVyxPQUF1QjtDQUN6QyxNQUFNLE9BQU8sSUFBSSxLQUFLLEtBQUs7Q0FDM0IsT0FBTyxPQUFPLE1BQU0sS0FBSyxRQUFRLENBQUMsSUFBSSxRQUFRLEtBQUssZUFBZTtBQUNwRTtBQUVBLGVBQWUsU0FBUyw2QkFBNkIsRUFDbkQsY0FDQSxPQUNBLFFBQ1E7O0NBQ1IsTUFBTSxDQUFDLE1BQU0sV0FBVyxTQUFTLEtBQUs7Q0FDdEMsTUFBTSxDQUFDLGFBQWEsa0JBQWtCLFNBQXVCLENBQUMsQ0FBQztDQUMvRCxNQUFNLENBQUMsY0FBYyxtQkFBbUIsU0FBd0IsSUFBSTtDQUNwRSxNQUFNLENBQUMsVUFBVSxlQUFlLFNBQW9CLENBQUMsQ0FBQztDQUN0RCxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQWlDLENBQUMsQ0FBQztDQUMvRCxNQUFNLENBQUMsb0JBQW9CLHlCQUF5QixTQUFTLEtBQUs7Q0FDbEUsTUFBTSxDQUFDLGlCQUFpQixzQkFBc0IsU0FBUyxLQUFLO0NBQzVELE1BQU0sQ0FBQyxVQUFVLGVBQWUsU0FBd0IsSUFBSTtDQUM1RCxNQUFNLENBQUMsZUFBZSxvQkFBb0IsU0FBd0IsSUFBSTtDQUN0RSxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsUUFBUSxhQUFhLFNBQVMsRUFBRTtDQUV2QyxNQUFNLFlBQVksU0FBUyxlQUFlLFNBQVM7Q0FFbkQsZ0JBQWdCO0VBQ2QsSUFBSSxDQUFDLE1BQU07RUFDWCxNQUFNLGFBQWEsSUFBSSxnQkFBZ0I7RUFFdkMsZUFBZSxrQkFBa0I7R0FDL0Isc0JBQXNCLElBQUk7R0FDMUIsU0FBUyxFQUFFO0dBQ1gsVUFBVSxFQUFFO0dBQ1osZUFBZSxDQUFDLENBQUM7R0FDakIsZ0JBQWdCLElBQUk7R0FDcEIsWUFBWSxDQUFDLENBQUM7R0FDZCxJQUFJO0lBQ0YsTUFBTSxXQUFXLFlBQ2IsZ0NBQWdDLGlCQUNoQztJQUNKLE1BQU0sV0FBVyxNQUFNLGdCQUNyQixNQUFNLE1BQU0sVUFBVTtLQUNwQixTQUFTLEVBQUUsZUFBZSxVQUFVLFFBQVE7S0FDNUMsUUFBUSxXQUFXO0lBQ3JCLENBQUMsQ0FDSDtJQUNBLE1BQU0sT0FBUSxNQUFNLFNBQVMsS0FBSztJQUNsQyxNQUFNLFdBQVcsWUFDYixPQUNBLEtBQUssUUFBUSxTQUFTLEtBQUssa0JBQWtCLFlBQVk7SUFDN0QsSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUFTO0tBQzlCLGVBQWUsUUFBUTtLQUN2QixnQkFBZ0IsU0FBUyxTQUFTLElBQUksU0FBUyxFQUFFLENBQUMsS0FBSyxJQUFJO0lBQzdEO0dBQ0YsU0FBUyxLQUFLO0lBQ1osSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUFTO0tBQzlCLFNBQVMsZUFBZSxRQUFRLElBQUksVUFBVSw2QkFBNkI7SUFDN0U7R0FDRixVQUFVO0lBQ1IsSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUFTLHNCQUFzQixLQUFLO0dBQzdEO0VBQ0Y7RUFFQSxLQUFLLGdCQUFnQjtFQUNyQixhQUFhLFdBQVcsTUFBTTtDQUNoQyxHQUFHO0VBQUM7RUFBTTtFQUFjO0VBQU87Q0FBUyxDQUFDO0NBRXpDLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxRQUFRLGlCQUFpQixNQUFNO0VBQ3BDLE1BQU0sYUFBYSxJQUFJLGdCQUFnQjtFQUV2QyxlQUFlLGVBQWU7R0FDNUIsbUJBQW1CLElBQUk7R0FDdkIsU0FBUyxFQUFFO0dBQ1gsVUFBVSxFQUFFO0dBQ1osWUFBWSxDQUFDLENBQUM7R0FDZCxJQUFJO0lBQ0YsTUFBTSxXQUFXLE1BQU0sZ0JBQ3JCLE1BQU0sTUFBTSx3Q0FBd0MsZ0JBQWdCO0tBQ2xFLFNBQVMsRUFBRSxlQUFlLFVBQVUsUUFBUTtLQUM1QyxRQUFRLFdBQVc7SUFDckIsQ0FBQyxDQUNIO0lBQ0EsTUFBTSxPQUFRLE1BQU0sU0FBUyxLQUFLO0lBQ2xDLElBQUksQ0FBQyxXQUFXLE9BQU8sU0FBUztLQUM5QixZQUFZLElBQUk7S0FDaEIsVUFDRSxPQUFPLFlBQVksS0FBSyxLQUFLLFlBQVksQ0FBQyxRQUFRLElBQUksUUFBUSxZQUFZLEVBQUUsQ0FBQyxDQUFDLENBQ2hGO0lBQ0Y7R0FDRixTQUFTLEtBQUs7SUFDWixJQUFJLENBQUMsV0FBVyxPQUFPLFNBQVM7S0FDOUIsU0FBUyxlQUFlLFFBQVEsSUFBSSxVQUFVLDBCQUEwQjtJQUMxRTtHQUNGLFVBQVU7SUFDUixJQUFJLENBQUMsV0FBVyxPQUFPLFNBQVMsbUJBQW1CLEtBQUs7R0FDMUQ7RUFDRjtFQUVBLEtBQUssYUFBYTtFQUNsQixhQUFhLFdBQVcsTUFBTTtDQUNoQyxHQUFHO0VBQUM7RUFBTTtFQUFjO0NBQUssQ0FBQztDQUU5QixlQUFlLGFBQWEsU0FBa0I7RUFDNUMsTUFBTSxZQUFZLE9BQU8sUUFBUSxPQUFPLEdBQUUsQ0FBRSxLQUFLO0VBQ2pELElBQUksQ0FBQyxVQUFVO0dBQ2IsU0FBUyxnQ0FBZ0M7R0FDekM7RUFDRjtFQUNBLFlBQVksUUFBUSxFQUFFO0VBQ3RCLFNBQVMsRUFBRTtFQUNYLFVBQVUsRUFBRTtFQUNaLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxnQkFDckIsTUFBTSxNQUFNLDRCQUE0QixRQUFRLEdBQUcsWUFBWTtJQUM3RCxRQUFRO0lBQ1IsU0FBUztLQUNQLGVBQWUsVUFBVTtLQUN6QixnQkFBZ0I7SUFDbEI7SUFDQSxNQUFNLEtBQUssVUFBVSxFQUFFLFNBQVMsQ0FBQztHQUNuQyxDQUFDLENBQ0g7R0FDQSxNQUFNLFVBQVcsTUFBTSxTQUFTLEtBQUs7R0FDckMsYUFBYSxhQUNYLFNBQVMsS0FBSyxTQUFVLEtBQUssT0FBTyxRQUFRLEtBQUssVUFBVSxJQUFLLENBQ2xFO0dBQ0EsV0FBVyxjQUFjO0lBQUUsR0FBRztLQUFXLFFBQVEsS0FBSyxRQUFRLFlBQVk7R0FBRyxFQUFFO0dBQy9FLFVBQVUsOEJBQThCLFFBQVEsZUFBZSxFQUFFO0VBQ25FLFNBQVMsS0FBSztHQUNaLFNBQVMsZUFBZSxRQUFRLElBQUksVUFBVSwwQkFBMEI7RUFDMUUsVUFBVTtHQUNSLFlBQVksSUFBSTtFQUNsQjtDQUNGO0NBRUEsZUFBZSxnQkFBZ0IsU0FBa0I7RUFDL0MsSUFBSSxDQUFDLFFBQVEsbUJBQW1CO0VBQ2hDLGlCQUFpQixRQUFRLEVBQUU7RUFDM0IsU0FBUyxFQUFFO0VBQ1gsSUFBSTtHQUNGLE1BQU0sV0FBVyxNQUFNLGdCQUNyQixNQUFNLE1BQU0sNEJBQTRCLFFBQVEsR0FBRyxZQUFZLEVBQzdELFNBQVMsRUFBRSxlQUFlLFVBQVUsUUFBUSxFQUM5QyxDQUFDLENBQ0g7R0FDQSxNQUFNLE9BQU8sTUFBTSxTQUFTLEtBQUs7R0FDakMsTUFBTSxNQUFNLElBQUksZ0JBQWdCLElBQUk7R0FDcEMsTUFBTSxPQUFPLFNBQVMsY0FBYyxHQUFHO0dBQ3ZDLEtBQUssT0FBTztHQUNaLEtBQUssV0FBVyxRQUFRO0dBQ3hCLFNBQVMsS0FBSyxZQUFZLElBQUk7R0FDOUIsS0FBSyxNQUFNO0dBQ1gsS0FBSyxPQUFPO0dBQ1osT0FBTyxpQkFBaUIsSUFBSSxnQkFBZ0IsR0FBRyxHQUFHLEdBQUk7RUFDeEQsU0FBUyxLQUFLO0dBQ1osU0FBUyxlQUFlLFFBQVEsSUFBSSxVQUFVLDhCQUE4QjtFQUM5RSxVQUFVO0dBQ1IsaUJBQWlCLElBQUk7RUFDdkI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkIsQ0FDRSx3QkFBQyxVQUFEO0dBQ0UsTUFBSztHQUNMLFdBQVU7R0FDVixpQkFBZTtHQUNmLGVBQWUsU0FBUyxhQUFhLENBQUMsUUFBUTthQUU3QyxPQUFPLDRCQUE0QjtFQUM5Qjs7OztZQUVQLFFBQ0Msd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE1BQUQsWUFBSyxZQUFZLG9DQUFvQyx3QkFBNEI7Ozs7O0lBQ2hGLFNBQVMsd0JBQUMsS0FBRDtLQUFHLFdBQVU7S0FBdUIsTUFBSztlQUFTO0lBQVM7Ozs7O0lBQ3BFLFVBQVUsd0JBQUMsS0FBRDtLQUFHLFdBQVU7S0FBeUIsTUFBSztlQUFVO0lBQVU7Ozs7O0lBQ3pFLHFCQUNDLHdCQUFDLEtBQUQsWUFBRyx5QkFBeUI7Ozs7ZUFDMUIsWUFBWSxXQUFXLElBQ3pCLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXVCO0lBQXlEOzs7O2VBRTdGLGdEQUNHLGFBQ0Msd0JBQUMsU0FBRDtLQUFPLFdBQVU7ZUFBakIsQ0FBbUQsa0JBRWpELHdCQUFDLFVBQUQ7TUFDRSxPQUFPLGdCQUFnQjtNQUN2QixXQUFXLFVBQTBDLGdCQUFnQixPQUFPLE1BQU0sT0FBTyxLQUFLLENBQUM7Z0JBRTlGLFlBQVksS0FBSyxlQUNoQix3QkFBQyxVQUFEO09BQTRCLE9BQU8sV0FBVztpQkFBOUM7UUFBa0Q7UUFDdEMsV0FBVztRQUFXO1FBQWdCLFdBQVc7T0FDckQ7U0FGSyxXQUFXOzs7O2FBRWhCLENBQ1Q7S0FDSzs7OzthQUNIOzs7OztjQUdSLGtCQUNDLHdCQUFDLEtBQUQsWUFBRyxzQkFBc0I7Ozs7ZUFDdkIsU0FBUyxXQUFXLElBQ3RCLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQXVCO0lBQWdEOzs7O2VBRXBGLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQ1osU0FBUyxLQUFLLFNBQVMsVUFDdEIsd0JBQUMsV0FBRDtNQUFTLFdBQVU7Z0JBQW5CO09BQ0Usd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWY7U0FDRSx3QkFBQyxVQUFELGFBQVEsWUFBUyxRQUFRLGNBQXVCOzs7OztTQUMvQyxVQUFVLFNBQVMsU0FBUyxLQUMzQix3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBd0I7U0FBWTs7Ozs7U0FFdEQsd0JBQUMsUUFBRDtVQUFNLFdBQVU7b0JBQXVCLFdBQVcsUUFBUSxZQUFZO1NBQVE7Ozs7O1FBQzNFOzs7Ozs7T0FFSixRQUFRLGlCQUNQLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBQ0Usd0JBQUMsUUFBRDtTQUFNLFdBQVU7bUJBQXlCO1FBQXNCOzs7O2tCQUMvRCx3QkFBQyxLQUFELFlBQUksUUFBUSxjQUFpQjs7OztnQkFDMUI7Ozs7OztPQUdOLFFBQVEscUJBQ1Asd0JBQUMsVUFBRDtRQUNFLE1BQUs7UUFDTCxXQUFVO1FBQ1YsVUFBVSxrQkFBa0IsUUFBUTtRQUNwQyxlQUFlLEtBQUssZ0JBQWdCLE9BQU87a0JBRTFDLGtCQUFrQixRQUFRLEtBQ3ZCLG1CQUNBLGFBQWEsUUFBUTtPQUNuQjs7Ozs7T0FHVCxZQUNDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmO1NBQ0Usd0JBQUMsU0FBRDtVQUFPLFNBQVMsb0JBQW9CLFFBQVE7b0JBQTVDLENBQWtELG1DQUNoQixRQUFRLGNBQ25DOzs7Ozs7U0FDUCx3QkFBQyxZQUFEO1VBQ0UsSUFBSSxvQkFBb0IsUUFBUTtVQUNoQyxPQUFPLE9BQU8sUUFBUSxPQUFPO1VBQzdCLFdBQVcsVUFDVCxXQUFXLGNBQWM7V0FDdkIsR0FBRztZQUNGLFFBQVEsS0FBSyxNQUFNLE9BQU87VUFDN0IsRUFBRTtVQUVKLFdBQVc7VUFDWCxNQUFNO1VBQ04sYUFBWTtTQUNiOzs7OztTQUUzQix3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLFdBQVU7VUFDVixVQUNFLGFBQWEsUUFDYixFQUFFLE9BQU8sUUFBUSxPQUFPLEdBQUUsQ0FBRSxLQUFLLE1BQ2hDLE9BQU8sUUFBUSxPQUFPLEdBQUUsQ0FBRSxLQUFLLE9BQzdCLFFBQVEsWUFBWSxHQUFFLENBQUUsS0FBSztVQUVsQyxlQUFlLEtBQUssYUFBYSxPQUFPO29CQUV2QyxhQUFhLFFBQVEsS0FDbEIsY0FDQTtTQUNFOzs7OztTQUVtQixRQUFRLGVBQ1Asd0JBQUMsU0FBRDtVQUFPLFdBQVU7b0JBQWpCLENBQXVDLGFBQzNCLFdBQVcsUUFBUSxXQUFXLENBQ25DOzs7Ozs7UUFFTjs7Ozs7a0JBRUwsd0JBQUMsT0FBRDtRQUFLLFdBQVU7a0JBQWYsQ0FDRSx3QkFBQyxVQUFELFlBQVEscUJBQTBCOzs7O2tCQUNsQyx3QkFBQyxLQUFELFlBQUksUUFBUSxZQUFZLG9CQUF1Qjs7OztnQkFDNUM7Ozs7OztNQUVBO1FBNUVxQyxRQUFROzs7O1lBNEU3QyxDQUNWO0lBQ0U7Ozs7WUFFUDs7Ozs7R0FFRDs7Ozs7VUFFQTs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXNzaWdubWVudEF0dGVtcHRSZXZpZXdQYW5lbC50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSwgdHlwZSBDaGFuZ2VFdmVudCB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0ICcuL0Fzc2lnbm1lbnRBdHRlbXB0UmV2aWV3UGFuZWwuY3NzJ1xuXG50eXBlIE1vZGUgPSAnc3R1ZGVudCcgfCAncHJvZmVzc29yJyB8ICdhZG1pbidcblxudHlwZSBTdWJtaXNzaW9uID0ge1xuICBpZDogbnVtYmVyXG4gIGFzc2lnbm1lbnRfaWQ6IG51bWJlclxuICBzdHVkZW50X2lkOiBudW1iZXJcbn1cblxudHlwZSBBdHRlbXB0ID0ge1xuICBpZDogbnVtYmVyXG4gIHN1Ym1pc3Npb25faWQ6IG51bWJlclxuICBhdHRlbXB0X251bWJlcjogbnVtYmVyXG4gIHRleHRfcmVzcG9uc2U6IHN0cmluZyB8IG51bGxcbiAgb3JpZ2luYWxfZmlsZW5hbWU6IHN0cmluZyB8IG51bGxcbiAgc3VibWl0dGVkX2F0OiBzdHJpbmdcbiAgZmVlZGJhY2s6IHN0cmluZyB8IG51bGxcbiAgcmV2aWV3ZWRfYnk6IG51bWJlciB8IG51bGxcbiAgcmV2aWV3ZWRfYXQ6IHN0cmluZyB8IG51bGxcbn1cblxudHlwZSBQcm9wcyA9IHtcbiAgYXNzaWdubWVudElkOiBudW1iZXJcbiAgdG9rZW46IHN0cmluZ1xuICBtb2RlOiBNb2RlXG59XG5cbmFzeW5jIGZ1bmN0aW9uIHJlc3BvbnNlT3JUaHJvdyhyZXNwb25zZTogUmVzcG9uc2UpOiBQcm9taXNlPFJlc3BvbnNlPiB7XG4gIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICBjb25zdCBkYXRhOiB1bmtub3duID0gYXdhaXQgcmVzcG9uc2UuanNvbigpLmNhdGNoKCgpID0+IG51bGwpXG4gICAgY29uc3QgZGV0YWlsID1cbiAgICAgIGRhdGEgJiYgdHlwZW9mIGRhdGEgPT09ICdvYmplY3QnICYmICdkZXRhaWwnIGluIGRhdGFcbiAgICAgICAgPyAoZGF0YSBhcyB7IGRldGFpbDogdW5rbm93biB9KS5kZXRhaWxcbiAgICAgICAgOiBudWxsXG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgdHlwZW9mIGRldGFpbCA9PT0gJ3N0cmluZydcbiAgICAgICAgPyBkZXRhaWxcbiAgICAgICAgOiBgUmVxdWVzdCBmYWlsZWQgKEhUVFAgJHtyZXNwb25zZS5zdGF0dXN9KS5gLFxuICAgIClcbiAgfVxuICByZXR1cm4gcmVzcG9uc2Vcbn1cblxuZnVuY3Rpb24gZm9ybWF0RGF0ZSh2YWx1ZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgY29uc3QgZGF0ZSA9IG5ldyBEYXRlKHZhbHVlKVxuICByZXR1cm4gTnVtYmVyLmlzTmFOKGRhdGUuZ2V0VGltZSgpKSA/IHZhbHVlIDogZGF0ZS50b0xvY2FsZVN0cmluZygpXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFzc2lnbm1lbnRBdHRlbXB0UmV2aWV3UGFuZWwoe1xuICBhc3NpZ25tZW50SWQsXG4gIHRva2VuLFxuICBtb2RlLFxufTogUHJvcHMpIHtcbiAgY29uc3QgW29wZW4sIHNldE9wZW5dID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtzdWJtaXNzaW9ucywgc2V0U3VibWlzc2lvbnNdID0gdXNlU3RhdGU8U3VibWlzc2lvbltdPihbXSlcbiAgY29uc3QgW3N1Ym1pc3Npb25JZCwgc2V0U3VibWlzc2lvbklkXSA9IHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpXG4gIGNvbnN0IFthdHRlbXB0cywgc2V0QXR0ZW1wdHNdID0gdXNlU3RhdGU8QXR0ZW1wdFtdPihbXSlcbiAgY29uc3QgW2RyYWZ0cywgc2V0RHJhZnRzXSA9IHVzZVN0YXRlPFJlY29yZDxudW1iZXIsIHN0cmluZz4+KHt9KVxuICBjb25zdCBbbG9hZGluZ1N1Ym1pc3Npb25zLCBzZXRMb2FkaW5nU3VibWlzc2lvbnNdID0gdXNlU3RhdGUoZmFsc2UpXG4gIGNvbnN0IFtsb2FkaW5nQXR0ZW1wdHMsIHNldExvYWRpbmdBdHRlbXB0c10gPSB1c2VTdGF0ZShmYWxzZSlcbiAgY29uc3QgW3NhdmluZ0lkLCBzZXRTYXZpbmdJZF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKVxuICBjb25zdCBbZG93bmxvYWRpbmdJZCwgc2V0RG93bmxvYWRpbmdJZF0gPSB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKVxuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbbm90aWNlLCBzZXROb3RpY2VdID0gdXNlU3RhdGUoJycpXG5cbiAgY29uc3QgY2FuUmV2aWV3ID0gbW9kZSA9PT0gJ3Byb2Zlc3NvcicgfHwgbW9kZSA9PT0gJ2FkbWluJ1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFvcGVuKSByZXR1cm5cbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpXG5cbiAgICBhc3luYyBmdW5jdGlvbiBsb2FkU3VibWlzc2lvbnMoKSB7XG4gICAgICBzZXRMb2FkaW5nU3VibWlzc2lvbnModHJ1ZSlcbiAgICAgIHNldEVycm9yKCcnKVxuICAgICAgc2V0Tm90aWNlKCcnKVxuICAgICAgc2V0U3VibWlzc2lvbnMoW10pXG4gICAgICBzZXRTdWJtaXNzaW9uSWQobnVsbClcbiAgICAgIHNldEF0dGVtcHRzKFtdKVxuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZW5kcG9pbnQgPSBjYW5SZXZpZXdcbiAgICAgICAgICA/IGAvYXBpL3N1Ym1pc3Npb25zL2Fzc2lnbm1lbnRzLyR7YXNzaWdubWVudElkfWBcbiAgICAgICAgICA6ICcvYXBpL3N1Ym1pc3Npb25zL215LXN1Ym1pc3Npb25zJ1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHJlc3BvbnNlT3JUaHJvdyhcbiAgICAgICAgICBhd2FpdCBmZXRjaChlbmRwb2ludCwge1xuICAgICAgICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9LFxuICAgICAgICAgICAgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCxcbiAgICAgICAgICB9KSxcbiAgICAgICAgKVxuICAgICAgICBjb25zdCBkYXRhID0gKGF3YWl0IHJlc3BvbnNlLmpzb24oKSkgYXMgU3VibWlzc2lvbltdXG4gICAgICAgIGNvbnN0IG1hdGNoaW5nID0gY2FuUmV2aWV3XG4gICAgICAgICAgPyBkYXRhXG4gICAgICAgICAgOiBkYXRhLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5hc3NpZ25tZW50X2lkID09PSBhc3NpZ25tZW50SWQpXG4gICAgICAgIGlmICghY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgICAgIHNldFN1Ym1pc3Npb25zKG1hdGNoaW5nKVxuICAgICAgICAgIHNldFN1Ym1pc3Npb25JZChtYXRjaGluZy5sZW5ndGggPiAwID8gbWF0Y2hpbmdbMF0uaWQgOiBudWxsKVxuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgaWYgKCFjb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSB7XG4gICAgICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdVbmFibGUgdG8gbG9hZCBzdWJtaXNzaW9ucy4nKVxuICAgICAgICB9XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBpZiAoIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHNldExvYWRpbmdTdWJtaXNzaW9ucyhmYWxzZSlcbiAgICAgIH1cbiAgICB9XG5cbiAgICB2b2lkIGxvYWRTdWJtaXNzaW9ucygpXG4gICAgcmV0dXJuICgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKVxuICB9LCBbb3BlbiwgYXNzaWdubWVudElkLCB0b2tlbiwgY2FuUmV2aWV3XSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghb3BlbiB8fCBzdWJtaXNzaW9uSWQgPT09IG51bGwpIHJldHVyblxuICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKClcblxuICAgIGFzeW5jIGZ1bmN0aW9uIGxvYWRBdHRlbXB0cygpIHtcbiAgICAgIHNldExvYWRpbmdBdHRlbXB0cyh0cnVlKVxuICAgICAgc2V0RXJyb3IoJycpXG4gICAgICBzZXROb3RpY2UoJycpXG4gICAgICBzZXRBdHRlbXB0cyhbXSlcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcmVzcG9uc2VPclRocm93KFxuICAgICAgICAgIGF3YWl0IGZldGNoKGAvYXBpL3N1Ym1pc3Npb24tYXR0ZW1wdHMvc3VibWlzc2lvbnMvJHtzdWJtaXNzaW9uSWR9YCwge1xuICAgICAgICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9LFxuICAgICAgICAgICAgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCxcbiAgICAgICAgICB9KSxcbiAgICAgICAgKVxuICAgICAgICBjb25zdCBkYXRhID0gKGF3YWl0IHJlc3BvbnNlLmpzb24oKSkgYXMgQXR0ZW1wdFtdXG4gICAgICAgIGlmICghY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgICAgIHNldEF0dGVtcHRzKGRhdGEpXG4gICAgICAgICAgc2V0RHJhZnRzKFxuICAgICAgICAgICAgT2JqZWN0LmZyb21FbnRyaWVzKGRhdGEubWFwKChhdHRlbXB0KSA9PiBbYXR0ZW1wdC5pZCwgYXR0ZW1wdC5mZWVkYmFjayA/PyAnJ10pKSxcbiAgICAgICAgICApXG4gICAgICAgIH1cbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBpZiAoIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcbiAgICAgICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ1VuYWJsZSB0byBsb2FkIGF0dGVtcHRzLicpXG4gICAgICAgIH1cbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIGlmICghY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkgc2V0TG9hZGluZ0F0dGVtcHRzKGZhbHNlKVxuICAgICAgfVxuICAgIH1cblxuICAgIHZvaWQgbG9hZEF0dGVtcHRzKClcbiAgICByZXR1cm4gKCkgPT4gY29udHJvbGxlci5hYm9ydCgpXG4gIH0sIFtvcGVuLCBzdWJtaXNzaW9uSWQsIHRva2VuXSlcblxuICBhc3luYyBmdW5jdGlvbiBzYXZlRmVlZGJhY2soYXR0ZW1wdDogQXR0ZW1wdCkge1xuICAgIGNvbnN0IGZlZWRiYWNrID0gKGRyYWZ0c1thdHRlbXB0LmlkXSA/PyAnJykudHJpbSgpXG4gICAgaWYgKCFmZWVkYmFjaykge1xuICAgICAgc2V0RXJyb3IoJ1dyaXRlIGEgY29tbWVudCBiZWZvcmUgc2F2aW5nLicpXG4gICAgICByZXR1cm5cbiAgICB9XG4gICAgc2V0U2F2aW5nSWQoYXR0ZW1wdC5pZClcbiAgICBzZXRFcnJvcignJylcbiAgICBzZXROb3RpY2UoJycpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcmVzcG9uc2VPclRocm93KFxuICAgICAgICBhd2FpdCBmZXRjaChgL2FwaS9zdWJtaXNzaW9uLWF0dGVtcHRzLyR7YXR0ZW1wdC5pZH0vZmVlZGJhY2tgLCB7XG4gICAgICAgICAgbWV0aG9kOiAnUFVUJyxcbiAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCxcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgfSxcbiAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7IGZlZWRiYWNrIH0pLFxuICAgICAgICB9KSxcbiAgICAgIClcbiAgICAgIGNvbnN0IHVwZGF0ZWQgPSAoYXdhaXQgcmVzcG9uc2UuanNvbigpKSBhcyBBdHRlbXB0XG4gICAgICBzZXRBdHRlbXB0cygocHJldmlvdXMpID0+XG4gICAgICAgIHByZXZpb3VzLm1hcCgoaXRlbSkgPT4gKGl0ZW0uaWQgPT09IHVwZGF0ZWQuaWQgPyB1cGRhdGVkIDogaXRlbSkpLFxuICAgICAgKVxuICAgICAgc2V0RHJhZnRzKChwcmV2aW91cykgPT4gKHsgLi4ucHJldmlvdXMsIFthdHRlbXB0LmlkXTogdXBkYXRlZC5mZWVkYmFjayA/PyAnJyB9KSlcbiAgICAgIHNldE5vdGljZShgRmVlZGJhY2sgc2F2ZWQgZm9yIEF0dGVtcHQgJHthdHRlbXB0LmF0dGVtcHRfbnVtYmVyfS5gKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdVbmFibGUgdG8gc2F2ZSBmZWVkYmFjay4nKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRTYXZpbmdJZChudWxsKVxuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGZ1bmN0aW9uIGRvd25sb2FkQXR0ZW1wdChhdHRlbXB0OiBBdHRlbXB0KSB7XG4gICAgaWYgKCFhdHRlbXB0Lm9yaWdpbmFsX2ZpbGVuYW1lKSByZXR1cm5cbiAgICBzZXREb3dubG9hZGluZ0lkKGF0dGVtcHQuaWQpXG4gICAgc2V0RXJyb3IoJycpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgcmVzcG9uc2VPclRocm93KFxuICAgICAgICBhd2FpdCBmZXRjaChgL2FwaS9zdWJtaXNzaW9uLWF0dGVtcHRzLyR7YXR0ZW1wdC5pZH0vZG93bmxvYWRgLCB7XG4gICAgICAgICAgaGVhZGVyczogeyBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCB9LFxuICAgICAgICB9KSxcbiAgICAgIClcbiAgICAgIGNvbnN0IGJsb2IgPSBhd2FpdCByZXNwb25zZS5ibG9iKClcbiAgICAgIGNvbnN0IHVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYilcbiAgICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJylcbiAgICAgIGxpbmsuaHJlZiA9IHVybFxuICAgICAgbGluay5kb3dubG9hZCA9IGF0dGVtcHQub3JpZ2luYWxfZmlsZW5hbWVcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluaylcbiAgICAgIGxpbmsuY2xpY2soKVxuICAgICAgbGluay5yZW1vdmUoKVxuICAgICAgd2luZG93LnNldFRpbWVvdXQoKCkgPT4gVVJMLnJldm9rZU9iamVjdFVSTCh1cmwpLCAxMDAwKVxuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgc2V0RXJyb3IoZXJyIGluc3RhbmNlb2YgRXJyb3IgPyBlcnIubWVzc2FnZSA6ICdVbmFibGUgdG8gZG93bmxvYWQgdGhlIGZpbGUuJylcbiAgICB9IGZpbmFsbHkge1xuICAgICAgc2V0RG93bmxvYWRpbmdJZChudWxsKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiYXR0ZW1wdC1yZXZpZXctcGFuZWxcIj5cbiAgICAgIDxidXR0b25cbiAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgIGNsYXNzTmFtZT1cImF0dGVtcHQtcmV2aWV3LXRvZ2dsZVwiXG4gICAgICAgIGFyaWEtZXhwYW5kZWQ9e29wZW59XG4gICAgICAgIG9uQ2xpY2s9eygpID0+IHNldE9wZW4oKHByZXZpb3VzKSA9PiAhcHJldmlvdXMpfVxuICAgICAgPlxuICAgICAgICB7b3BlbiA/ICdIaWRlIHN1Ym1pc3Npb24gaGlzdG9yeScgOiAnVmlldyBzdWJtaXNzaW9uIGF0dGVtcHRzIGFuZCBmZWVkYmFjayd9XG4gICAgICA8L2J1dHRvbj5cblxuICAgICAge29wZW4gJiYgKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImF0dGVtcHQtcmV2aWV3LWJvZHlcIj5cbiAgICAgICAgICA8aDQ+e2NhblJldmlldyA/ICdTdHVkZW50IHN1Ym1pc3Npb25zIGFuZCByZXZpZXdzJyA6ICdNeSBzdWJtaXNzaW9uIGhpc3RvcnknfTwvaDQ+XG4gICAgICAgICAge2Vycm9yICYmIDxwIGNsYXNzTmFtZT1cImF0dGVtcHQtcmV2aWV3LWVycm9yXCIgcm9sZT1cImFsZXJ0XCI+e2Vycm9yfTwvcD59XG4gICAgICAgICAge25vdGljZSAmJiA8cCBjbGFzc05hbWU9XCJhdHRlbXB0LXJldmlldy1zdWNjZXNzXCIgcm9sZT1cInN0YXR1c1wiPntub3RpY2V9PC9wPn1cbiAgICAgICAgICB7bG9hZGluZ1N1Ym1pc3Npb25zID8gKFxuICAgICAgICAgICAgPHA+TG9hZGluZyBzdWJtaXNzaW9ucy4uLjwvcD5cbiAgICAgICAgICApIDogc3VibWlzc2lvbnMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwiYXR0ZW1wdC1yZXZpZXctbXV0ZWRcIj5ObyBzdWJtaXNzaW9ucyBoYXZlIGJlZW4gcmVjb3JkZWQgZm9yIHRoaXMgYXNzaWdubWVudC48L3A+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDw+XG4gICAgICAgICAgICAgIHtjYW5SZXZpZXcgJiYgKFxuICAgICAgICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJhdHRlbXB0LXJldmlldy1zdHVkZW50LXNlbGVjdG9yXCI+XG4gICAgICAgICAgICAgICAgICBTZWxlY3Qgc3R1ZGVudFxuICAgICAgICAgICAgICAgICAgPHNlbGVjdFxuICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c3VibWlzc2lvbklkID8/ICcnfVxuICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGV2ZW50OiBDaGFuZ2VFdmVudDxIVE1MU2VsZWN0RWxlbWVudD4pID0+IHNldFN1Ym1pc3Npb25JZChOdW1iZXIoZXZlbnQudGFyZ2V0LnZhbHVlKSl9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHtzdWJtaXNzaW9ucy5tYXAoKHN1Ym1pc3Npb24pID0+IChcbiAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIGtleT17c3VibWlzc2lvbi5pZH0gdmFsdWU9e3N1Ym1pc3Npb24uaWR9PlxuICAgICAgICAgICAgICAgICAgICAgICAgU3R1ZGVudCAje3N1Ym1pc3Npb24uc3R1ZGVudF9pZH0g4oCUIFN1Ym1pc3Npb24gI3tzdWJtaXNzaW9uLmlkfVxuICAgICAgICAgICAgICAgICAgICAgIDwvb3B0aW9uPlxuICAgICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICAgIDwvc2VsZWN0PlxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XG4gICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAge2xvYWRpbmdBdHRlbXB0cyA/IChcbiAgICAgICAgICAgICAgICA8cD5Mb2FkaW5nIGF0dGVtcHRzLi4uPC9wPlxuICAgICAgICAgICAgICApIDogYXR0ZW1wdHMubGVuZ3RoID09PSAwID8gKFxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImF0dGVtcHQtcmV2aWV3LW11dGVkXCI+Tm8gYXR0ZW1wdCByZWNvcmRzIGZvdW5kIGZvciB0aGlzIHN1Ym1pc3Npb24uPC9wPlxuICAgICAgICAgICAgICApIDogKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXR0ZW1wdC1yZXZpZXctbGlzdFwiPlxuICAgICAgICAgICAgICAgICAge2F0dGVtcHRzLm1hcCgoYXR0ZW1wdCwgaW5kZXgpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGFydGljbGUgY2xhc3NOYW1lPVwiYXR0ZW1wdC1yZXZpZXctY2FyZFwiIGtleT17YXR0ZW1wdC5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdHRlbXB0LXJldmlldy1oZWFkaW5nXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPkF0dGVtcHQge2F0dGVtcHQuYXR0ZW1wdF9udW1iZXJ9PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgICAgICB7aW5kZXggPT09IGF0dGVtcHRzLmxlbmd0aCAtIDEgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhdHRlbXB0LXJldmlldy1sYXRlc3RcIj5MYXRlc3Q8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYXR0ZW1wdC1yZXZpZXctZGF0ZVwiPntmb3JtYXREYXRlKGF0dGVtcHQuc3VibWl0dGVkX2F0KX08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICB7YXR0ZW1wdC50ZXh0X3Jlc3BvbnNlICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXR0ZW1wdC1yZXZpZXctcmVzcG9uc2VcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYXR0ZW1wdC1yZXZpZXctY2FwdGlvblwiPlN0dWRlbnQgcmVzcG9uc2U8L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgICAgICAgIDxwPnthdHRlbXB0LnRleHRfcmVzcG9uc2V9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgKX1cblxuICAgICAgICAgICAgICAgICAgICAgIHthdHRlbXB0Lm9yaWdpbmFsX2ZpbGVuYW1lICYmIChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b25cbiAgICAgICAgICAgICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImF0dGVtcHQtcmV2aWV3LWRvd25sb2FkXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2Rvd25sb2FkaW5nSWQgPT09IGF0dGVtcHQuaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHZvaWQgZG93bmxvYWRBdHRlbXB0KGF0dGVtcHQpfVxuICAgICAgICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICAgICAgICB7ZG93bmxvYWRpbmdJZCA9PT0gYXR0ZW1wdC5pZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ0Rvd25sb2FkaW5nLi4uJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogYERvd25sb2FkOiAke2F0dGVtcHQub3JpZ2luYWxfZmlsZW5hbWV9YH1cbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICAgICl9XG5cbiAgICAgICAgICAgICAgICAgICAgICB7Y2FuUmV2aWV3ID8gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhdHRlbXB0LXJldmlldy1mZWVkYmFja1wiPlxuICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj17YGF0dGVtcHQtZmVlZGJhY2stJHthdHRlbXB0LmlkfWB9PlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByb2Zlc3NvciBmZWVkYmFjayBmb3IgQXR0ZW1wdCB7YXR0ZW1wdC5hdHRlbXB0X251bWJlcn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHRleHRhcmVhXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9e2BhdHRlbXB0LWZlZWRiYWNrLSR7YXR0ZW1wdC5pZH1gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtkcmFmdHNbYXR0ZW1wdC5pZF0gPz8gJyd9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudDogQ2hhbmdlRXZlbnQ8SFRNTFRleHRBcmVhRWxlbWVudD4pID0+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXREcmFmdHMoKHByZXZpb3VzKSA9PiAoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuLi5wcmV2aW91cyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgW2F0dGVtcHQuaWRdOiBldmVudC50YXJnZXQudmFsdWUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4TGVuZ3RoPXs1MDAwfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJvd3M9ezN9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJXcml0ZSBmZWVkYmFjayBmb3IgdGhpcyBhdHRlbXB0Li4uXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgXG48YnV0dG9uXG4gIHR5cGU9XCJidXR0b25cIlxuICBjbGFzc05hbWU9XCJhdHRlbXB0LXJldmlldy1zYXZlXCJcbiAgZGlzYWJsZWQ9e1xuICAgIHNhdmluZ0lkICE9PSBudWxsIHx8XG4gICAgIShkcmFmdHNbYXR0ZW1wdC5pZF0gPz8gJycpLnRyaW0oKSB8fFxuICAgIChkcmFmdHNbYXR0ZW1wdC5pZF0gPz8gJycpLnRyaW0oKSA9PT1cbiAgICAgIChhdHRlbXB0LmZlZWRiYWNrID8/ICcnKS50cmltKClcbiAgfVxuICBvbkNsaWNrPXsoKSA9PiB2b2lkIHNhdmVGZWVkYmFjayhhdHRlbXB0KX1cbj5cbiAge3NhdmluZ0lkID09PSBhdHRlbXB0LmlkXG4gICAgPyAnU2F2aW5nLi4uJ1xuICAgIDogJ1NhdmUgRmVlZGJhY2snfVxuPC9idXR0b24+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgICAge2F0dGVtcHQucmV2aWV3ZWRfYXQgJiYgKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzbWFsbCBjbGFzc05hbWU9XCJhdHRlbXB0LXJldmlldy1kYXRlXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICBSZXZpZXdlZCB7Zm9ybWF0RGF0ZShhdHRlbXB0LnJldmlld2VkX2F0KX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NtYWxsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgKSA6IChcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXR0ZW1wdC1yZXZpZXctZmVlZGJhY2sgYXR0ZW1wdC1yZXZpZXctcmVhZG9ubHlcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5Qcm9mZXNzb3IgZmVlZGJhY2s8L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgPHA+e2F0dGVtcHQuZmVlZGJhY2sgfHwgJ05vdCByZXZpZXdlZCB5ZXQuJ308L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgICAgICAgICA8L2FydGljbGU+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L3NlY3Rpb24+XG4gIClcbn1cbiJdfQ==