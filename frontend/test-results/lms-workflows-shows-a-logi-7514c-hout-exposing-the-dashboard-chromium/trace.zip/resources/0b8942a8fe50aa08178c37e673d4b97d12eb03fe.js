import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/RoleDashboard.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
import AssignmentProgressBadge, { getAssignmentProgress } from "/src/components/AssignmentProgress.tsx";
import "/src/components/RoleDashboard.css";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/RoleDashboard.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
export function buildStudentDashboardRows(courses, enrollments, assignments, submissions, now = Date.now()) {
	const enrolledCourseIds = new Set(enrollments.map((item) => item.course_id));
	const courseById = new Map(courses.filter((course) => enrolledCourseIds.has(course.id)).map((course) => [course.id, course]));
	const submissionByAssignment = new Map(submissions.map((submission) => [submission.assignment_id, submission]));
	return assignments.flatMap((assignment) => {
		const course = courseById.get(assignment.course_id);
		if (!course) return [];
		const submission = submissionByAssignment.get(assignment.id) ?? null;
		return [{
			assignment,
			course,
			submission,
			status: getAssignmentProgress(assignment.due_at, submission, now)
		}];
	});
}
export function buildProfessorDashboardRows(courses, assignments, submissions) {
	const courseById = new Map(courses.map((course) => [course.id, course]));
	const assignmentById = new Map(assignments.map((item) => [item.id, item]));
	return submissions.flatMap((submission) => {
		const assignment = assignmentById.get(submission.assignment_id);
		const course = assignment && courseById.get(assignment.course_id);
		return assignment && course ? [{
			assignment,
			course,
			submission
		}] : [];
	});
}
export function isPendingFinalGrade(row, now = Date.now()) {
	return Date.parse(row.assignment.due_at) <= now && row.submission.score === null;
}
async function getJson(path, token, signal) {
	const response = await fetch(path, {
		headers: { Authorization: `Bearer ${token}` },
		signal
	});
	if (!response.ok) {
		const payload = await response.json().catch(() => null);
		const message = typeof payload?.detail === "string" ? payload.detail : `Request failed (${response.status})`;
		throw new Error(message);
	}
	return await response.json();
}
function Metric({ label, value }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "rd-metric",
		children: [/* @__PURE__ */ _jsxDEV("span", { children: label }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 131,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("strong", { children: value }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 132,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 130,
		columnNumber: 5
	}, this);
}
_c = Metric;
function formatDate(date) {
	return new Date(date).toLocaleString();
}
export default function RoleDashboard({ role, token, courses, onOpenAssignment }) {
	_s();
	const normalizedRole = role.toLowerCase();
	const isStudent = normalizedRole === "student";
	const isProfessor = normalizedRole === "professor";
	const [data, setData] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState("");
	const [reloadKey, setReloadKey] = useState(0);
	const [now, setNow] = useState(() => Date.now());
	useEffect(() => {
		const timer = window.setInterval(() => setNow(Date.now()), 3e4);
		return () => window.clearInterval(timer);
	}, []);
	useEffect(() => {
		if (!isStudent && !isProfessor) {
			setLoading(false);
			return;
		}
		const controller = new AbortController();
		async function load() {
			setLoading(true);
			setError("");
			try {
				if (isStudent) {
					// /api/courses/ contains the complete catalogue for students.
					// Only fetch assignments for courses in their own enrollment list.
					const [enrollments, submissions] = await Promise.all([getJson("/api/enrollments/", token, controller.signal), getJson("/api/submissions/my-submissions", token, controller.signal)]);
					const enrolledIds = new Set(enrollments.map((item) => item.course_id));
					const assignedCourses = courses.filter((course) => enrolledIds.has(course.id));
					const perCourse = await Promise.all(assignedCourses.map((course) => getJson(`/api/assignments/courses/${course.id}`, token, controller.signal)));
					if (!controller.signal.aborted) {
						setData({
							enrollments,
							assignments: perCourse.flat(),
							submissions
						});
					}
				} else {
					// The course API already restricts professors to their assigned courses.
					const perCourse = await Promise.all(courses.map((course) => getJson(`/api/assignments/courses/${course.id}`, token, controller.signal)));
					const assignments = perCourse.flat();
					const perAssignment = await Promise.all(assignments.map((assignment) => getJson(`/api/submissions/assignments/${assignment.id}`, token, controller.signal)));
					if (!controller.signal.aborted) {
						setData({
							enrollments: [],
							assignments,
							submissions: perAssignment.flat()
						});
					}
				}
			} catch (err) {
				if (!controller.signal.aborted) {
					setData(null);
					setError(err instanceof Error ? err.message : "Unable to load dashboard.");
				}
			} finally {
				if (!controller.signal.aborted) setLoading(false);
			}
		}
		void load();
		return () => controller.abort();
	}, [
		isStudent,
		isProfessor,
		token,
		courses,
		reloadKey
	]);
	if (!isStudent && !isProfessor) return null;
	const studentRows = isStudent && data ? buildStudentDashboardRows(courses, data.enrollments, data.assignments, data.submissions, now) : [];
	const professorRows = isProfessor && data ? buildProfessorDashboardRows(courses, data.assignments, data.submissions) : [];
	const dueSoon = studentRows.filter((row) => row.status === "not-submitted" && Date.parse(row.assignment.due_at) > now && Date.parse(row.assignment.due_at) <= now + 7 * 24 * 60 * 60 * 1e3);
	const upcoming = studentRows.filter((row) => Date.parse(row.assignment.due_at) > now).sort((a, b) => Date.parse(a.assignment.due_at) - Date.parse(b.assignment.due_at)).slice(0, 8);
	const graded = studentRows.filter((row) => row.status === "graded").sort((a, b) => Date.parse(b.submission?.graded_at ?? b.submission?.submitted_at ?? "") - Date.parse(a.submission?.graded_at ?? a.submission?.submitted_at ?? "")).slice(0, 5);
	const pendingGrades = professorRows.filter((row) => isPendingFinalGrade(row, now)).sort((a, b) => Date.parse(a.assignment.due_at) - Date.parse(b.assignment.due_at));
	const recentWork = [...professorRows].sort((a, b) => Date.parse(b.submission.submitted_at) - Date.parse(a.submission.submitted_at)).slice(0, 8);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "role-dashboard",
		"aria-label": isStudent ? "Student dashboard" : "Professor dashboard",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "rd-heading",
				children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: isStudent ? "My learning overview" : "Teaching overview" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 248,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: isStudent ? "Deadlines, submissions and results across your enrolled courses." : "Assignments awaiting final grades and recently submitted student work." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 249,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 247,
					columnNumber: 9
				}, this), /* @__PURE__ */ _jsxDEV("button", {
					type: "button",
					className: "btn-secondary",
					onClick: () => setReloadKey((n) => n + 1),
					disabled: loading,
					children: loading ? "Loading..." : "Refresh dashboard"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 252,
					columnNumber: 9
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 246,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				role: "alert",
				className: "error",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 257,
				columnNumber: 17
			}, this),
			loading && /* @__PURE__ */ _jsxDEV("p", {
				role: "status",
				children: "Loading dashboard..."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 258,
				columnNumber: 19
			}, this),
			!loading && data && isStudent && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "rd-metrics",
					children: [
						/* @__PURE__ */ _jsxDEV(Metric, {
							label: "Enrolled courses",
							value: courses.filter((course) => data.enrollments.some((item) => item.course_id === course.id)).length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 263,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Metric, {
							label: "Due within 7 days (not submitted)",
							value: dueSoon.length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 265,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Metric, {
							label: "Awaiting final grading",
							value: studentRows.filter((row) => row.status === "under-review").length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 266,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Metric, {
							label: "Graded assignments",
							value: studentRows.filter((row) => row.status === "graded").length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 267,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 262,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "rd-sections",
					children: [/* @__PURE__ */ _jsxDEV("section", {
						className: "rd-panel",
						"aria-labelledby": "rd-deadlines",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							id: "rd-deadlines",
							children: "Upcoming deadlines"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 271,
							columnNumber: 15
						}, this), upcoming.length === 0 ? /* @__PURE__ */ _jsxDEV("p", { children: "No upcoming deadlines in your enrolled courses." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 272,
							columnNumber: 40
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "rd-list",
							children: upcoming.map((row) => /* @__PURE__ */ _jsxDEV("article", {
								className: "rd-item",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("strong", { children: row.assignment.title }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 277,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: [
										row.course.course_code,
										" · ",
										formatDate(row.assignment.due_at)
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 278,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV(AssignmentProgressBadge, { status: row.status }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 279,
										columnNumber: 25
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 276,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "btn-secondary",
									onClick: () => onOpenAssignment(row.course.id),
									children: "Open assignment"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 281,
									columnNumber: 23
								}, this)]
							}, row.assignment.id, true, {
								fileName: _jsxFileName,
								lineNumber: 275,
								columnNumber: 21
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 273,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 270,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("section", {
						className: "rd-panel",
						"aria-labelledby": "rd-results",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							id: "rd-results",
							children: "Recent final grades"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 290,
							columnNumber: 15
						}, this), graded.length === 0 ? /* @__PURE__ */ _jsxDEV("p", { children: "No final grades published yet." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 291,
							columnNumber: 38
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "rd-list",
							children: graded.map((row) => /* @__PURE__ */ _jsxDEV("article", {
								className: "rd-item",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("strong", { children: row.assignment.title }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 296,
									columnNumber: 25
								}, this), /* @__PURE__ */ _jsxDEV("p", { children: [
									row.course.course_code,
									" · Grade ",
									row.submission?.score,
									" / ",
									row.assignment.max_score
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 297,
									columnNumber: 25
								}, this)] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 295,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "btn-secondary",
									onClick: () => onOpenAssignment(row.course.id),
									children: "View result"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 299,
									columnNumber: 23
								}, this)]
							}, row.assignment.id, true, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 21
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 292,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 289,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 269,
					columnNumber: 11
				}, this),
				studentRows.some((row) => row.status === "missing") && /* @__PURE__ */ _jsxDEV("section", {
					className: "rd-panel",
					"aria-label": "Missing assignments",
					children: [/* @__PURE__ */ _jsxDEV("h3", { children: "Missing assignments" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 310,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("p", { children: [studentRows.filter((row) => row.status === "missing").length, " assignment(s) closed without a submission."] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 311,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 309,
					columnNumber: 13
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 261,
				columnNumber: 9
			}, this),
			!loading && data && isProfessor && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
				/* @__PURE__ */ _jsxDEV("div", {
					className: "rd-metrics",
					children: [
						/* @__PURE__ */ _jsxDEV(Metric, {
							label: "Teaching courses",
							value: courses.length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 320,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Metric, {
							label: "Assignments",
							value: data.assignments.length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 321,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Metric, {
							label: "Awaiting final grades",
							value: pendingGrades.length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 322,
							columnNumber: 13
						}, this),
						/* @__PURE__ */ _jsxDEV(Metric, {
							label: "Student submissions",
							value: professorRows.length
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 323,
							columnNumber: 13
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 319,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "rd-sections",
					children: [/* @__PURE__ */ _jsxDEV("section", {
						className: "rd-panel",
						"aria-labelledby": "rd-grading",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							id: "rd-grading",
							children: "Final grading queue"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 327,
							columnNumber: 15
						}, this), pendingGrades.length === 0 ? /* @__PURE__ */ _jsxDEV("p", { children: "No submissions are currently awaiting final grades." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 328,
							columnNumber: 45
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "rd-list",
							children: pendingGrades.slice(0, 8).map((row) => /* @__PURE__ */ _jsxDEV("article", {
								className: "rd-item",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("strong", { children: row.assignment.title }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 333,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: [
										row.course.course_code,
										" · Student #",
										row.submission.student_id
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 334,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "rd-hint",
										children: "Deadline passed · Grade pending"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 335,
										columnNumber: 25
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 332,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "btn-secondary",
									onClick: () => onOpenAssignment(row.course.id),
									children: "Open grading"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 337,
									columnNumber: 23
								}, this)]
							}, row.submission.id, true, {
								fileName: _jsxFileName,
								lineNumber: 331,
								columnNumber: 21
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 329,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 326,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("section", {
						className: "rd-panel",
						"aria-labelledby": "rd-recent",
						children: [/* @__PURE__ */ _jsxDEV("h3", {
							id: "rd-recent",
							children: "Recent submissions"
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 346,
							columnNumber: 15
						}, this), recentWork.length === 0 ? /* @__PURE__ */ _jsxDEV("p", { children: "No submissions received yet." }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 347,
							columnNumber: 42
						}, this) : /* @__PURE__ */ _jsxDEV("div", {
							className: "rd-list",
							children: recentWork.map((row) => /* @__PURE__ */ _jsxDEV("article", {
								className: "rd-item",
								children: [/* @__PURE__ */ _jsxDEV("div", { children: [
									/* @__PURE__ */ _jsxDEV("strong", { children: row.assignment.title }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 352,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("p", { children: [
										row.course.course_code,
										" · Student #",
										row.submission.student_id
									] }, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 353,
										columnNumber: 25
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: "rd-hint",
										children: ["Received ", formatDate(row.submission.submitted_at)]
									}, void 0, true, {
										fileName: _jsxFileName,
										lineNumber: 354,
										columnNumber: 25
									}, this)
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 351,
									columnNumber: 23
								}, this), /* @__PURE__ */ _jsxDEV("button", {
									type: "button",
									className: "btn-secondary",
									onClick: () => onOpenAssignment(row.course.id),
									children: "Review work"
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 356,
									columnNumber: 23
								}, this)]
							}, row.submission.id, true, {
								fileName: _jsxFileName,
								lineNumber: 350,
								columnNumber: 21
							}, this))
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 348,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 345,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 325,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("p", {
					className: "rd-note",
					children: "Individual attempt comments are available inside each course's Assignments tab. The grading queue counts submissions, not unreviewed attempts."
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 365,
					columnNumber: 11
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 318,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 245,
		columnNumber: 5
	}, this);
}
_s(RoleDashboard, "RKEQXrgMTL5VzXewj1I53me3eJE=");
_c2 = RoleDashboard;
var _c, _c2;
$RefreshReg$(_c, "Metric");
$RefreshReg$(_c2, "RoleDashboard");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/RoleDashboard.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/RoleDashboard.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/RoleDashboard.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/RoleDashboard.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxPQUFPLDJCQUNMLDZCQUVLO0FBQ1AsT0FBTzs7OztBQThDUCxPQUFPLFNBQVMsMEJBQ2QsU0FDQSxhQUNBLGFBQ0EsYUFDQSxNQUFNLEtBQUssSUFBSSxHQUNRO0NBQ3ZCLE1BQU0sb0JBQW9CLElBQUksSUFBSSxZQUFZLEtBQUssU0FBUyxLQUFLLFNBQVMsQ0FBQztDQUMzRSxNQUFNLGFBQWEsSUFBSSxJQUNyQixRQUFRLFFBQVEsV0FBVyxrQkFBa0IsSUFBSSxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQ3pELEtBQUssV0FBVyxDQUFDLE9BQU8sSUFBSSxNQUFNLENBQVUsQ0FDakQ7Q0FDQSxNQUFNLHlCQUF5QixJQUFJLElBQ2pDLFlBQVksS0FBSyxlQUFlLENBQUMsV0FBVyxlQUFlLFVBQVUsQ0FBVSxDQUNqRjtDQUVBLE9BQU8sWUFBWSxTQUFTLGVBQWU7RUFDekMsTUFBTSxTQUFTLFdBQVcsSUFBSSxXQUFXLFNBQVM7RUFDbEQsSUFBSSxDQUFDLFFBQVEsT0FBTyxDQUFDO0VBQ3JCLE1BQU0sYUFBYSx1QkFBdUIsSUFBSSxXQUFXLEVBQUUsS0FBSztFQUNoRSxPQUFPLENBQUM7R0FDTjtHQUNBO0dBQ0E7R0FDQSxRQUFRLHNCQUFzQixXQUFXLFFBQVEsWUFBWSxHQUFHO0VBQ2xFLENBQUM7Q0FDSCxDQUFDO0FBQ0g7QUFFQSxPQUFPLFNBQVMsNEJBQ2QsU0FDQSxhQUNBLGFBQ3lCO0NBQ3pCLE1BQU0sYUFBYSxJQUFJLElBQUksUUFBUSxLQUFLLFdBQVcsQ0FBQyxPQUFPLElBQUksTUFBTSxDQUFVLENBQUM7Q0FDaEYsTUFBTSxpQkFBaUIsSUFBSSxJQUFJLFlBQVksS0FBSyxTQUFTLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBVSxDQUFDO0NBQ2xGLE9BQU8sWUFBWSxTQUFTLGVBQWU7RUFDekMsTUFBTSxhQUFhLGVBQWUsSUFBSSxXQUFXLGFBQWE7RUFDOUQsTUFBTSxTQUFTLGNBQWMsV0FBVyxJQUFJLFdBQVcsU0FBUztFQUNoRSxPQUFPLGNBQWMsU0FBUyxDQUFDO0dBQUU7R0FBWTtHQUFRO0VBQVcsQ0FBQyxJQUFJLENBQUM7Q0FDeEUsQ0FBQztBQUNIO0FBRUEsT0FBTyxTQUFTLG9CQUFvQixLQUE0QixNQUFNLEtBQUssSUFBSSxHQUFHO0NBQ2hGLE9BQU8sS0FBSyxNQUFNLElBQUksV0FBVyxNQUFNLEtBQUssT0FDMUMsSUFBSSxXQUFXLFVBQVU7QUFDN0I7QUFlQSxlQUFlLFFBQVcsTUFBYyxPQUFlLFFBQWlDO0NBQ3RGLE1BQU0sV0FBVyxNQUFNLE1BQU0sTUFBTTtFQUNqQyxTQUFTLEVBQUUsZUFBZSxVQUFVLFFBQVE7RUFDNUM7Q0FDRixDQUFDO0NBQ0QsSUFBSSxDQUFDLFNBQVMsSUFBSTtFQUNoQixNQUFNLFVBQXVDLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQyxZQUFZLElBQUk7RUFDbkYsTUFBTSxVQUFVLE9BQU8sU0FBUyxXQUFXLFdBQ3ZDLFFBQVEsU0FDUixtQkFBbUIsU0FBUyxPQUFPO0VBQ3ZDLE1BQU0sSUFBSSxNQUFNLE9BQU87Q0FDekI7Q0FDQSxPQUFRLE1BQU0sU0FBUyxLQUFLO0FBQzlCO0FBRUEsU0FBUyxPQUFPLEVBQUUsT0FBTyxTQUEyQztDQUNsRSxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQWYsQ0FDRSx3QkFBQyxRQUFELFlBQU8sTUFBWTs7OztZQUNuQix3QkFBQyxVQUFELFlBQVMsTUFBYzs7OztVQUNwQjs7Ozs7O0FBRVQ7O0FBRUEsU0FBUyxXQUFXLE1BQWM7Q0FDaEMsT0FBTyxJQUFJLEtBQUssSUFBSSxDQUFDLENBQUMsZUFBZTtBQUN2QztBQUVBLGVBQWUsU0FBUyxjQUFjLEVBQUUsTUFBTSxPQUFPLFNBQVMsb0JBQTJCOztDQUN2RixNQUFNLGlCQUFpQixLQUFLLFlBQVk7Q0FDeEMsTUFBTSxZQUFZLG1CQUFtQjtDQUNyQyxNQUFNLGNBQWMsbUJBQW1CO0NBQ3ZDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBK0IsSUFBSTtDQUMzRCxNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxDQUFDO0NBQzVDLE1BQU0sQ0FBQyxLQUFLLFVBQVUsZUFBZSxLQUFLLElBQUksQ0FBQztDQUUvQyxnQkFBZ0I7RUFDZCxNQUFNLFFBQVEsT0FBTyxrQkFBa0IsT0FBTyxLQUFLLElBQUksQ0FBQyxHQUFHLEdBQUs7RUFDaEUsYUFBYSxPQUFPLGNBQWMsS0FBSztDQUN6QyxHQUFHLENBQUMsQ0FBQztDQUVMLGdCQUFnQjtFQUNkLElBQUksQ0FBQyxhQUFhLENBQUMsYUFBYTtHQUM5QixXQUFXLEtBQUs7R0FDaEI7RUFDRjtFQUNBLE1BQU0sYUFBYSxJQUFJLGdCQUFnQjtFQUV2QyxlQUFlLE9BQU87R0FDcEIsV0FBVyxJQUFJO0dBQ2YsU0FBUyxFQUFFO0dBQ1gsSUFBSTtJQUNGLElBQUksV0FBVzs7O0tBR2IsTUFBTSxDQUFDLGFBQWEsZUFBZSxNQUFNLFFBQVEsSUFBSSxDQUNuRCxRQUErQixxQkFBcUIsT0FBTyxXQUFXLE1BQU0sR0FDNUUsUUFBK0IsbUNBQW1DLE9BQU8sV0FBVyxNQUFNLENBQzVGLENBQUM7S0FDRCxNQUFNLGNBQWMsSUFBSSxJQUFJLFlBQVksS0FBSyxTQUFTLEtBQUssU0FBUyxDQUFDO0tBQ3JFLE1BQU0sa0JBQWtCLFFBQVEsUUFBUSxXQUFXLFlBQVksSUFBSSxPQUFPLEVBQUUsQ0FBQztLQUM3RSxNQUFNLFlBQVksTUFBTSxRQUFRLElBQUksZ0JBQWdCLEtBQUssV0FDdkQsUUFDRSw0QkFBNEIsT0FBTyxNQUFNLE9BQU8sV0FBVyxNQUM3RCxDQUNGLENBQUM7S0FDRCxJQUFJLENBQUMsV0FBVyxPQUFPLFNBQVM7TUFDOUIsUUFBUTtPQUFFO09BQWEsYUFBYSxVQUFVLEtBQUs7T0FBRztNQUFZLENBQUM7S0FDckU7SUFDRixPQUFPOztLQUVMLE1BQU0sWUFBWSxNQUFNLFFBQVEsSUFBSSxRQUFRLEtBQUssV0FDL0MsUUFDRSw0QkFBNEIsT0FBTyxNQUFNLE9BQU8sV0FBVyxNQUM3RCxDQUNGLENBQUM7S0FDRCxNQUFNLGNBQWMsVUFBVSxLQUFLO0tBQ25DLE1BQU0sZ0JBQWdCLE1BQU0sUUFBUSxJQUFJLFlBQVksS0FBSyxlQUN2RCxRQUNFLGdDQUFnQyxXQUFXLE1BQU0sT0FBTyxXQUFXLE1BQ3JFLENBQ0YsQ0FBQztLQUNELElBQUksQ0FBQyxXQUFXLE9BQU8sU0FBUztNQUM5QixRQUFRO09BQUUsYUFBYSxDQUFDO09BQUc7T0FBYSxhQUFhLGNBQWMsS0FBSztNQUFFLENBQUM7S0FDN0U7SUFDRjtHQUNGLFNBQVMsS0FBSztJQUNaLElBQUksQ0FBQyxXQUFXLE9BQU8sU0FBUztLQUM5QixRQUFRLElBQUk7S0FDWixTQUFTLGVBQWUsUUFBUSxJQUFJLFVBQVUsMkJBQTJCO0lBQzNFO0dBQ0YsVUFBVTtJQUNSLElBQUksQ0FBQyxXQUFXLE9BQU8sU0FBUyxXQUFXLEtBQUs7R0FDbEQ7RUFDRjtFQUVBLEtBQUssS0FBSztFQUNWLGFBQWEsV0FBVyxNQUFNO0NBQ2hDLEdBQUc7RUFBQztFQUFXO0VBQWE7RUFBTztFQUFTO0NBQVMsQ0FBQztDQUV0RCxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsT0FBTztDQUV2QyxNQUFNLGNBQWMsYUFBYSxPQUM3QiwwQkFDRSxTQUFTLEtBQUssYUFBYSxLQUFLLGFBQWEsS0FBSyxhQUFhLEdBQ2pFLElBQ0EsQ0FBQztDQUNMLE1BQU0sZ0JBQWdCLGVBQWUsT0FDakMsNEJBQTRCLFNBQVMsS0FBSyxhQUFhLEtBQUssV0FBVyxJQUN2RSxDQUFDO0NBRUwsTUFBTSxVQUFVLFlBQVksUUFBUSxRQUNsQyxJQUFJLFdBQVcsbUJBQ2YsS0FBSyxNQUFNLElBQUksV0FBVyxNQUFNLElBQUksT0FDcEMsS0FBSyxNQUFNLElBQUksV0FBVyxNQUFNLEtBQUssTUFBTSxJQUFJLEtBQUssS0FBSyxLQUFLLEdBQ2hFO0NBQ0EsTUFBTSxXQUFXLFlBQVksUUFBUSxRQUFRLEtBQUssTUFBTSxJQUFJLFdBQVcsTUFBTSxJQUFJLEdBQUcsQ0FBQyxDQUNsRixNQUFNLEdBQUcsTUFBTSxLQUFLLE1BQU0sRUFBRSxXQUFXLE1BQU0sSUFBSSxLQUFLLE1BQU0sRUFBRSxXQUFXLE1BQU0sQ0FBQyxDQUFDLENBQ2pGLE1BQU0sR0FBRyxDQUFDO0NBQ2IsTUFBTSxTQUFTLFlBQVksUUFBUSxRQUFRLElBQUksV0FBVyxRQUFRLENBQUMsQ0FDaEUsTUFBTSxHQUFHLE1BQU0sS0FBSyxNQUFNLEVBQUUsWUFBWSxhQUFhLEVBQUUsWUFBWSxnQkFBZ0IsRUFBRSxJQUNwRixLQUFLLE1BQU0sRUFBRSxZQUFZLGFBQWEsRUFBRSxZQUFZLGdCQUFnQixFQUFFLENBQUMsQ0FBQyxDQUN6RSxNQUFNLEdBQUcsQ0FBQztDQUNiLE1BQU0sZ0JBQWdCLGNBQWMsUUFBUSxRQUFRLG9CQUFvQixLQUFLLEdBQUcsQ0FBQyxDQUFDLENBQy9FLE1BQU0sR0FBRyxNQUFNLEtBQUssTUFBTSxFQUFFLFdBQVcsTUFBTSxJQUFJLEtBQUssTUFBTSxFQUFFLFdBQVcsTUFBTSxDQUFDO0NBQ25GLE1BQU0sYUFBYSxDQUFDLEdBQUcsYUFBYSxDQUFDLENBQ2xDLE1BQU0sR0FBRyxNQUFNLEtBQUssTUFBTSxFQUFFLFdBQVcsWUFBWSxJQUFJLEtBQUssTUFBTSxFQUFFLFdBQVcsWUFBWSxDQUFDLENBQUMsQ0FDN0YsTUFBTSxHQUFHLENBQUM7Q0FFYixPQUNFLHdCQUFDLFdBQUQ7RUFBUyxXQUFVO0VBQWlCLGNBQVksWUFBWSxzQkFBc0I7WUFBbEY7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUFmLENBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLE1BQUQsWUFBSyxZQUFZLHlCQUF5QixvQkFBd0I7Ozs7Y0FDbEUsd0JBQUMsS0FBRCxZQUFJLFlBQVkscUVBQ1oseUVBQTRFOzs7O1lBQzdFOzs7O2NBQ0wsd0JBQUMsVUFBRDtLQUFRLE1BQUs7S0FBUyxXQUFVO0tBQWdCLGVBQWUsY0FBYyxNQUFNLElBQUksQ0FBQztLQUFHLFVBQVU7ZUFDbEcsVUFBVSxlQUFlO0lBQ3BCOzs7O1lBQ0w7Ozs7OztHQUVKLFNBQVMsd0JBQUMsS0FBRDtJQUFHLE1BQUs7SUFBUSxXQUFVO2NBQVM7R0FBUzs7Ozs7R0FDckQsV0FBVyx3QkFBQyxLQUFEO0lBQUcsTUFBSztjQUFTO0dBQXVCOzs7OztHQUVuRCxDQUFDLFdBQVcsUUFBUSxhQUNuQjtJQUNFLHdCQUFDLE9BQUQ7S0FBSyxXQUFVO2VBQWY7TUFDRSx3QkFBQyxRQUFEO09BQVEsT0FBTTtPQUFtQixPQUFPLFFBQVEsUUFBUSxXQUN0RCxLQUFLLFlBQVksTUFBTSxTQUFTLEtBQUssY0FBYyxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7TUFBUzs7Ozs7TUFDMUUsd0JBQUMsUUFBRDtPQUFRLE9BQU07T0FBb0MsT0FBTyxRQUFRO01BQVM7Ozs7O01BQzFFLHdCQUFDLFFBQUQ7T0FBUSxPQUFNO09BQXlCLE9BQU8sWUFBWSxRQUFRLFFBQVEsSUFBSSxXQUFXLGNBQWMsQ0FBQyxDQUFDO01BQVM7Ozs7O01BQ2xILHdCQUFDLFFBQUQ7T0FBUSxPQUFNO09BQXFCLE9BQU8sWUFBWSxRQUFRLFFBQVEsSUFBSSxXQUFXLFFBQVEsQ0FBQyxDQUFDO01BQVM7Ozs7O0tBQ3JHOzs7Ozs7SUFDTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsV0FBRDtNQUFTLFdBQVU7TUFBVyxtQkFBZ0I7Z0JBQTlDLENBQ0Usd0JBQUMsTUFBRDtPQUFJLElBQUc7aUJBQWU7TUFBc0I7Ozs7Z0JBQzNDLFNBQVMsV0FBVyxJQUFJLHdCQUFDLEtBQUQsWUFBRyxrREFBa0Q7Ozs7aUJBQzVFLHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLFNBQVMsS0FBSyxRQUNiLHdCQUFDLFdBQUQ7UUFBUyxXQUFVO2tCQUFuQixDQUNFLHdCQUFDLE9BQUQ7U0FDRSx3QkFBQyxVQUFELFlBQVMsSUFBSSxXQUFXLE1BQWM7Ozs7O1NBQ3RDLHdCQUFDLEtBQUQ7VUFBSSxJQUFJLE9BQU87VUFBWTtVQUFJLFdBQVcsSUFBSSxXQUFXLE1BQU07U0FBSzs7Ozs7U0FDcEUsd0JBQUMseUJBQUQsRUFBeUIsUUFBUSxJQUFJLE9BQVM7Ozs7O1FBQzNDOzs7O2tCQUNMLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsV0FBVTtTQUFnQixlQUFlLGlCQUFpQixJQUFJLE9BQU8sRUFBRTttQkFBRztRQUV4Rjs7OztnQkFDRDtVQVR5QixJQUFJLFdBQVc7Ozs7Y0FTeEMsQ0FDVjtNQUNFOzs7O2NBRUE7Ozs7O2VBQ1Qsd0JBQUMsV0FBRDtNQUFTLFdBQVU7TUFBVyxtQkFBZ0I7Z0JBQTlDLENBQ0Usd0JBQUMsTUFBRDtPQUFJLElBQUc7aUJBQWE7TUFBdUI7Ozs7Z0JBQzFDLE9BQU8sV0FBVyxJQUFJLHdCQUFDLEtBQUQsWUFBRyxpQ0FBaUM7Ozs7aUJBQ3pELHdCQUFDLE9BQUQ7T0FBSyxXQUFVO2lCQUNaLE9BQU8sS0FBSyxRQUNYLHdCQUFDLFdBQUQ7UUFBUyxXQUFVO2tCQUFuQixDQUNFLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxVQUFELFlBQVMsSUFBSSxXQUFXLE1BQWM7Ozs7a0JBQ3RDLHdCQUFDLEtBQUQ7U0FBSSxJQUFJLE9BQU87U0FBWTtTQUFVLElBQUksWUFBWTtTQUFNO1NBQUksSUFBSSxXQUFXO1FBQWE7Ozs7Z0JBQ3hGOzs7O2tCQUNMLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsV0FBVTtTQUFnQixlQUFlLGlCQUFpQixJQUFJLE9BQU8sRUFBRTttQkFBRztRQUV4Rjs7OztnQkFDRDtVQVJ5QixJQUFJLFdBQVc7Ozs7Y0FReEMsQ0FDVjtNQUNFOzs7O2NBRUE7Ozs7O2FBQ047Ozs7OztJQUNKLFlBQVksTUFBTSxRQUFRLElBQUksV0FBVyxTQUFTLEtBQ2pELHdCQUFDLFdBQUQ7S0FBUyxXQUFVO0tBQVcsY0FBVztlQUF6QyxDQUNFLHdCQUFDLE1BQUQsWUFBSSxzQkFBdUI7Ozs7ZUFDM0Isd0JBQUMsS0FBRCxhQUFJLFlBQVksUUFBUSxRQUFRLElBQUksV0FBVyxTQUFTLENBQUMsQ0FBQyxRQUFPLDZDQUE4Qzs7OzthQUN4Rzs7Ozs7O0dBRVg7Ozs7O0dBR0gsQ0FBQyxXQUFXLFFBQVEsZUFDbkI7SUFDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmO01BQ0Usd0JBQUMsUUFBRDtPQUFRLE9BQU07T0FBbUIsT0FBTyxRQUFRO01BQVM7Ozs7O01BQ3pELHdCQUFDLFFBQUQ7T0FBUSxPQUFNO09BQWMsT0FBTyxLQUFLLFlBQVk7TUFBUzs7Ozs7TUFDN0Qsd0JBQUMsUUFBRDtPQUFRLE9BQU07T0FBd0IsT0FBTyxjQUFjO01BQVM7Ozs7O01BQ3BFLHdCQUFDLFFBQUQ7T0FBUSxPQUFNO09BQXNCLE9BQU8sY0FBYztNQUFTOzs7OztLQUMvRDs7Ozs7O0lBQ0wsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFdBQUQ7TUFBUyxXQUFVO01BQVcsbUJBQWdCO2dCQUE5QyxDQUNFLHdCQUFDLE1BQUQ7T0FBSSxJQUFHO2lCQUFhO01BQXVCOzs7O2dCQUMxQyxjQUFjLFdBQVcsSUFBSSx3QkFBQyxLQUFELFlBQUcsc0RBQXNEOzs7O2lCQUNyRix3QkFBQyxPQUFEO09BQUssV0FBVTtpQkFDWixjQUFjLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxLQUFLLFFBQzlCLHdCQUFDLFdBQUQ7UUFBUyxXQUFVO2tCQUFuQixDQUNFLHdCQUFDLE9BQUQ7U0FDRSx3QkFBQyxVQUFELFlBQVMsSUFBSSxXQUFXLE1BQWM7Ozs7O1NBQ3RDLHdCQUFDLEtBQUQ7VUFBSSxJQUFJLE9BQU87VUFBWTtVQUFhLElBQUksV0FBVztTQUFjOzs7OztTQUNyRSx3QkFBQyxRQUFEO1VBQU0sV0FBVTtvQkFBVTtTQUFxQzs7Ozs7UUFDNUQ7Ozs7a0JBQ0wsd0JBQUMsVUFBRDtTQUFRLE1BQUs7U0FBUyxXQUFVO1NBQWdCLGVBQWUsaUJBQWlCLElBQUksT0FBTyxFQUFFO21CQUFHO1FBRXhGOzs7O2dCQUNEO1VBVHlCLElBQUksV0FBVzs7OztjQVN4QyxDQUNWO01BQ0U7Ozs7Y0FFQTs7Ozs7ZUFDVCx3QkFBQyxXQUFEO01BQVMsV0FBVTtNQUFXLG1CQUFnQjtnQkFBOUMsQ0FDRSx3QkFBQyxNQUFEO09BQUksSUFBRztpQkFBWTtNQUFzQjs7OztnQkFDeEMsV0FBVyxXQUFXLElBQUksd0JBQUMsS0FBRCxZQUFHLCtCQUErQjs7OztpQkFDM0Qsd0JBQUMsT0FBRDtPQUFLLFdBQVU7aUJBQ1osV0FBVyxLQUFLLFFBQ2Ysd0JBQUMsV0FBRDtRQUFTLFdBQVU7a0JBQW5CLENBQ0Usd0JBQUMsT0FBRDtTQUNFLHdCQUFDLFVBQUQsWUFBUyxJQUFJLFdBQVcsTUFBYzs7Ozs7U0FDdEMsd0JBQUMsS0FBRDtVQUFJLElBQUksT0FBTztVQUFZO1VBQWEsSUFBSSxXQUFXO1NBQWM7Ozs7O1NBQ3JFLHdCQUFDLFFBQUQ7VUFBTSxXQUFVO29CQUFoQixDQUEwQixhQUFVLFdBQVcsSUFBSSxXQUFXLFlBQVksQ0FBUTs7Ozs7O1FBQy9FOzs7O2tCQUNMLHdCQUFDLFVBQUQ7U0FBUSxNQUFLO1NBQVMsV0FBVTtTQUFnQixlQUFlLGlCQUFpQixJQUFJLE9BQU8sRUFBRTttQkFBRztRQUV4Rjs7OztnQkFDRDtVQVR5QixJQUFJLFdBQVc7Ozs7Y0FTeEMsQ0FDVjtNQUNFOzs7O2NBRUE7Ozs7O2FBQ047Ozs7OztJQUNMLHdCQUFDLEtBQUQ7S0FBRyxXQUFVO2VBQVU7SUFBaUo7Ozs7O0dBQ3hLOzs7OztFQUVHOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJSb2xlRGFzaGJvYXJkLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQXNzaWdubWVudFByb2dyZXNzQmFkZ2UsIHtcbiAgZ2V0QXNzaWdubWVudFByb2dyZXNzLFxuICB0eXBlIEFzc2lnbm1lbnRQcm9ncmVzc1N0YXR1cyxcbn0gZnJvbSAnLi9Bc3NpZ25tZW50UHJvZ3Jlc3MnXG5pbXBvcnQgJy4vUm9sZURhc2hib2FyZC5jc3MnXG5cbmV4cG9ydCB0eXBlIERhc2hib2FyZENvdXJzZSA9IHtcbiAgaWQ6IG51bWJlclxuICB0aXRsZTogc3RyaW5nXG4gIGNvdXJzZV9jb2RlOiBzdHJpbmdcbiAgZGVzY3JpcHRpb24/OiBzdHJpbmcgfCBudWxsXG59XG5cbmV4cG9ydCB0eXBlIERhc2hib2FyZEFzc2lnbm1lbnQgPSB7XG4gIGlkOiBudW1iZXJcbiAgY291cnNlX2lkOiBudW1iZXJcbiAgdGl0bGU6IHN0cmluZ1xuICBkdWVfYXQ6IHN0cmluZ1xuICBtYXhfc2NvcmU6IG51bWJlciB8IHN0cmluZ1xufVxuXG50eXBlIERhc2hib2FyZEVucm9sbG1lbnQgPSB7XG4gIGlkOiBudW1iZXJcbiAgY291cnNlX2lkOiBudW1iZXJcbiAgc3R1ZGVudF9pZDogbnVtYmVyXG59XG5cbmV4cG9ydCB0eXBlIERhc2hib2FyZFN1Ym1pc3Npb24gPSB7XG4gIGlkOiBudW1iZXJcbiAgYXNzaWdubWVudF9pZDogbnVtYmVyXG4gIHN0dWRlbnRfaWQ6IG51bWJlclxuICBzdWJtaXR0ZWRfYXQ6IHN0cmluZ1xuICBzY29yZTogbnVtYmVyIHwgc3RyaW5nIHwgbnVsbFxuICBncmFkZWRfYXQ/OiBzdHJpbmcgfCBudWxsXG4gIGZlZWRiYWNrPzogc3RyaW5nIHwgbnVsbFxufVxuXG5leHBvcnQgdHlwZSBTdHVkZW50RGFzaGJvYXJkUm93ID0ge1xuICBhc3NpZ25tZW50OiBEYXNoYm9hcmRBc3NpZ25tZW50XG4gIGNvdXJzZTogRGFzaGJvYXJkQ291cnNlXG4gIHN1Ym1pc3Npb246IERhc2hib2FyZFN1Ym1pc3Npb24gfCBudWxsXG4gIHN0YXR1czogQXNzaWdubWVudFByb2dyZXNzU3RhdHVzXG59XG5cbmV4cG9ydCB0eXBlIFByb2Zlc3NvckRhc2hib2FyZFJvdyA9IHtcbiAgYXNzaWdubWVudDogRGFzaGJvYXJkQXNzaWdubWVudFxuICBjb3Vyc2U6IERhc2hib2FyZENvdXJzZVxuICBzdWJtaXNzaW9uOiBEYXNoYm9hcmRTdWJtaXNzaW9uXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZFN0dWRlbnREYXNoYm9hcmRSb3dzKFxuICBjb3Vyc2VzOiBEYXNoYm9hcmRDb3Vyc2VbXSxcbiAgZW5yb2xsbWVudHM6IERhc2hib2FyZEVucm9sbG1lbnRbXSxcbiAgYXNzaWdubWVudHM6IERhc2hib2FyZEFzc2lnbm1lbnRbXSxcbiAgc3VibWlzc2lvbnM6IERhc2hib2FyZFN1Ym1pc3Npb25bXSxcbiAgbm93ID0gRGF0ZS5ub3coKSxcbik6IFN0dWRlbnREYXNoYm9hcmRSb3dbXSB7XG4gIGNvbnN0IGVucm9sbGVkQ291cnNlSWRzID0gbmV3IFNldChlbnJvbGxtZW50cy5tYXAoKGl0ZW0pID0+IGl0ZW0uY291cnNlX2lkKSlcbiAgY29uc3QgY291cnNlQnlJZCA9IG5ldyBNYXAoXG4gICAgY291cnNlcy5maWx0ZXIoKGNvdXJzZSkgPT4gZW5yb2xsZWRDb3Vyc2VJZHMuaGFzKGNvdXJzZS5pZCkpXG4gICAgICAubWFwKChjb3Vyc2UpID0+IFtjb3Vyc2UuaWQsIGNvdXJzZV0gYXMgY29uc3QpLFxuICApXG4gIGNvbnN0IHN1Ym1pc3Npb25CeUFzc2lnbm1lbnQgPSBuZXcgTWFwKFxuICAgIHN1Ym1pc3Npb25zLm1hcCgoc3VibWlzc2lvbikgPT4gW3N1Ym1pc3Npb24uYXNzaWdubWVudF9pZCwgc3VibWlzc2lvbl0gYXMgY29uc3QpLFxuICApXG5cbiAgcmV0dXJuIGFzc2lnbm1lbnRzLmZsYXRNYXAoKGFzc2lnbm1lbnQpID0+IHtcbiAgICBjb25zdCBjb3Vyc2UgPSBjb3Vyc2VCeUlkLmdldChhc3NpZ25tZW50LmNvdXJzZV9pZClcbiAgICBpZiAoIWNvdXJzZSkgcmV0dXJuIFtdXG4gICAgY29uc3Qgc3VibWlzc2lvbiA9IHN1Ym1pc3Npb25CeUFzc2lnbm1lbnQuZ2V0KGFzc2lnbm1lbnQuaWQpID8/IG51bGxcbiAgICByZXR1cm4gW3tcbiAgICAgIGFzc2lnbm1lbnQsXG4gICAgICBjb3Vyc2UsXG4gICAgICBzdWJtaXNzaW9uLFxuICAgICAgc3RhdHVzOiBnZXRBc3NpZ25tZW50UHJvZ3Jlc3MoYXNzaWdubWVudC5kdWVfYXQsIHN1Ym1pc3Npb24sIG5vdyksXG4gICAgfV1cbiAgfSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGJ1aWxkUHJvZmVzc29yRGFzaGJvYXJkUm93cyhcbiAgY291cnNlczogRGFzaGJvYXJkQ291cnNlW10sXG4gIGFzc2lnbm1lbnRzOiBEYXNoYm9hcmRBc3NpZ25tZW50W10sXG4gIHN1Ym1pc3Npb25zOiBEYXNoYm9hcmRTdWJtaXNzaW9uW10sXG4pOiBQcm9mZXNzb3JEYXNoYm9hcmRSb3dbXSB7XG4gIGNvbnN0IGNvdXJzZUJ5SWQgPSBuZXcgTWFwKGNvdXJzZXMubWFwKChjb3Vyc2UpID0+IFtjb3Vyc2UuaWQsIGNvdXJzZV0gYXMgY29uc3QpKVxuICBjb25zdCBhc3NpZ25tZW50QnlJZCA9IG5ldyBNYXAoYXNzaWdubWVudHMubWFwKChpdGVtKSA9PiBbaXRlbS5pZCwgaXRlbV0gYXMgY29uc3QpKVxuICByZXR1cm4gc3VibWlzc2lvbnMuZmxhdE1hcCgoc3VibWlzc2lvbikgPT4ge1xuICAgIGNvbnN0IGFzc2lnbm1lbnQgPSBhc3NpZ25tZW50QnlJZC5nZXQoc3VibWlzc2lvbi5hc3NpZ25tZW50X2lkKVxuICAgIGNvbnN0IGNvdXJzZSA9IGFzc2lnbm1lbnQgJiYgY291cnNlQnlJZC5nZXQoYXNzaWdubWVudC5jb3Vyc2VfaWQpXG4gICAgcmV0dXJuIGFzc2lnbm1lbnQgJiYgY291cnNlID8gW3sgYXNzaWdubWVudCwgY291cnNlLCBzdWJtaXNzaW9uIH1dIDogW11cbiAgfSlcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzUGVuZGluZ0ZpbmFsR3JhZGUocm93OiBQcm9mZXNzb3JEYXNoYm9hcmRSb3csIG5vdyA9IERhdGUubm93KCkpIHtcbiAgcmV0dXJuIERhdGUucGFyc2Uocm93LmFzc2lnbm1lbnQuZHVlX2F0KSA8PSBub3cgJiZcbiAgICByb3cuc3VibWlzc2lvbi5zY29yZSA9PT0gbnVsbFxufVxuXG50eXBlIERhc2hib2FyZERhdGEgPSB7XG4gIGVucm9sbG1lbnRzOiBEYXNoYm9hcmRFbnJvbGxtZW50W11cbiAgYXNzaWdubWVudHM6IERhc2hib2FyZEFzc2lnbm1lbnRbXVxuICBzdWJtaXNzaW9uczogRGFzaGJvYXJkU3VibWlzc2lvbltdXG59XG5cbnR5cGUgUHJvcHMgPSB7XG4gIHJvbGU6IHN0cmluZ1xuICB0b2tlbjogc3RyaW5nXG4gIGNvdXJzZXM6IERhc2hib2FyZENvdXJzZVtdXG4gIG9uT3BlbkFzc2lnbm1lbnQ6IChjb3Vyc2VJZDogbnVtYmVyKSA9PiB2b2lkXG59XG5cbmFzeW5jIGZ1bmN0aW9uIGdldEpzb248VD4ocGF0aDogc3RyaW5nLCB0b2tlbjogc3RyaW5nLCBzaWduYWw6IEFib3J0U2lnbmFsKTogUHJvbWlzZTxUPiB7XG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2gocGF0aCwge1xuICAgIGhlYWRlcnM6IHsgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAgfSxcbiAgICBzaWduYWwsXG4gIH0pXG4gIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICBjb25zdCBwYXlsb2FkOiB7IGRldGFpbD86IHVua25vd24gfSB8IG51bGwgPSBhd2FpdCByZXNwb25zZS5qc29uKCkuY2F0Y2goKCkgPT4gbnVsbClcbiAgICBjb25zdCBtZXNzYWdlID0gdHlwZW9mIHBheWxvYWQ/LmRldGFpbCA9PT0gJ3N0cmluZydcbiAgICAgID8gcGF5bG9hZC5kZXRhaWxcbiAgICAgIDogYFJlcXVlc3QgZmFpbGVkICgke3Jlc3BvbnNlLnN0YXR1c30pYFxuICAgIHRocm93IG5ldyBFcnJvcihtZXNzYWdlKVxuICB9XG4gIHJldHVybiAoYXdhaXQgcmVzcG9uc2UuanNvbigpKSBhcyBUXG59XG5cbmZ1bmN0aW9uIE1ldHJpYyh7IGxhYmVsLCB2YWx1ZSB9OiB7IGxhYmVsOiBzdHJpbmc7IHZhbHVlOiBudW1iZXIgfSkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmQtbWV0cmljXCI+XG4gICAgICA8c3Bhbj57bGFiZWx9PC9zcGFuPlxuICAgICAgPHN0cm9uZz57dmFsdWV9PC9zdHJvbmc+XG4gICAgPC9kaXY+XG4gIClcbn1cblxuZnVuY3Rpb24gZm9ybWF0RGF0ZShkYXRlOiBzdHJpbmcpIHtcbiAgcmV0dXJuIG5ldyBEYXRlKGRhdGUpLnRvTG9jYWxlU3RyaW5nKClcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gUm9sZURhc2hib2FyZCh7IHJvbGUsIHRva2VuLCBjb3Vyc2VzLCBvbk9wZW5Bc3NpZ25tZW50IH06IFByb3BzKSB7XG4gIGNvbnN0IG5vcm1hbGl6ZWRSb2xlID0gcm9sZS50b0xvd2VyQ2FzZSgpXG4gIGNvbnN0IGlzU3R1ZGVudCA9IG5vcm1hbGl6ZWRSb2xlID09PSAnc3R1ZGVudCdcbiAgY29uc3QgaXNQcm9mZXNzb3IgPSBub3JtYWxpemVkUm9sZSA9PT0gJ3Byb2Zlc3NvcidcbiAgY29uc3QgW2RhdGEsIHNldERhdGFdID0gdXNlU3RhdGU8RGFzaGJvYXJkRGF0YSB8IG51bGw+KG51bGwpXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtyZWxvYWRLZXksIHNldFJlbG9hZEtleV0gPSB1c2VTdGF0ZSgwKVxuICBjb25zdCBbbm93LCBzZXROb3ddID0gdXNlU3RhdGUoKCkgPT4gRGF0ZS5ub3coKSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHRpbWVyID0gd2luZG93LnNldEludGVydmFsKCgpID0+IHNldE5vdyhEYXRlLm5vdygpKSwgMzAwMDApXG4gICAgcmV0dXJuICgpID0+IHdpbmRvdy5jbGVhckludGVydmFsKHRpbWVyKVxuICB9LCBbXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICghaXNTdHVkZW50ICYmICFpc1Byb2Zlc3Nvcikge1xuICAgICAgc2V0TG9hZGluZyhmYWxzZSlcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpXG5cbiAgICBhc3luYyBmdW5jdGlvbiBsb2FkKCkge1xuICAgICAgc2V0TG9hZGluZyh0cnVlKVxuICAgICAgc2V0RXJyb3IoJycpXG4gICAgICB0cnkge1xuICAgICAgICBpZiAoaXNTdHVkZW50KSB7XG4gICAgICAgICAgLy8gL2FwaS9jb3Vyc2VzLyBjb250YWlucyB0aGUgY29tcGxldGUgY2F0YWxvZ3VlIGZvciBzdHVkZW50cy5cbiAgICAgICAgICAvLyBPbmx5IGZldGNoIGFzc2lnbm1lbnRzIGZvciBjb3Vyc2VzIGluIHRoZWlyIG93biBlbnJvbGxtZW50IGxpc3QuXG4gICAgICAgICAgY29uc3QgW2Vucm9sbG1lbnRzLCBzdWJtaXNzaW9uc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgICAgICBnZXRKc29uPERhc2hib2FyZEVucm9sbG1lbnRbXT4oJy9hcGkvZW5yb2xsbWVudHMvJywgdG9rZW4sIGNvbnRyb2xsZXIuc2lnbmFsKSxcbiAgICAgICAgICAgIGdldEpzb248RGFzaGJvYXJkU3VibWlzc2lvbltdPignL2FwaS9zdWJtaXNzaW9ucy9teS1zdWJtaXNzaW9ucycsIHRva2VuLCBjb250cm9sbGVyLnNpZ25hbCksXG4gICAgICAgICAgXSlcbiAgICAgICAgICBjb25zdCBlbnJvbGxlZElkcyA9IG5ldyBTZXQoZW5yb2xsbWVudHMubWFwKChpdGVtKSA9PiBpdGVtLmNvdXJzZV9pZCkpXG4gICAgICAgICAgY29uc3QgYXNzaWduZWRDb3Vyc2VzID0gY291cnNlcy5maWx0ZXIoKGNvdXJzZSkgPT4gZW5yb2xsZWRJZHMuaGFzKGNvdXJzZS5pZCkpXG4gICAgICAgICAgY29uc3QgcGVyQ291cnNlID0gYXdhaXQgUHJvbWlzZS5hbGwoYXNzaWduZWRDb3Vyc2VzLm1hcCgoY291cnNlKSA9PlxuICAgICAgICAgICAgZ2V0SnNvbjxEYXNoYm9hcmRBc3NpZ25tZW50W10+KFxuICAgICAgICAgICAgICBgL2FwaS9hc3NpZ25tZW50cy9jb3Vyc2VzLyR7Y291cnNlLmlkfWAsIHRva2VuLCBjb250cm9sbGVyLnNpZ25hbCxcbiAgICAgICAgICAgICksXG4gICAgICAgICAgKSlcbiAgICAgICAgICBpZiAoIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcbiAgICAgICAgICAgIHNldERhdGEoeyBlbnJvbGxtZW50cywgYXNzaWdubWVudHM6IHBlckNvdXJzZS5mbGF0KCksIHN1Ym1pc3Npb25zIH0pXG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIFRoZSBjb3Vyc2UgQVBJIGFscmVhZHkgcmVzdHJpY3RzIHByb2Zlc3NvcnMgdG8gdGhlaXIgYXNzaWduZWQgY291cnNlcy5cbiAgICAgICAgICBjb25zdCBwZXJDb3Vyc2UgPSBhd2FpdCBQcm9taXNlLmFsbChjb3Vyc2VzLm1hcCgoY291cnNlKSA9PlxuICAgICAgICAgICAgZ2V0SnNvbjxEYXNoYm9hcmRBc3NpZ25tZW50W10+KFxuICAgICAgICAgICAgICBgL2FwaS9hc3NpZ25tZW50cy9jb3Vyc2VzLyR7Y291cnNlLmlkfWAsIHRva2VuLCBjb250cm9sbGVyLnNpZ25hbCxcbiAgICAgICAgICAgICksXG4gICAgICAgICAgKSlcbiAgICAgICAgICBjb25zdCBhc3NpZ25tZW50cyA9IHBlckNvdXJzZS5mbGF0KClcbiAgICAgICAgICBjb25zdCBwZXJBc3NpZ25tZW50ID0gYXdhaXQgUHJvbWlzZS5hbGwoYXNzaWdubWVudHMubWFwKChhc3NpZ25tZW50KSA9PlxuICAgICAgICAgICAgZ2V0SnNvbjxEYXNoYm9hcmRTdWJtaXNzaW9uW10+KFxuICAgICAgICAgICAgICBgL2FwaS9zdWJtaXNzaW9ucy9hc3NpZ25tZW50cy8ke2Fzc2lnbm1lbnQuaWR9YCwgdG9rZW4sIGNvbnRyb2xsZXIuc2lnbmFsLFxuICAgICAgICAgICAgKSxcbiAgICAgICAgICApKVxuICAgICAgICAgIGlmICghY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgICAgICAgc2V0RGF0YSh7IGVucm9sbG1lbnRzOiBbXSwgYXNzaWdubWVudHMsIHN1Ym1pc3Npb25zOiBwZXJBc3NpZ25tZW50LmZsYXQoKSB9KVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGlmICghY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgICAgIHNldERhdGEobnVsbClcbiAgICAgICAgICBzZXRFcnJvcihlcnIgaW5zdGFuY2VvZiBFcnJvciA/IGVyci5tZXNzYWdlIDogJ1VuYWJsZSB0byBsb2FkIGRhc2hib2FyZC4nKVxuICAgICAgICB9XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBpZiAoIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHNldExvYWRpbmcoZmFsc2UpXG4gICAgICB9XG4gICAgfVxuXG4gICAgdm9pZCBsb2FkKClcbiAgICByZXR1cm4gKCkgPT4gY29udHJvbGxlci5hYm9ydCgpXG4gIH0sIFtpc1N0dWRlbnQsIGlzUHJvZmVzc29yLCB0b2tlbiwgY291cnNlcywgcmVsb2FkS2V5XSlcblxuICBpZiAoIWlzU3R1ZGVudCAmJiAhaXNQcm9mZXNzb3IpIHJldHVybiBudWxsXG5cbiAgY29uc3Qgc3R1ZGVudFJvd3MgPSBpc1N0dWRlbnQgJiYgZGF0YVxuICAgID8gYnVpbGRTdHVkZW50RGFzaGJvYXJkUm93cyhcbiAgICAgICAgY291cnNlcywgZGF0YS5lbnJvbGxtZW50cywgZGF0YS5hc3NpZ25tZW50cywgZGF0YS5zdWJtaXNzaW9ucywgbm93LFxuICAgICAgKVxuICAgIDogW11cbiAgY29uc3QgcHJvZmVzc29yUm93cyA9IGlzUHJvZmVzc29yICYmIGRhdGFcbiAgICA/IGJ1aWxkUHJvZmVzc29yRGFzaGJvYXJkUm93cyhjb3Vyc2VzLCBkYXRhLmFzc2lnbm1lbnRzLCBkYXRhLnN1Ym1pc3Npb25zKVxuICAgIDogW11cblxuICBjb25zdCBkdWVTb29uID0gc3R1ZGVudFJvd3MuZmlsdGVyKChyb3cpID0+XG4gICAgcm93LnN0YXR1cyA9PT0gJ25vdC1zdWJtaXR0ZWQnICYmXG4gICAgRGF0ZS5wYXJzZShyb3cuYXNzaWdubWVudC5kdWVfYXQpID4gbm93ICYmXG4gICAgRGF0ZS5wYXJzZShyb3cuYXNzaWdubWVudC5kdWVfYXQpIDw9IG5vdyArIDcgKiAyNCAqIDYwICogNjAgKiAxMDAwLFxuICApXG4gIGNvbnN0IHVwY29taW5nID0gc3R1ZGVudFJvd3MuZmlsdGVyKChyb3cpID0+IERhdGUucGFyc2Uocm93LmFzc2lnbm1lbnQuZHVlX2F0KSA+IG5vdylcbiAgICAuc29ydCgoYSwgYikgPT4gRGF0ZS5wYXJzZShhLmFzc2lnbm1lbnQuZHVlX2F0KSAtIERhdGUucGFyc2UoYi5hc3NpZ25tZW50LmR1ZV9hdCkpXG4gICAgLnNsaWNlKDAsIDgpXG4gIGNvbnN0IGdyYWRlZCA9IHN0dWRlbnRSb3dzLmZpbHRlcigocm93KSA9PiByb3cuc3RhdHVzID09PSAnZ3JhZGVkJylcbiAgICAuc29ydCgoYSwgYikgPT4gRGF0ZS5wYXJzZShiLnN1Ym1pc3Npb24/LmdyYWRlZF9hdCA/PyBiLnN1Ym1pc3Npb24/LnN1Ym1pdHRlZF9hdCA/PyAnJykgLVxuICAgICAgRGF0ZS5wYXJzZShhLnN1Ym1pc3Npb24/LmdyYWRlZF9hdCA/PyBhLnN1Ym1pc3Npb24/LnN1Ym1pdHRlZF9hdCA/PyAnJykpXG4gICAgLnNsaWNlKDAsIDUpXG4gIGNvbnN0IHBlbmRpbmdHcmFkZXMgPSBwcm9mZXNzb3JSb3dzLmZpbHRlcigocm93KSA9PiBpc1BlbmRpbmdGaW5hbEdyYWRlKHJvdywgbm93KSlcbiAgICAuc29ydCgoYSwgYikgPT4gRGF0ZS5wYXJzZShhLmFzc2lnbm1lbnQuZHVlX2F0KSAtIERhdGUucGFyc2UoYi5hc3NpZ25tZW50LmR1ZV9hdCkpXG4gIGNvbnN0IHJlY2VudFdvcmsgPSBbLi4ucHJvZmVzc29yUm93c11cbiAgICAuc29ydCgoYSwgYikgPT4gRGF0ZS5wYXJzZShiLnN1Ym1pc3Npb24uc3VibWl0dGVkX2F0KSAtIERhdGUucGFyc2UoYS5zdWJtaXNzaW9uLnN1Ym1pdHRlZF9hdCkpXG4gICAgLnNsaWNlKDAsIDgpXG5cbiAgcmV0dXJuIChcbiAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyb2xlLWRhc2hib2FyZFwiIGFyaWEtbGFiZWw9e2lzU3R1ZGVudCA/ICdTdHVkZW50IGRhc2hib2FyZCcgOiAnUHJvZmVzc29yIGRhc2hib2FyZCd9PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZC1oZWFkaW5nXCI+XG4gICAgICAgIDxkaXY+XG4gICAgICAgICAgPGgyPntpc1N0dWRlbnQgPyAnTXkgbGVhcm5pbmcgb3ZlcnZpZXcnIDogJ1RlYWNoaW5nIG92ZXJ2aWV3J308L2gyPlxuICAgICAgICAgIDxwPntpc1N0dWRlbnQgPyAnRGVhZGxpbmVzLCBzdWJtaXNzaW9ucyBhbmQgcmVzdWx0cyBhY3Jvc3MgeW91ciBlbnJvbGxlZCBjb3Vyc2VzLidcbiAgICAgICAgICAgIDogJ0Fzc2lnbm1lbnRzIGF3YWl0aW5nIGZpbmFsIGdyYWRlcyBhbmQgcmVjZW50bHkgc3VibWl0dGVkIHN0dWRlbnQgd29yay4nfTwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiBzZXRSZWxvYWRLZXkoKG4pID0+IG4gKyAxKX0gZGlzYWJsZWQ9e2xvYWRpbmd9PlxuICAgICAgICAgIHtsb2FkaW5nID8gJ0xvYWRpbmcuLi4nIDogJ1JlZnJlc2ggZGFzaGJvYXJkJ31cbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cblxuICAgICAge2Vycm9yICYmIDxwIHJvbGU9XCJhbGVydFwiIGNsYXNzTmFtZT1cImVycm9yXCI+e2Vycm9yfTwvcD59XG4gICAgICB7bG9hZGluZyAmJiA8cCByb2xlPVwic3RhdHVzXCI+TG9hZGluZyBkYXNoYm9hcmQuLi48L3A+fVxuXG4gICAgICB7IWxvYWRpbmcgJiYgZGF0YSAmJiBpc1N0dWRlbnQgJiYgKFxuICAgICAgICA8PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmQtbWV0cmljc1wiPlxuICAgICAgICAgICAgPE1ldHJpYyBsYWJlbD1cIkVucm9sbGVkIGNvdXJzZXNcIiB2YWx1ZT17Y291cnNlcy5maWx0ZXIoKGNvdXJzZSkgPT5cbiAgICAgICAgICAgICAgZGF0YS5lbnJvbGxtZW50cy5zb21lKChpdGVtKSA9PiBpdGVtLmNvdXJzZV9pZCA9PT0gY291cnNlLmlkKSkubGVuZ3RofSAvPlxuICAgICAgICAgICAgPE1ldHJpYyBsYWJlbD1cIkR1ZSB3aXRoaW4gNyBkYXlzIChub3Qgc3VibWl0dGVkKVwiIHZhbHVlPXtkdWVTb29uLmxlbmd0aH0gLz5cbiAgICAgICAgICAgIDxNZXRyaWMgbGFiZWw9XCJBd2FpdGluZyBmaW5hbCBncmFkaW5nXCIgdmFsdWU9e3N0dWRlbnRSb3dzLmZpbHRlcigocm93KSA9PiByb3cuc3RhdHVzID09PSAndW5kZXItcmV2aWV3JykubGVuZ3RofSAvPlxuICAgICAgICAgICAgPE1ldHJpYyBsYWJlbD1cIkdyYWRlZCBhc3NpZ25tZW50c1wiIHZhbHVlPXtzdHVkZW50Um93cy5maWx0ZXIoKHJvdykgPT4gcm93LnN0YXR1cyA9PT0gJ2dyYWRlZCcpLmxlbmd0aH0gLz5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJkLXNlY3Rpb25zXCI+XG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyZC1wYW5lbFwiIGFyaWEtbGFiZWxsZWRieT1cInJkLWRlYWRsaW5lc1wiPlxuICAgICAgICAgICAgICA8aDMgaWQ9XCJyZC1kZWFkbGluZXNcIj5VcGNvbWluZyBkZWFkbGluZXM8L2gzPlxuICAgICAgICAgICAgICB7dXBjb21pbmcubGVuZ3RoID09PSAwID8gPHA+Tm8gdXBjb21pbmcgZGVhZGxpbmVzIGluIHlvdXIgZW5yb2xsZWQgY291cnNlcy48L3A+IDogKFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmQtbGlzdFwiPlxuICAgICAgICAgICAgICAgICAge3VwY29taW5nLm1hcCgocm93KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInJkLWl0ZW1cIiBrZXk9e3Jvdy5hc3NpZ25tZW50LmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57cm93LmFzc2lnbm1lbnQudGl0bGV9PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cD57cm93LmNvdXJzZS5jb3Vyc2VfY29kZX0gwrcge2Zvcm1hdERhdGUocm93LmFzc2lnbm1lbnQuZHVlX2F0KX08L3A+XG4gICAgICAgICAgICAgICAgICAgICAgICA8QXNzaWdubWVudFByb2dyZXNzQmFkZ2Ugc3RhdHVzPXtyb3cuc3RhdHVzfSAvPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiBvbk9wZW5Bc3NpZ25tZW50KHJvdy5jb3Vyc2UuaWQpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIE9wZW4gYXNzaWdubWVudFxuICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgICAgICA8L2FydGljbGU+XG4gICAgICAgICAgICAgICAgICApKX1cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJkLXBhbmVsXCIgYXJpYS1sYWJlbGxlZGJ5PVwicmQtcmVzdWx0c1wiPlxuICAgICAgICAgICAgICA8aDMgaWQ9XCJyZC1yZXN1bHRzXCI+UmVjZW50IGZpbmFsIGdyYWRlczwvaDM+XG4gICAgICAgICAgICAgIHtncmFkZWQubGVuZ3RoID09PSAwID8gPHA+Tm8gZmluYWwgZ3JhZGVzIHB1Ymxpc2hlZCB5ZXQuPC9wPiA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJkLWxpc3RcIj5cbiAgICAgICAgICAgICAgICAgIHtncmFkZWQubWFwKChyb3cpID0+IChcbiAgICAgICAgICAgICAgICAgICAgPGFydGljbGUgY2xhc3NOYW1lPVwicmQtaXRlbVwiIGtleT17cm93LmFzc2lnbm1lbnQuaWR9PlxuICAgICAgICAgICAgICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nPntyb3cuYXNzaWdubWVudC50aXRsZX08L3N0cm9uZz5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxwPntyb3cuY291cnNlLmNvdXJzZV9jb2RlfSDCtyBHcmFkZSB7cm93LnN1Ym1pc3Npb24/LnNjb3JlfSAvIHtyb3cuYXNzaWdubWVudC5tYXhfc2NvcmV9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiBvbk9wZW5Bc3NpZ25tZW50KHJvdy5jb3Vyc2UuaWQpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIFZpZXcgcmVzdWx0XG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvYXJ0aWNsZT5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIHtzdHVkZW50Um93cy5zb21lKChyb3cpID0+IHJvdy5zdGF0dXMgPT09ICdtaXNzaW5nJykgJiYgKFxuICAgICAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicmQtcGFuZWxcIiBhcmlhLWxhYmVsPVwiTWlzc2luZyBhc3NpZ25tZW50c1wiPlxuICAgICAgICAgICAgICA8aDM+TWlzc2luZyBhc3NpZ25tZW50czwvaDM+XG4gICAgICAgICAgICAgIDxwPntzdHVkZW50Um93cy5maWx0ZXIoKHJvdykgPT4gcm93LnN0YXR1cyA9PT0gJ21pc3NpbmcnKS5sZW5ndGh9IGFzc2lnbm1lbnQocykgY2xvc2VkIHdpdGhvdXQgYSBzdWJtaXNzaW9uLjwvcD5cbiAgICAgICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgICApfVxuICAgICAgICA8Lz5cbiAgICAgICl9XG5cbiAgICAgIHshbG9hZGluZyAmJiBkYXRhICYmIGlzUHJvZmVzc29yICYmIChcbiAgICAgICAgPD5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJkLW1ldHJpY3NcIj5cbiAgICAgICAgICAgIDxNZXRyaWMgbGFiZWw9XCJUZWFjaGluZyBjb3Vyc2VzXCIgdmFsdWU9e2NvdXJzZXMubGVuZ3RofSAvPlxuICAgICAgICAgICAgPE1ldHJpYyBsYWJlbD1cIkFzc2lnbm1lbnRzXCIgdmFsdWU9e2RhdGEuYXNzaWdubWVudHMubGVuZ3RofSAvPlxuICAgICAgICAgICAgPE1ldHJpYyBsYWJlbD1cIkF3YWl0aW5nIGZpbmFsIGdyYWRlc1wiIHZhbHVlPXtwZW5kaW5nR3JhZGVzLmxlbmd0aH0gLz5cbiAgICAgICAgICAgIDxNZXRyaWMgbGFiZWw9XCJTdHVkZW50IHN1Ym1pc3Npb25zXCIgdmFsdWU9e3Byb2Zlc3NvclJvd3MubGVuZ3RofSAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmQtc2VjdGlvbnNcIj5cbiAgICAgICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInJkLXBhbmVsXCIgYXJpYS1sYWJlbGxlZGJ5PVwicmQtZ3JhZGluZ1wiPlxuICAgICAgICAgICAgICA8aDMgaWQ9XCJyZC1ncmFkaW5nXCI+RmluYWwgZ3JhZGluZyBxdWV1ZTwvaDM+XG4gICAgICAgICAgICAgIHtwZW5kaW5nR3JhZGVzLmxlbmd0aCA9PT0gMCA/IDxwPk5vIHN1Ym1pc3Npb25zIGFyZSBjdXJyZW50bHkgYXdhaXRpbmcgZmluYWwgZ3JhZGVzLjwvcD4gOiAoXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZC1saXN0XCI+XG4gICAgICAgICAgICAgICAgICB7cGVuZGluZ0dyYWRlcy5zbGljZSgwLCA4KS5tYXAoKHJvdykgPT4gKFxuICAgICAgICAgICAgICAgICAgICA8YXJ0aWNsZSBjbGFzc05hbWU9XCJyZC1pdGVtXCIga2V5PXtyb3cuc3VibWlzc2lvbi5pZH0+XG4gICAgICAgICAgICAgICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+e3Jvdy5hc3NpZ25tZW50LnRpdGxlfTwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHA+e3Jvdy5jb3Vyc2UuY291cnNlX2NvZGV9IMK3IFN0dWRlbnQgI3tyb3cuc3VibWlzc2lvbi5zdHVkZW50X2lkfTwvcD5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInJkLWhpbnRcIj5EZWFkbGluZSBwYXNzZWQgwrcgR3JhZGUgcGVuZGluZzwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBjbGFzc05hbWU9XCJidG4tc2Vjb25kYXJ5XCIgb25DbGljaz17KCkgPT4gb25PcGVuQXNzaWdubWVudChyb3cuY291cnNlLmlkKX0+XG4gICAgICAgICAgICAgICAgICAgICAgICBPcGVuIGdyYWRpbmdcbiAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9hcnRpY2xlPlxuICAgICAgICAgICAgICAgICAgKSl9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8L3NlY3Rpb24+XG4gICAgICAgICAgICA8c2VjdGlvbiBjbGFzc05hbWU9XCJyZC1wYW5lbFwiIGFyaWEtbGFiZWxsZWRieT1cInJkLXJlY2VudFwiPlxuICAgICAgICAgICAgICA8aDMgaWQ9XCJyZC1yZWNlbnRcIj5SZWNlbnQgc3VibWlzc2lvbnM8L2gzPlxuICAgICAgICAgICAgICB7cmVjZW50V29yay5sZW5ndGggPT09IDAgPyA8cD5ObyBzdWJtaXNzaW9ucyByZWNlaXZlZCB5ZXQuPC9wPiA6IChcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJkLWxpc3RcIj5cbiAgICAgICAgICAgICAgICAgIHtyZWNlbnRXb3JrLm1hcCgocm93KSA9PiAoXG4gICAgICAgICAgICAgICAgICAgIDxhcnRpY2xlIGNsYXNzTmFtZT1cInJkLWl0ZW1cIiBrZXk9e3Jvdy5zdWJtaXNzaW9uLmlkfT5cbiAgICAgICAgICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz57cm93LmFzc2lnbm1lbnQudGl0bGV9PC9zdHJvbmc+XG4gICAgICAgICAgICAgICAgICAgICAgICA8cD57cm93LmNvdXJzZS5jb3Vyc2VfY29kZX0gwrcgU3R1ZGVudCAje3Jvdy5zdWJtaXNzaW9uLnN0dWRlbnRfaWR9PC9wPlxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicmQtaGludFwiPlJlY2VpdmVkIHtmb3JtYXREYXRlKHJvdy5zdWJtaXNzaW9uLnN1Ym1pdHRlZF9hdCl9PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT1cImJ1dHRvblwiIGNsYXNzTmFtZT1cImJ0bi1zZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiBvbk9wZW5Bc3NpZ25tZW50KHJvdy5jb3Vyc2UuaWQpfT5cbiAgICAgICAgICAgICAgICAgICAgICAgIFJldmlldyB3b3JrXG4gICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgICAgIDwvYXJ0aWNsZT5cbiAgICAgICAgICAgICAgICAgICkpfVxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICApfVxuICAgICAgICAgICAgPC9zZWN0aW9uPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInJkLW5vdGVcIj5JbmRpdmlkdWFsIGF0dGVtcHQgY29tbWVudHMgYXJlIGF2YWlsYWJsZSBpbnNpZGUgZWFjaCBjb3Vyc2UncyBBc3NpZ25tZW50cyB0YWIuIFRoZSBncmFkaW5nIHF1ZXVlIGNvdW50cyBzdWJtaXNzaW9ucywgbm90IHVucmV2aWV3ZWQgYXR0ZW1wdHMuPC9wPlxuICAgICAgICA8Lz5cbiAgICAgICl9XG4gICAgPC9zZWN0aW9uPlxuICApXG59XG4iXX0=