import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CourseAssignments.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport9_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport9_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
import AssignmentGrading from "/src/components/AssignmentGrading.tsx";
import AssignmentAttemptReviewPanel from "/src/components/AssignmentAttemptReviewPanel.tsx";
import CreateAssignmentForm from "/src/components/CreateAssignmentForm.tsx";
import EditAssignmentForm from "/src/components/EditAssignmentForm.tsx";
import AddNewSubmissionForm from "/src/components/AddNewSubmissionForm.tsx";
import FinalSubmissionSummary from "/src/components/FinalSubmissionSummary.tsx";
import AssignmentProgressBadge, { getAssignmentProgress } from "/src/components/AssignmentProgress.tsx";
import AssignmentSubmissionForm from "/src/components/AssignmentSubmissionForm.tsx";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CourseAssignments.tsx";
import __vite__cjsImport9_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
async function readError(response) {
	const data = await response.json().catch(() => null);
	return typeof data?.detail === "string" ? data.detail : `Request failed (${response.status}).`;
}
export default function CourseAssignments({ courseId, token, role }) {
	_s();
	const [assignments, setAssignments] = useState([]);
	const [refreshKey, setRefreshKey] = useState(0);
	const [submissions, setSubmissions] = useState([]);
	const [deletingAssignmentId, setDeletingAssignmentId] = useState(null);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState("");
	const [editingAssignmentId, setEditingAssignmentId] = useState(null);
	const [now, setNow] = useState(() => Date.now());
	const isStudent = role.toLowerCase() === "student";
	const canGrade = role.toLowerCase() === "professor" || role.toLowerCase() === "admin";
	async function refreshSubmissions() {
		if (!isStudent) return;
		const response = await fetch("/api/submissions/my-submissions", { headers: { Authorization: `Bearer ${token}` } });
		if (!response.ok) {
			throw new Error(await readError(response));
		}
		const data = await response.json();
		setSubmissions(data);
	}
	useEffect(() => {
		const controller = new AbortController();
		async function loadAssignments() {
			setLoading(true);
			setError("");
			setAssignments([]);
			setSubmissions([]);
			try {
				const headers = { Authorization: `Bearer ${token}` };
				const assignmentRequest = fetch(`/api/assignments/courses/${courseId}`, {
					headers,
					signal: controller.signal
				});
				const submissionRequest = isStudent ? fetch("/api/submissions/my-submissions", {
					headers,
					signal: controller.signal
				}) : Promise.resolve(null);
				const [assignmentResponse, submissionResponse] = await Promise.all([assignmentRequest, submissionRequest]);
				if (!assignmentResponse.ok) {
					throw new Error(await readError(assignmentResponse));
				}
				const assignmentData = await assignmentResponse.json();
				let submissionData = [];
				if (submissionResponse) {
					if (!submissionResponse.ok) {
						throw new Error(await readError(submissionResponse));
					}
					submissionData = await submissionResponse.json();
				}
				if (!controller.signal.aborted) {
					setAssignments([...assignmentData].sort((a, b) => new Date(a.due_at).getTime() - new Date(b.due_at).getTime()));
					setSubmissions(submissionData);
				}
			} catch (err) {
				if (!controller.signal.aborted) {
					setError(err instanceof Error ? err.message : "Unable to load assignments.");
				}
			} finally {
				if (!controller.signal.aborted) {
					setLoading(false);
				}
			}
		}
		void loadAssignments();
		return () => controller.abort();
	}, [
		courseId,
		token,
		isStudent,
		refreshKey
	]);
	async function deleteAssignment(assignment) {
		const confirmed = window.confirm(`Are you sure you want to delete "${assignment.title}"?\n\n` + "This action cannot be undone.");
		if (!confirmed) return;
		setDeletingAssignmentId(assignment.id);
		setError("");
		try {
			const response = await fetch(`/api/assignments/${assignment.id}`, {
				method: "DELETE",
				headers: { Authorization: `Bearer ${token}` }
			});
			if (!response.ok) {
				const data = await response.json().catch(() => null);
				throw new Error(typeof data?.detail === "string" ? data.detail : `Deletion failed (${response.status}).`);
			}
			setEditingAssignmentId(null);
			// Reload assignments from the backend.
			setRefreshKey((previous) => previous + 1);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to delete assignment.");
		} finally {
			setDeletingAssignmentId(null);
		}
	}
	useEffect(() => {
		const timer = window.setInterval(() => {
			setNow(Date.now());
		}, 15e3);
		return () => window.clearInterval(timer);
	}, []);
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "panel",
		children: [
			/* @__PURE__ */ _jsxDEV("h2", { children: "Course Assignments" }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 229,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", { children: "View instructions, submit your work, and check your grades." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 231,
				columnNumber: 7
			}, this),
			(role.toLowerCase() === "professor" || role.toLowerCase() === "admin") && /* @__PURE__ */ _jsxDEV(CreateAssignmentForm, {
				courseId,
				token,
				onCreated: () => setRefreshKey((n) => n + 1)
			}, courseId, false, {
				fileName: _jsxFileName,
				lineNumber: 237,
				columnNumber: 3
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 245,
				columnNumber: 9
			}, this),
			loading ? /* @__PURE__ */ _jsxDEV("p", { children: "Loading assignments..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 251,
				columnNumber: 9
			}, this) : assignments.length === 0 ? !error && /* @__PURE__ */ _jsxDEV("p", { children: "No assignments available." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 253,
				columnNumber: 19
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "assignments-list",
				children: assignments.map((assignment) => {
					const submission = submissions.find((item) => item.assignment_id === assignment.id) ?? null;
					const pastDeadline = new Date(assignment.due_at).getTime() <= now;
					const studentStatus = getAssignmentProgress(assignment.due_at, submission, now);
					return /* @__PURE__ */ _jsxDEV("article", {
						className: "assignment-card",
						children: [
							/* @__PURE__ */ _jsxDEV("div", {
								className: "assignment-header",
								children: [
									/* @__PURE__ */ _jsxDEV("h3", { children: assignment.title }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 275,
										columnNumber: 19
									}, this),
									/* @__PURE__ */ _jsxDEV("span", {
										className: pastDeadline ? "assignment-status overdue" : "assignment-status open",
										children: pastDeadline ? "Past deadline" : "Upcoming"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 277,
										columnNumber: 19
									}, this),
									isStudent && /* @__PURE__ */ _jsxDEV(AssignmentProgressBadge, { status: studentStatus }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 289,
										columnNumber: 3
									}, this)
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 274,
								columnNumber: 17
							}, this),
							assignment.description && /* @__PURE__ */ _jsxDEV("p", { children: assignment.description }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 294,
								columnNumber: 19
							}, this),
							assignment.instructions && /* @__PURE__ */ _jsxDEV("div", {
								className: "assignment-instructions",
								children: [/* @__PURE__ */ _jsxDEV("strong", { children: "Instructions" }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 299,
									columnNumber: 21
								}, this), /* @__PURE__ */ _jsxDEV("p", { children: assignment.instructions }, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 300,
									columnNumber: 21
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 298,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("div", {
								className: "assignment-details",
								children: [/* @__PURE__ */ _jsxDEV("p", { children: [
									/* @__PURE__ */ _jsxDEV("strong", { children: "Deadline:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 306,
										columnNumber: 21
									}, this),
									" ",
									new Date(assignment.due_at).toLocaleString()
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 305,
									columnNumber: 19
								}, this), /* @__PURE__ */ _jsxDEV("p", { children: [
									/* @__PURE__ */ _jsxDEV("strong", { children: "Maximum Score:" }, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 313,
										columnNumber: 21
									}, this),
									" ",
									assignment.max_score
								] }, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 312,
									columnNumber: 19
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 304,
								columnNumber: 17
							}, this),
							canGrade && /* @__PURE__ */ _jsxDEV("div", {
								className: "assignment-manage",
								children: [editingAssignmentId !== assignment.id && /* @__PURE__ */ _jsxDEV("div", {
									className: "assignment-manage-actions",
									children: [/* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "btn-secondary",
										onClick: () => setEditingAssignmentId(assignment.id),
										children: "Edit Assignment"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 329,
										columnNumber: 9
									}, this), /* @__PURE__ */ _jsxDEV("button", {
										type: "button",
										className: "btn-danger",
										disabled: deletingAssignmentId !== null,
										onClick: () => void deleteAssignment(assignment),
										children: deletingAssignmentId === assignment.id ? "Deleting..." : "Delete Assignment"
									}, void 0, false, {
										fileName: _jsxFileName,
										lineNumber: 339,
										columnNumber: 9
									}, this)]
								}, void 0, true, {
									fileName: _jsxFileName,
									lineNumber: 327,
									columnNumber: 7
								}, this), editingAssignmentId === assignment.id && /* @__PURE__ */ _jsxDEV(EditAssignmentForm, {
									assignment,
									token,
									onSaved: () => {
										setEditingAssignmentId(null);
										setRefreshKey((n) => n + 1);
									},
									onCancel: () => setEditingAssignmentId(null)
								}, void 0, false, {
									fileName: _jsxFileName,
									lineNumber: 356,
									columnNumber: 7
								}, this)]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 324,
								columnNumber: 3
							}, this),
							isStudent && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [!pastDeadline ? /* @__PURE__ */ _jsxDEV(_Fragment, { children: [/* @__PURE__ */ _jsxDEV(AssignmentSubmissionForm, {
								assignmentId: assignment.id,
								token,
								existing: submission,
								onSubmitted: refreshSubmissions
							}, assignment.id, false, {
								fileName: _jsxFileName,
								lineNumber: 383,
								columnNumber: 9
							}, this), assignment.allow_multiple_submissions && submission && /* @__PURE__ */ _jsxDEV(AddNewSubmissionForm, {
								assignmentId: assignment.id,
								token,
								onSubmitted: refreshSubmissions
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 392,
								columnNumber: 11
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 382,
								columnNumber: 7
							}, this) : submission ? /* @__PURE__ */ _jsxDEV(FinalSubmissionSummary, {
								submissionId: submission.id,
								token,
								maxScore: assignment.max_score
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 400,
								columnNumber: 7
							}, this) : /* @__PURE__ */ _jsxDEV("p", {
								role: "status",
								children: "No submission was received before the deadline."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 406,
								columnNumber: 7
							}, this), /* @__PURE__ */ _jsxDEV(AssignmentAttemptReviewPanel, {
								assignmentId: assignment.id,
								token,
								mode: "student"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 411,
								columnNumber: 5
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 380,
								columnNumber: 3
							}, this),
							canGrade && /* @__PURE__ */ _jsxDEV(_Fragment, { children: [pastDeadline ? /* @__PURE__ */ _jsxDEV(AssignmentGrading, {
								assignmentId: assignment.id,
								maxScore: assignment.max_score,
								token
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 423,
								columnNumber: 7
							}, this) : /* @__PURE__ */ _jsxDEV("p", {
								role: "status",
								children: "Final grading opens after the assignment deadline. You can review and comment on attempts now."
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 429,
								columnNumber: 7
							}, this), /* @__PURE__ */ _jsxDEV(AssignmentAttemptReviewPanel, {
								assignmentId: assignment.id,
								token,
								mode: role.toLowerCase() === "admin" ? "admin" : "professor"
							}, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 435,
								columnNumber: 5
							}, this)] }, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 421,
								columnNumber: 3
							}, this)
						]
					}, assignment.id, true, {
						fileName: _jsxFileName,
						lineNumber: 270,
						columnNumber: 15
					}, this);
				})
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 255,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 228,
		columnNumber: 5
	}, this);
}
_s(CourseAssignments, "Tp9Nv2nOQGjE0+T8/7p2J5X1rqo=");
_c = CourseAssignments;
var _c;
$RefreshReg$(_c, "CourseAssignments");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/CourseAssignments.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CourseAssignments.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CourseAssignments.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CourseAssignments.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxPQUFPLHVCQUF1QjtBQUM5QixPQUFPLGtDQUFrQztBQUN6QyxPQUFPLDBCQUEwQjtBQUNqQyxPQUFPLHdCQUF3QjtBQUMvQixPQUFPLDBCQUEwQjtBQUNqQyxPQUFPLDRCQUE0QjtBQUNuQyxPQUFPLDJCQUNMLDZCQUNLO0FBQ1AsT0FBTyw4QkFFQTs7OztBQW9CUCxlQUFlLFVBQVUsVUFBcUM7Q0FDNUQsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQyxZQUFZLElBQUk7Q0FFbkQsT0FBTyxPQUFPLE1BQU0sV0FBVyxXQUMzQixLQUFLLFNBQ0wsbUJBQW1CLFNBQVMsT0FBTztBQUN6QztBQUVBLGVBQWUsU0FBUyxrQkFBa0IsRUFDeEMsVUFDQSxPQUNBLFFBQ1E7O0NBQ1IsTUFBTSxDQUFDLGFBQWEsa0JBQ2xCLFNBQXVCLENBQUMsQ0FBQztDQUMzQixNQUFNLENBQUMsWUFBWSxpQkFBaUIsU0FBUyxDQUFDO0NBQzlDLE1BQU0sQ0FBQyxhQUFhLGtCQUNsQixTQUE4QixDQUFDLENBQUM7Q0FDbEMsTUFBTSxDQUFDLHNCQUFzQiwyQkFDN0IsU0FBd0IsSUFBSTtDQUM1QixNQUFNLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSTtDQUMzQyxNQUFNLENBQUMsT0FBTyxZQUFZLFNBQVMsRUFBRTtDQUNyQyxNQUFNLENBQUMscUJBQXFCLDBCQUM1QixTQUF3QixJQUFJO0NBQzVCLE1BQU0sQ0FBQyxLQUFLLFVBQVUsZUFBZSxLQUFLLElBQUksQ0FBQztDQUMvQyxNQUFNLFlBQVksS0FBSyxZQUFZLE1BQU07Q0FDekMsTUFBTSxXQUNOLEtBQUssWUFBWSxNQUFNLGVBQ3ZCLEtBQUssWUFBWSxNQUFNO0NBQ3ZCLGVBQWUscUJBQXFCO0VBQ2xDLElBQUksQ0FBQyxXQUFXO0VBRWhCLE1BQU0sV0FBVyxNQUFNLE1BQ3JCLG1DQUNBLEVBQ0UsU0FBUyxFQUNQLGVBQWUsVUFBVSxRQUMzQixFQUNGLENBQ0Y7RUFFQSxJQUFJLENBQUMsU0FBUyxJQUFJO0dBQ2hCLE1BQU0sSUFBSSxNQUFNLE1BQU0sVUFBVSxRQUFRLENBQUM7RUFDM0M7RUFFQSxNQUFNLE9BQTRCLE1BQU0sU0FBUyxLQUFLO0VBQ3RELGVBQWUsSUFBSTtDQUNyQjtDQUVBLGdCQUFnQjtFQUNkLE1BQU0sYUFBYSxJQUFJLGdCQUFnQjtFQUV2QyxlQUFlLGtCQUFrQjtHQUMvQixXQUFXLElBQUk7R0FDZixTQUFTLEVBQUU7R0FDWCxlQUFlLENBQUMsQ0FBQztHQUNqQixlQUFlLENBQUMsQ0FBQztHQUVqQixJQUFJO0lBQ0YsTUFBTSxVQUFVLEVBQ2QsZUFBZSxVQUFVLFFBQzNCO0lBRUEsTUFBTSxvQkFBb0IsTUFDeEIsNEJBQTRCLFlBQzVCO0tBQ0U7S0FDQSxRQUFRLFdBQVc7SUFDckIsQ0FDRjtJQUVBLE1BQU0sb0JBQW9CLFlBQ3RCLE1BQU0sbUNBQW1DO0tBQ3ZDO0tBQ0EsUUFBUSxXQUFXO0lBQ3JCLENBQUMsSUFDRCxRQUFRLFFBQVEsSUFBSTtJQUV4QixNQUFNLENBQUMsb0JBQW9CLHNCQUN6QixNQUFNLFFBQVEsSUFBSSxDQUNoQixtQkFDQSxpQkFDRixDQUFDO0lBRUgsSUFBSSxDQUFDLG1CQUFtQixJQUFJO0tBQzFCLE1BQU0sSUFBSSxNQUNSLE1BQU0sVUFBVSxrQkFBa0IsQ0FDcEM7SUFDRjtJQUVBLE1BQU0saUJBQ0osTUFBTSxtQkFBbUIsS0FBSztJQUVoQyxJQUFJLGlCQUFzQyxDQUFDO0lBRTNDLElBQUksb0JBQW9CO0tBQ3RCLElBQUksQ0FBQyxtQkFBbUIsSUFBSTtNQUMxQixNQUFNLElBQUksTUFDUixNQUFNLFVBQVUsa0JBQWtCLENBQ3BDO0tBQ0Y7S0FFQSxpQkFBaUIsTUFBTSxtQkFBbUIsS0FBSztJQUNqRDtJQUVBLElBQUksQ0FBQyxXQUFXLE9BQU8sU0FBUztLQUM5QixlQUNFLENBQUMsR0FBRyxjQUFjLENBQUMsQ0FBQyxNQUNqQixHQUFHLE1BQ0YsSUFBSSxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUMsUUFBUSxJQUMzQixJQUFJLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQyxRQUFRLENBQy9CLENBQ0Y7S0FFQSxlQUFlLGNBQWM7SUFDL0I7R0FDRixTQUFTLEtBQUs7SUFDWixJQUFJLENBQUMsV0FBVyxPQUFPLFNBQVM7S0FDOUIsU0FDRSxlQUFlLFFBQ1gsSUFBSSxVQUNKLDZCQUNOO0lBQ0Y7R0FDRixVQUFVO0lBQ1IsSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUFTO0tBQzlCLFdBQVcsS0FBSztJQUNsQjtHQUNGO0VBQ0Y7RUFFQSxLQUFLLGdCQUFnQjtFQUVyQixhQUFhLFdBQVcsTUFBTTtDQUNoQyxHQUFHO0VBQUM7RUFBVTtFQUFPO0VBQVc7Q0FBVSxDQUFDO0NBSTdDLGVBQWUsaUJBQWlCLFlBQXdCO0VBQ3RELE1BQU0sWUFBWSxPQUFPLFFBQ3ZCLG9DQUFvQyxXQUFXLE1BQU0sVUFDckQsK0JBQ0Y7RUFFQSxJQUFJLENBQUMsV0FBVztFQUVoQix3QkFBd0IsV0FBVyxFQUFFO0VBQ3JDLFNBQVMsRUFBRTtFQUVYLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxNQUNyQixvQkFBb0IsV0FBVyxNQUMvQjtJQUNFLFFBQVE7SUFDUixTQUFTLEVBQ1AsZUFBZSxVQUFVLFFBQzNCO0dBQ0YsQ0FDRjtHQUVBLElBQUksQ0FBQyxTQUFTLElBQUk7SUFDaEIsTUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLLENBQUMsQ0FBQyxZQUFZLElBQUk7SUFFbkQsTUFBTSxJQUFJLE1BQ1IsT0FBTyxNQUFNLFdBQVcsV0FDcEIsS0FBSyxTQUNMLG9CQUFvQixTQUFTLE9BQU8sR0FDMUM7R0FDRjtHQUVBLHVCQUF1QixJQUFJOztHQUczQixlQUFlLGFBQWEsV0FBVyxDQUFDO0VBRTFDLFNBQVMsS0FBSztHQUNaLFNBQ0UsZUFBZSxRQUNYLElBQUksVUFDSiw4QkFDTjtFQUNGLFVBQVU7R0FDUix3QkFBd0IsSUFBSTtFQUM5QjtDQUNGO0NBRUEsZ0JBQWdCO0VBQ2QsTUFBTSxRQUFRLE9BQU8sa0JBQWtCO0dBQ3JDLE9BQU8sS0FBSyxJQUFJLENBQUM7RUFDbkIsR0FBRyxJQUFLO0VBRVIsYUFBYSxPQUFPLGNBQWMsS0FBSztDQUN6QyxHQUFHLENBQUMsQ0FBQztDQUNILE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkI7R0FDRSx3QkFBQyxNQUFELFlBQUkscUJBQXNCOzs7OztHQUUxQix3QkFBQyxLQUFELFlBQUcsOERBR0E7Ozs7O0lBQ1AsS0FBSyxZQUFZLE1BQU0sZUFDdkIsS0FBSyxZQUFZLE1BQU0sWUFDdkIsd0JBQUMsc0JBQUQ7SUFFWTtJQUNIO0lBQ1AsaUJBQWlCLGVBQWUsTUFBTSxJQUFJLENBQUM7R0FDNUMsR0FKTTs7OztVQUlOO0dBRUksU0FDQyx3QkFBQyxLQUFEO0lBQUcsV0FBVTtJQUFRLE1BQUs7Y0FDdkI7R0FDQTs7Ozs7R0FHSixVQUNDLHdCQUFDLEtBQUQsWUFBRyx5QkFBeUI7Ozs7Y0FDMUIsWUFBWSxXQUFXLElBQ3pCLENBQUMsU0FBUyx3QkFBQyxLQUFELFlBQUcsNEJBQTRCOzs7O2NBRXpDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ1osWUFBWSxLQUFLLGVBQWU7S0FDL0IsTUFBTSxhQUFhLFlBQVksTUFDNUIsU0FDQyxLQUFLLGtCQUFrQixXQUFXLEVBQ3RDLEtBQUs7S0FFTCxNQUFNLGVBQ2hCLElBQUksS0FBSyxXQUFXLE1BQU0sQ0FBQyxDQUFDLFFBQVEsS0FBSztLQUMzQyxNQUFNLGdCQUFnQixzQkFDcEIsV0FBVyxRQUNYLFlBQ0EsR0FDRjtLQUNZLE9BQ0Usd0JBQUMsV0FBRDtNQUVFLFdBQVU7Z0JBRlo7T0FJRSx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZjtTQUNFLHdCQUFDLE1BQUQsWUFBSyxXQUFXLE1BQVU7Ozs7O1NBRTFCLHdCQUFDLFFBQUQ7VUFDRSxXQUNFLGVBQ0ksOEJBQ0E7b0JBR0wsZUFDRyxrQkFDQTtTQUNBOzs7OztTQUNMLGFBQ2pCLHdCQUFDLHlCQUFELEVBQXlCLFFBQVEsY0FBZ0I7Ozs7O1FBRTlCOzs7Ozs7T0FFSixXQUFXLGVBQ1Ysd0JBQUMsS0FBRCxZQUFJLFdBQVcsWUFBZTs7Ozs7T0FHL0IsV0FBVyxnQkFDVix3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLFVBQUQsWUFBUSxlQUFvQjs7OztrQkFDNUIsd0JBQUMsS0FBRCxZQUFJLFdBQVcsYUFBZ0I7Ozs7Z0JBQzVCOzs7Ozs7T0FHUCx3QkFBQyxPQUFEO1FBQUssV0FBVTtrQkFBZixDQUNFLHdCQUFDLEtBQUQ7U0FDRSx3QkFBQyxVQUFELFlBQVEsWUFBaUI7Ozs7O1NBQUU7U0FDMUIsSUFBSSxLQUNILFdBQVcsTUFDYixDQUFDLENBQUMsZUFBZTtRQUNoQjs7OztrQkFFSCx3QkFBQyxLQUFEO1NBQ0Usd0JBQUMsVUFBRCxZQUFRLGlCQUFzQjs7Ozs7U0FBRTtTQUMvQixXQUFXO1FBQ1g7Ozs7Z0JBR0E7Ozs7OztPQUtwQixZQUNDLHdCQUFDLE9BQUQ7UUFBSyxXQUFVO2tCQUFmLENBRUcsd0JBQXdCLFdBQVcsTUFDbEMsd0JBQUMsT0FBRDtTQUFLLFdBQVU7bUJBQWYsQ0FFRSx3QkFBQyxVQUFEO1VBQ0UsTUFBSztVQUNMLFdBQVU7VUFDVixlQUNFLHVCQUF1QixXQUFXLEVBQUU7b0JBRXZDO1NBRU87Ozs7bUJBRVIsd0JBQUMsVUFBRDtVQUNFLE1BQUs7VUFDTCxXQUFVO1VBQ1YsVUFBVSx5QkFBeUI7VUFDbkMsZUFDRSxLQUFLLGlCQUFpQixVQUFVO29CQUdqQyx5QkFBeUIsV0FBVyxLQUNqQyxnQkFDQTtTQUNFOzs7O2lCQUVMOzs7OztrQkFHTix3QkFBd0IsV0FBVyxNQUNsQyx3QkFBQyxvQkFBRDtTQUNjO1NBQ0w7U0FDUCxlQUFlO1VBQ2IsdUJBQXVCLElBQUk7VUFDM0IsZUFBZSxNQUFNLElBQUksQ0FBQztTQUM1QjtTQUNBLGdCQUNFLHVCQUF1QixJQUFJO1FBRTlCOzs7O2dCQUdBOzs7Ozs7T0FVTixhQUNDLGdEQUNHLENBQUMsZUFDQSxnREFDRSx3QkFBQywwQkFBRDtRQUVFLGNBQWMsV0FBVztRQUNsQjtRQUNQLFVBQVU7UUFDVixhQUFhO09BQ2QsR0FMTSxXQUFXOzs7O2NBS2pCLEdBRUEsV0FBVyw4QkFBOEIsY0FDeEMsd0JBQUMsc0JBQUQ7UUFDRSxjQUFjLFdBQVc7UUFDbEI7UUFDUCxhQUFhO09BQ2Q7Ozs7ZUFFSDs7OztrQkFDQSxhQUNGLHdCQUFDLHdCQUFEO1FBQ0UsY0FBYyxXQUFXO1FBQ2xCO1FBQ1AsVUFBVSxXQUFXO09BQ3RCOzs7O2tCQUVELHdCQUFDLEtBQUQ7UUFBRyxNQUFLO2tCQUFTO09BRWQ7Ozs7aUJBR0wsd0JBQUMsOEJBQUQ7UUFDRSxjQUFjLFdBQVc7UUFDbEI7UUFDUCxNQUFLO09BQ047Ozs7ZUFDRDs7Ozs7T0FJSCxZQUNDLGdEQUNHLGVBQ0Msd0JBQUMsbUJBQUQ7UUFDRSxjQUFjLFdBQVc7UUFDekIsVUFBVSxXQUFXO1FBQ2Q7T0FDUjs7OztrQkFFRCx3QkFBQyxLQUFEO1FBQUcsTUFBSztrQkFBUztPQUdkOzs7O2lCQUdMLHdCQUFDLDhCQUFEO1FBQ0UsY0FBYyxXQUFXO1FBQ2xCO1FBQ1AsTUFDRSxLQUFLLFlBQVksTUFBTSxVQUNuQixVQUNBO09BRVA7Ozs7ZUFDRDs7Ozs7TUFHbUI7UUFoTEYsV0FBVzs7OztZQWdMVDtJQUViLENBQUM7R0FDRTs7Ozs7RUFFQTs7Ozs7O0FBRWIiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ291cnNlQXNzaWdubWVudHMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCBBc3NpZ25tZW50R3JhZGluZyBmcm9tICcuL0Fzc2lnbm1lbnRHcmFkaW5nJ1xyXG5pbXBvcnQgQXNzaWdubWVudEF0dGVtcHRSZXZpZXdQYW5lbCBmcm9tICcuL0Fzc2lnbm1lbnRBdHRlbXB0UmV2aWV3UGFuZWwnXHJcbmltcG9ydCBDcmVhdGVBc3NpZ25tZW50Rm9ybSBmcm9tICcuL0NyZWF0ZUFzc2lnbm1lbnRGb3JtJ1xyXG5pbXBvcnQgRWRpdEFzc2lnbm1lbnRGb3JtIGZyb20gJy4vRWRpdEFzc2lnbm1lbnRGb3JtJ1xyXG5pbXBvcnQgQWRkTmV3U3VibWlzc2lvbkZvcm0gZnJvbSAnLi9BZGROZXdTdWJtaXNzaW9uRm9ybSdcclxuaW1wb3J0IEZpbmFsU3VibWlzc2lvblN1bW1hcnkgZnJvbSAnLi9GaW5hbFN1Ym1pc3Npb25TdW1tYXJ5J1xyXG5pbXBvcnQgQXNzaWdubWVudFByb2dyZXNzQmFkZ2UsIHtcclxuICBnZXRBc3NpZ25tZW50UHJvZ3Jlc3MsXHJcbn0gZnJvbSAnLi9Bc3NpZ25tZW50UHJvZ3Jlc3MnXHJcbmltcG9ydCBBc3NpZ25tZW50U3VibWlzc2lvbkZvcm0sIHtcclxuICB0eXBlIFN0dWRlbnRTdWJtaXNzaW9uLFxyXG59IGZyb20gJy4vQXNzaWdubWVudFN1Ym1pc3Npb25Gb3JtJ1xyXG5cclxudHlwZSBBc3NpZ25tZW50ID0ge1xyXG4gIGlkOiBudW1iZXJcclxuICBjb3Vyc2VfaWQ6IG51bWJlclxyXG4gIHRpdGxlOiBzdHJpbmdcclxuICBkZXNjcmlwdGlvbjogc3RyaW5nIHwgbnVsbFxyXG4gIGluc3RydWN0aW9uczogc3RyaW5nIHwgbnVsbFxyXG4gIGR1ZV9hdDogc3RyaW5nXHJcbiAgbWF4X3Njb3JlOiBudW1iZXIgfCBzdHJpbmdcclxuICBjcmVhdGVkX2F0OiBzdHJpbmdcclxuICBhbGxvd19tdWx0aXBsZV9zdWJtaXNzaW9uczogYm9vbGVhblxyXG59XHJcblxyXG50eXBlIFByb3BzID0ge1xyXG4gIGNvdXJzZUlkOiBudW1iZXJcclxuICB0b2tlbjogc3RyaW5nXHJcbiAgcm9sZTogc3RyaW5nXHJcbn1cclxuXHJcbmFzeW5jIGZ1bmN0aW9uIHJlYWRFcnJvcihyZXNwb25zZTogUmVzcG9uc2UpOiBQcm9taXNlPHN0cmluZz4ge1xyXG4gIGNvbnN0IGRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCkuY2F0Y2goKCkgPT4gbnVsbClcclxuXHJcbiAgcmV0dXJuIHR5cGVvZiBkYXRhPy5kZXRhaWwgPT09ICdzdHJpbmcnXHJcbiAgICA/IGRhdGEuZGV0YWlsXHJcbiAgICA6IGBSZXF1ZXN0IGZhaWxlZCAoJHtyZXNwb25zZS5zdGF0dXN9KS5gXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvdXJzZUFzc2lnbm1lbnRzKHtcclxuICBjb3Vyc2VJZCxcclxuICB0b2tlbixcclxuICByb2xlLFxyXG59OiBQcm9wcykge1xyXG4gIGNvbnN0IFthc3NpZ25tZW50cywgc2V0QXNzaWdubWVudHNdID1cclxuICAgIHVzZVN0YXRlPEFzc2lnbm1lbnRbXT4oW10pXHJcbiAgY29uc3QgW3JlZnJlc2hLZXksIHNldFJlZnJlc2hLZXldID0gdXNlU3RhdGUoMClcclxuICBjb25zdCBbc3VibWlzc2lvbnMsIHNldFN1Ym1pc3Npb25zXSA9XHJcbiAgICB1c2VTdGF0ZTxTdHVkZW50U3VibWlzc2lvbltdPihbXSlcclxuICBjb25zdCBbZGVsZXRpbmdBc3NpZ25tZW50SWQsIHNldERlbGV0aW5nQXNzaWdubWVudElkXSA9XHJcbiAgdXNlU3RhdGU8bnVtYmVyIHwgbnVsbD4obnVsbClcclxuICBjb25zdCBbbG9hZGluZywgc2V0TG9hZGluZ10gPSB1c2VTdGF0ZSh0cnVlKVxyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpXHJcbiAgY29uc3QgW2VkaXRpbmdBc3NpZ25tZW50SWQsIHNldEVkaXRpbmdBc3NpZ25tZW50SWRdID1cclxuICB1c2VTdGF0ZTxudW1iZXIgfCBudWxsPihudWxsKVxyXG4gIGNvbnN0IFtub3csIHNldE5vd10gPSB1c2VTdGF0ZSgoKSA9PiBEYXRlLm5vdygpKVxyXG4gIGNvbnN0IGlzU3R1ZGVudCA9IHJvbGUudG9Mb3dlckNhc2UoKSA9PT0gJ3N0dWRlbnQnXHJcbiAgY29uc3QgY2FuR3JhZGUgPVxyXG4gIHJvbGUudG9Mb3dlckNhc2UoKSA9PT0gJ3Byb2Zlc3NvcicgfHxcclxuICByb2xlLnRvTG93ZXJDYXNlKCkgPT09ICdhZG1pbidcclxuICBhc3luYyBmdW5jdGlvbiByZWZyZXNoU3VibWlzc2lvbnMoKSB7XHJcbiAgICBpZiAoIWlzU3R1ZGVudCkgcmV0dXJuXHJcblxyXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgICAgJy9hcGkvc3VibWlzc2lvbnMvbXktc3VibWlzc2lvbnMnLFxyXG4gICAgICB7XHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAsXHJcbiAgICAgICAgfSxcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgdGhyb3cgbmV3IEVycm9yKGF3YWl0IHJlYWRFcnJvcihyZXNwb25zZSkpXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZGF0YTogU3R1ZGVudFN1Ym1pc3Npb25bXSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKVxyXG4gICAgc2V0U3VibWlzc2lvbnMoZGF0YSlcclxuICB9XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpXHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gbG9hZEFzc2lnbm1lbnRzKCkge1xyXG4gICAgICBzZXRMb2FkaW5nKHRydWUpXHJcbiAgICAgIHNldEVycm9yKCcnKVxyXG4gICAgICBzZXRBc3NpZ25tZW50cyhbXSlcclxuICAgICAgc2V0U3VibWlzc2lvbnMoW10pXHJcblxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIGNvbnN0IGhlYWRlcnMgPSB7XHJcbiAgICAgICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dG9rZW59YCxcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IGFzc2lnbm1lbnRSZXF1ZXN0ID0gZmV0Y2goXHJcbiAgICAgICAgICBgL2FwaS9hc3NpZ25tZW50cy9jb3Vyc2VzLyR7Y291cnNlSWR9YCxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgaGVhZGVycyxcclxuICAgICAgICAgICAgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCxcclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcblxyXG4gICAgICAgIGNvbnN0IHN1Ym1pc3Npb25SZXF1ZXN0ID0gaXNTdHVkZW50XHJcbiAgICAgICAgICA/IGZldGNoKCcvYXBpL3N1Ym1pc3Npb25zL215LXN1Ym1pc3Npb25zJywge1xyXG4gICAgICAgICAgICAgIGhlYWRlcnMsXHJcbiAgICAgICAgICAgICAgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIDogUHJvbWlzZS5yZXNvbHZlKG51bGwpXHJcblxyXG4gICAgICAgIGNvbnN0IFthc3NpZ25tZW50UmVzcG9uc2UsIHN1Ym1pc3Npb25SZXNwb25zZV0gPVxyXG4gICAgICAgICAgYXdhaXQgUHJvbWlzZS5hbGwoW1xyXG4gICAgICAgICAgICBhc3NpZ25tZW50UmVxdWVzdCxcclxuICAgICAgICAgICAgc3VibWlzc2lvblJlcXVlc3QsXHJcbiAgICAgICAgICBdKVxyXG5cclxuICAgICAgICBpZiAoIWFzc2lnbm1lbnRSZXNwb25zZS5vaykge1xyXG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICAgICAgICBhd2FpdCByZWFkRXJyb3IoYXNzaWdubWVudFJlc3BvbnNlKVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgY29uc3QgYXNzaWdubWVudERhdGE6IEFzc2lnbm1lbnRbXSA9XHJcbiAgICAgICAgICBhd2FpdCBhc3NpZ25tZW50UmVzcG9uc2UuanNvbigpXHJcblxyXG4gICAgICAgIGxldCBzdWJtaXNzaW9uRGF0YTogU3R1ZGVudFN1Ym1pc3Npb25bXSA9IFtdXHJcblxyXG4gICAgICAgIGlmIChzdWJtaXNzaW9uUmVzcG9uc2UpIHtcclxuICAgICAgICAgIGlmICghc3VibWlzc2lvblJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgICAgICAgICBhd2FpdCByZWFkRXJyb3Ioc3VibWlzc2lvblJlc3BvbnNlKVxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgc3VibWlzc2lvbkRhdGEgPSBhd2FpdCBzdWJtaXNzaW9uUmVzcG9uc2UuanNvbigpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBpZiAoIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcclxuICAgICAgICAgIHNldEFzc2lnbm1lbnRzKFxyXG4gICAgICAgICAgICBbLi4uYXNzaWdubWVudERhdGFdLnNvcnQoXHJcbiAgICAgICAgICAgICAgKGEsIGIpID0+XHJcbiAgICAgICAgICAgICAgICBuZXcgRGF0ZShhLmR1ZV9hdCkuZ2V0VGltZSgpIC1cclxuICAgICAgICAgICAgICAgIG5ldyBEYXRlKGIuZHVlX2F0KS5nZXRUaW1lKClcclxuICAgICAgICAgICAgKVxyXG4gICAgICAgICAgKVxyXG5cclxuICAgICAgICAgIHNldFN1Ym1pc3Npb25zKHN1Ym1pc3Npb25EYXRhKVxyXG4gICAgICAgIH1cclxuICAgICAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICAgICAgaWYgKCFjb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSB7XHJcbiAgICAgICAgICBzZXRFcnJvcihcclxuICAgICAgICAgICAgZXJyIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICAgICAgICA/IGVyci5tZXNzYWdlXHJcbiAgICAgICAgICAgICAgOiAnVW5hYmxlIHRvIGxvYWQgYXNzaWdubWVudHMuJ1xyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBpZiAoIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcclxuICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgdm9pZCBsb2FkQXNzaWdubWVudHMoKVxyXG5cclxuICAgIHJldHVybiAoKSA9PiBjb250cm9sbGVyLmFib3J0KClcclxuICB9LCBbY291cnNlSWQsIHRva2VuLCBpc1N0dWRlbnQsIHJlZnJlc2hLZXldKVxyXG5cclxuXHJcbiAgXHJcbmFzeW5jIGZ1bmN0aW9uIGRlbGV0ZUFzc2lnbm1lbnQoYXNzaWdubWVudDogQXNzaWdubWVudCkge1xyXG4gIGNvbnN0IGNvbmZpcm1lZCA9IHdpbmRvdy5jb25maXJtKFxyXG4gICAgYEFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBkZWxldGUgXCIke2Fzc2lnbm1lbnQudGl0bGV9XCI/XFxuXFxuYCArXHJcbiAgICAnVGhpcyBhY3Rpb24gY2Fubm90IGJlIHVuZG9uZS4nXHJcbiAgKVxyXG5cclxuICBpZiAoIWNvbmZpcm1lZCkgcmV0dXJuXHJcblxyXG4gIHNldERlbGV0aW5nQXNzaWdubWVudElkKGFzc2lnbm1lbnQuaWQpXHJcbiAgc2V0RXJyb3IoJycpXHJcblxyXG4gIHRyeSB7XHJcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxyXG4gICAgICBgL2FwaS9hc3NpZ25tZW50cy8ke2Fzc2lnbm1lbnQuaWR9YCxcclxuICAgICAge1xyXG4gICAgICAgIG1ldGhvZDogJ0RFTEVURScsXHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAsXHJcbiAgICAgICAgfSxcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcclxuICAgICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKS5jYXRjaCgoKSA9PiBudWxsKVxyXG5cclxuICAgICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICAgIHR5cGVvZiBkYXRhPy5kZXRhaWwgPT09ICdzdHJpbmcnXHJcbiAgICAgICAgICA/IGRhdGEuZGV0YWlsXHJcbiAgICAgICAgICA6IGBEZWxldGlvbiBmYWlsZWQgKCR7cmVzcG9uc2Uuc3RhdHVzfSkuYFxyXG4gICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgc2V0RWRpdGluZ0Fzc2lnbm1lbnRJZChudWxsKVxyXG5cclxuICAgIC8vIFJlbG9hZCBhc3NpZ25tZW50cyBmcm9tIHRoZSBiYWNrZW5kLlxyXG4gICAgc2V0UmVmcmVzaEtleSgocHJldmlvdXMpID0+IHByZXZpb3VzICsgMSlcclxuXHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICBzZXRFcnJvcihcclxuICAgICAgZXJyIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICA/IGVyci5tZXNzYWdlXHJcbiAgICAgICAgOiAnVW5hYmxlIHRvIGRlbGV0ZSBhc3NpZ25tZW50LidcclxuICAgIClcclxuICB9IGZpbmFsbHkge1xyXG4gICAgc2V0RGVsZXRpbmdBc3NpZ25tZW50SWQobnVsbClcclxuICB9XHJcbn1cclxuXHJcbnVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgY29uc3QgdGltZXIgPSB3aW5kb3cuc2V0SW50ZXJ2YWwoKCkgPT4ge1xyXG4gICAgc2V0Tm93KERhdGUubm93KCkpXHJcbiAgfSwgMTUwMDApXHJcblxyXG4gIHJldHVybiAoKSA9PiB3aW5kb3cuY2xlYXJJbnRlcnZhbCh0aW1lcilcclxufSwgW10pXHJcbiAgcmV0dXJuIChcclxuICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInBhbmVsXCI+XHJcbiAgICAgIDxoMj5Db3Vyc2UgQXNzaWdubWVudHM8L2gyPlxyXG5cclxuICAgICAgPHA+XHJcbiAgICAgICAgVmlldyBpbnN0cnVjdGlvbnMsIHN1Ym1pdCB5b3VyIHdvcmssXHJcbiAgICAgICAgYW5kIGNoZWNrIHlvdXIgZ3JhZGVzLlxyXG4gICAgICA8L3A+XHJcbnsocm9sZS50b0xvd2VyQ2FzZSgpID09PSAncHJvZmVzc29yJyB8fFxyXG4gIHJvbGUudG9Mb3dlckNhc2UoKSA9PT0gJ2FkbWluJykgJiYgKFxyXG4gIDxDcmVhdGVBc3NpZ25tZW50Rm9ybVxyXG4gICAga2V5PXtjb3Vyc2VJZH1cclxuICAgIGNvdXJzZUlkPXtjb3Vyc2VJZH1cclxuICAgIHRva2VuPXt0b2tlbn1cclxuICAgIG9uQ3JlYXRlZD17KCkgPT4gc2V0UmVmcmVzaEtleSgobikgPT4gbiArIDEpfVxyXG4gIC8+XHJcbil9XHJcbiAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cclxuICAgICAgICAgIHtlcnJvcn1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICA8cD5Mb2FkaW5nIGFzc2lnbm1lbnRzLi4uPC9wPlxyXG4gICAgICApIDogYXNzaWdubWVudHMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICFlcnJvciAmJiA8cD5ObyBhc3NpZ25tZW50cyBhdmFpbGFibGUuPC9wPlxyXG4gICAgICApIDogKFxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXNzaWdubWVudHMtbGlzdFwiPlxyXG4gICAgICAgICAge2Fzc2lnbm1lbnRzLm1hcCgoYXNzaWdubWVudCkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCBzdWJtaXNzaW9uID0gc3VibWlzc2lvbnMuZmluZChcclxuICAgICAgICAgICAgICAoaXRlbSkgPT5cclxuICAgICAgICAgICAgICAgIGl0ZW0uYXNzaWdubWVudF9pZCA9PT0gYXNzaWdubWVudC5pZFxyXG4gICAgICAgICAgICApID8/IG51bGxcclxuXHJcbiAgICAgICAgICAgIGNvbnN0IHBhc3REZWFkbGluZSA9XHJcbiAgbmV3IERhdGUoYXNzaWdubWVudC5kdWVfYXQpLmdldFRpbWUoKSA8PSBub3dcclxuY29uc3Qgc3R1ZGVudFN0YXR1cyA9IGdldEFzc2lnbm1lbnRQcm9ncmVzcyhcclxuICBhc3NpZ25tZW50LmR1ZV9hdCxcclxuICBzdWJtaXNzaW9uLFxyXG4gIG5vdyxcclxuKVxyXG4gICAgICAgICAgICByZXR1cm4gKFxyXG4gICAgICAgICAgICAgIDxhcnRpY2xlXHJcbiAgICAgICAgICAgICAgICBrZXk9e2Fzc2lnbm1lbnQuaWR9XHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhc3NpZ25tZW50LWNhcmRcIlxyXG4gICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXNzaWdubWVudC1oZWFkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgPGgzPnthc3NpZ25tZW50LnRpdGxlfTwvaDM+XHJcblxyXG4gICAgICAgICAgICAgICAgICA8c3BhblxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17XHJcbiAgICAgICAgICAgICAgICAgICAgICBwYXN0RGVhZGxpbmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPyAnYXNzaWdubWVudC1zdGF0dXMgb3ZlcmR1ZSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgOiAnYXNzaWdubWVudC1zdGF0dXMgb3BlbidcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgID5cclxuICAgICAgICAgICAgICAgICAgICB7cGFzdERlYWRsaW5lXHJcbiAgICAgICAgICAgICAgICAgICAgICA/ICdQYXN0IGRlYWRsaW5lJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgOiAnVXBjb21pbmcnfVxyXG4gICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgIHtpc1N0dWRlbnQgJiYgKFxyXG4gIDxBc3NpZ25tZW50UHJvZ3Jlc3NCYWRnZSBzdGF0dXM9e3N0dWRlbnRTdGF0dXN9IC8+XHJcbil9XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICB7YXNzaWdubWVudC5kZXNjcmlwdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwPnthc3NpZ25tZW50LmRlc2NyaXB0aW9ufTwvcD5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAge2Fzc2lnbm1lbnQuaW5zdHJ1Y3Rpb25zICYmIChcclxuICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJhc3NpZ25tZW50LWluc3RydWN0aW9uc1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+SW5zdHJ1Y3Rpb25zPC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgICAgPHA+e2Fzc2lnbm1lbnQuaW5zdHJ1Y3Rpb25zfTwvcD5cclxuICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYXNzaWdubWVudC1kZXRhaWxzXCI+XHJcbiAgICAgICAgICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICAgICAgICAgIDxzdHJvbmc+RGVhZGxpbmU6PC9zdHJvbmc+eycgJ31cclxuICAgICAgICAgICAgICAgICAgICB7bmV3IERhdGUoXHJcbiAgICAgICAgICAgICAgICAgICAgICBhc3NpZ25tZW50LmR1ZV9hdFxyXG4gICAgICAgICAgICAgICAgICAgICkudG9Mb2NhbGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgICAgPC9wPlxyXG5cclxuICAgICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgPHN0cm9uZz5NYXhpbXVtIFNjb3JlOjwvc3Ryb25nPnsnICd9XHJcbiAgICAgICAgICAgICAgICAgICAge2Fzc2lnbm1lbnQubWF4X3Njb3JlfVxyXG4gICAgICAgICAgICAgICAgICA8L3A+XHJcblxyXG5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgXHJcbnsvKiBQcm9mZXNzb3IgYXNzaWdubWVudCBlZGl0aW5nICovfVxyXG5cclxuey8qIFByb2Zlc3NvciBhc3NpZ25tZW50IG1hbmFnZW1lbnQgKi99XHJcbntjYW5HcmFkZSAmJiAoXHJcbiAgPGRpdiBjbGFzc05hbWU9XCJhc3NpZ25tZW50LW1hbmFnZVwiPlxyXG5cclxuICAgIHtlZGl0aW5nQXNzaWdubWVudElkICE9PSBhc3NpZ25tZW50LmlkICYmIChcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJhc3NpZ25tZW50LW1hbmFnZS1hY3Rpb25zXCI+XHJcblxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLXNlY29uZGFyeVwiXHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICBzZXRFZGl0aW5nQXNzaWdubWVudElkKGFzc2lnbm1lbnQuaWQpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgPlxyXG4gICAgICAgICAgRWRpdCBBc3NpZ25tZW50XHJcbiAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgIDxidXR0b25cclxuICAgICAgICAgIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYnRuLWRhbmdlclwiXHJcbiAgICAgICAgICBkaXNhYmxlZD17ZGVsZXRpbmdBc3NpZ25tZW50SWQgIT09IG51bGx9XHJcbiAgICAgICAgICBvbkNsaWNrPXsoKSA9PlxyXG4gICAgICAgICAgICB2b2lkIGRlbGV0ZUFzc2lnbm1lbnQoYXNzaWdubWVudClcclxuICAgICAgICAgIH1cclxuICAgICAgICA+XHJcbiAgICAgICAgICB7ZGVsZXRpbmdBc3NpZ25tZW50SWQgPT09IGFzc2lnbm1lbnQuaWRcclxuICAgICAgICAgICAgPyAnRGVsZXRpbmcuLi4nXHJcbiAgICAgICAgICAgIDogJ0RlbGV0ZSBBc3NpZ25tZW50J31cclxuICAgICAgICA8L2J1dHRvbj5cclxuXHJcbiAgICAgIDwvZGl2PlxyXG4gICAgKX1cclxuXHJcbiAgICB7ZWRpdGluZ0Fzc2lnbm1lbnRJZCA9PT0gYXNzaWdubWVudC5pZCAmJiAoXHJcbiAgICAgIDxFZGl0QXNzaWdubWVudEZvcm1cclxuICAgICAgICBhc3NpZ25tZW50PXthc3NpZ25tZW50fVxyXG4gICAgICAgIHRva2VuPXt0b2tlbn1cclxuICAgICAgICBvblNhdmVkPXsoKSA9PiB7XHJcbiAgICAgICAgICBzZXRFZGl0aW5nQXNzaWdubWVudElkKG51bGwpXHJcbiAgICAgICAgICBzZXRSZWZyZXNoS2V5KChuKSA9PiBuICsgMSlcclxuICAgICAgICB9fVxyXG4gICAgICAgIG9uQ2FuY2VsPXsoKSA9PlxyXG4gICAgICAgICAgc2V0RWRpdGluZ0Fzc2lnbm1lbnRJZChudWxsKVxyXG4gICAgICAgIH1cclxuICAgICAgLz5cclxuICAgICl9XHJcblxyXG4gIDwvZGl2PlxyXG4pfVxyXG5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgXHJcblxyXG4gICAgICAgICAgXHJcblxyXG57LyogU3R1ZGVudCBzdWJtaXNzaW9uLCBmaW5hbCByZXN1bHQgYW5kIGF0dGVtcHQgaGlzdG9yeSAqL31cclxue2lzU3R1ZGVudCAmJiAoXHJcbiAgPD5cclxuICAgIHshcGFzdERlYWRsaW5lID8gKFxyXG4gICAgICA8PlxyXG4gICAgICAgIDxBc3NpZ25tZW50U3VibWlzc2lvbkZvcm1cclxuICAgICAgICAgIGtleT17YXNzaWdubWVudC5pZH1cclxuICAgICAgICAgIGFzc2lnbm1lbnRJZD17YXNzaWdubWVudC5pZH1cclxuICAgICAgICAgIHRva2VuPXt0b2tlbn1cclxuICAgICAgICAgIGV4aXN0aW5nPXtzdWJtaXNzaW9ufVxyXG4gICAgICAgICAgb25TdWJtaXR0ZWQ9e3JlZnJlc2hTdWJtaXNzaW9uc31cclxuICAgICAgICAvPlxyXG5cclxuICAgICAgICB7YXNzaWdubWVudC5hbGxvd19tdWx0aXBsZV9zdWJtaXNzaW9ucyAmJiBzdWJtaXNzaW9uICYmIChcclxuICAgICAgICAgIDxBZGROZXdTdWJtaXNzaW9uRm9ybVxyXG4gICAgICAgICAgICBhc3NpZ25tZW50SWQ9e2Fzc2lnbm1lbnQuaWR9XHJcbiAgICAgICAgICAgIHRva2VuPXt0b2tlbn1cclxuICAgICAgICAgICAgb25TdWJtaXR0ZWQ9e3JlZnJlc2hTdWJtaXNzaW9uc31cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgKX1cclxuICAgICAgPC8+XHJcbiAgICApIDogc3VibWlzc2lvbiA/IChcclxuICAgICAgPEZpbmFsU3VibWlzc2lvblN1bW1hcnlcclxuICAgICAgICBzdWJtaXNzaW9uSWQ9e3N1Ym1pc3Npb24uaWR9XHJcbiAgICAgICAgdG9rZW49e3Rva2VufVxyXG4gICAgICAgIG1heFNjb3JlPXthc3NpZ25tZW50Lm1heF9zY29yZX1cclxuICAgICAgLz5cclxuICAgICkgOiAoXHJcbiAgICAgIDxwIHJvbGU9XCJzdGF0dXNcIj5cclxuICAgICAgICBObyBzdWJtaXNzaW9uIHdhcyByZWNlaXZlZCBiZWZvcmUgdGhlIGRlYWRsaW5lLlxyXG4gICAgICA8L3A+XHJcbiAgICApfVxyXG5cclxuICAgIDxBc3NpZ25tZW50QXR0ZW1wdFJldmlld1BhbmVsXHJcbiAgICAgIGFzc2lnbm1lbnRJZD17YXNzaWdubWVudC5pZH1cclxuICAgICAgdG9rZW49e3Rva2VufVxyXG4gICAgICBtb2RlPVwic3R1ZGVudFwiXHJcbiAgICAvPlxyXG4gIDwvPlxyXG4pfVxyXG5cclxuey8qIFByb2Zlc3NvciBmaW5hbCBncmFkaW5nIGFuZCBhdHRlbXB0IGZlZWRiYWNrICovfVxyXG57Y2FuR3JhZGUgJiYgKFxyXG4gIDw+XHJcbiAgICB7cGFzdERlYWRsaW5lID8gKFxyXG4gICAgICA8QXNzaWdubWVudEdyYWRpbmdcclxuICAgICAgICBhc3NpZ25tZW50SWQ9e2Fzc2lnbm1lbnQuaWR9XHJcbiAgICAgICAgbWF4U2NvcmU9e2Fzc2lnbm1lbnQubWF4X3Njb3JlfVxyXG4gICAgICAgIHRva2VuPXt0b2tlbn1cclxuICAgICAgLz5cclxuICAgICkgOiAoXHJcbiAgICAgIDxwIHJvbGU9XCJzdGF0dXNcIj5cclxuICAgICAgICBGaW5hbCBncmFkaW5nIG9wZW5zIGFmdGVyIHRoZSBhc3NpZ25tZW50IGRlYWRsaW5lLlxyXG4gICAgICAgIFlvdSBjYW4gcmV2aWV3IGFuZCBjb21tZW50IG9uIGF0dGVtcHRzIG5vdy5cclxuICAgICAgPC9wPlxyXG4gICAgKX1cclxuXHJcbiAgICA8QXNzaWdubWVudEF0dGVtcHRSZXZpZXdQYW5lbFxyXG4gICAgICBhc3NpZ25tZW50SWQ9e2Fzc2lnbm1lbnQuaWR9XHJcbiAgICAgIHRva2VuPXt0b2tlbn1cclxuICAgICAgbW9kZT17XHJcbiAgICAgICAgcm9sZS50b0xvd2VyQ2FzZSgpID09PSAnYWRtaW4nXHJcbiAgICAgICAgICA/ICdhZG1pbidcclxuICAgICAgICAgIDogJ3Byb2Zlc3NvcidcclxuICAgICAgfVxyXG4gICAgLz5cclxuICA8Lz5cclxuKX1cclxuXHJcbiAgICAgICAgICAgICAgPC9hcnRpY2xlPlxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgICB9KX1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgKX1cclxuICAgIDwvc2VjdGlvbj5cclxuICApXHJcbn1cclxuIl19