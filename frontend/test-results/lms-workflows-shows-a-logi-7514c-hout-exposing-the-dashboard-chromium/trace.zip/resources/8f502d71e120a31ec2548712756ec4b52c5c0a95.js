import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/CourseMaterials.tsx");const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fcfa67a2";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CourseMaterials.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
var _s = $RefreshSig$();
function formatFileSize(bytes) {
	if (bytes < 1024) {
		return `${bytes} B`;
	}
	if (bytes < 1024 * 1024) {
		return `${(bytes / 1024).toFixed(1)} KB`;
	}
	return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
export default function CourseMaterials({ courseId, token }) {
	_s();
	const [materials, setMaterials] = useState([]);
	const [loading, setLoading] = useState(true);
	const [downloadingId, setDownloadingId] = useState(null);
	const [error, setError] = useState("");
	useEffect(() => {
		const controller = new AbortController();
		async function loadMaterials() {
			setLoading(true);
			setError("");
			setMaterials([]);
			try {
				const response = await fetch(`/api/materials/courses/${courseId}`, {
					headers: { Authorization: `Bearer ${token}` },
					signal: controller.signal
				});
				if (!response.ok) {
					if (response.status === 403) {
						throw new Error("You must be enrolled in this course to access its materials.");
					}
					throw new Error(`Unable to load course materials (${response.status}).`);
				}
				const data = await response.json();
				if (!controller.signal.aborted) {
					setMaterials(data);
				}
			} catch (err) {
				if (!controller.signal.aborted) {
					setError(err instanceof Error ? err.message : "Unable to load course materials.");
				}
			} finally {
				if (!controller.signal.aborted) {
					setLoading(false);
				}
			}
		}
		void loadMaterials();
		return () => controller.abort();
	}, [courseId, token]);
	async function downloadMaterial(material) {
		setDownloadingId(material.id);
		setError("");
		try {
			const response = await fetch(`/api/materials/${material.id}/download`, { headers: { Authorization: `Bearer ${token}` } });
			if (!response.ok) {
				throw new Error(`Download failed (${response.status}).`);
			}
			const blob = await response.blob();
			const downloadUrl = URL.createObjectURL(blob);
			const link = document.createElement("a");
			link.href = downloadUrl;
			link.download = material.original_filename || "course-material";
			document.body.appendChild(link);
			link.click();
			link.remove();
			setTimeout(() => {
				URL.revokeObjectURL(downloadUrl);
			}, 1e3);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Unable to download the material.");
		} finally {
			setDownloadingId(null);
		}
	}
	return /* @__PURE__ */ _jsxDEV("section", {
		className: "panel",
		children: [
			/* @__PURE__ */ _jsxDEV("div", {
				className: "materials-header",
				children: /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("h2", { children: "Course Materials" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 148,
					columnNumber: 11
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: "Lecture slides, documents, and learning resources." }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 149,
					columnNumber: 11
				}, this)] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 147,
					columnNumber: 9
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 146,
				columnNumber: 7
			}, this),
			error && /* @__PURE__ */ _jsxDEV("p", {
				className: "error",
				role: "alert",
				children: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 156,
				columnNumber: 9
			}, this),
			loading ? /* @__PURE__ */ _jsxDEV("p", { children: "Loading course materials..." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 162,
				columnNumber: 9
			}, this) : materials.length === 0 ? !error && /* @__PURE__ */ _jsxDEV("p", { children: "No materials have been uploaded yet." }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 164,
				columnNumber: 19
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "materials-list",
				children: materials.map((material) => /* @__PURE__ */ _jsxDEV("article", {
					className: "material-item",
					children: [/* @__PURE__ */ _jsxDEV("div", {
						className: "material-info",
						children: [
							/* @__PURE__ */ _jsxDEV("h3", { children: material.title }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 173,
								columnNumber: 17
							}, this),
							material.description && /* @__PURE__ */ _jsxDEV("p", { children: material.description }, void 0, false, {
								fileName: _jsxFileName,
								lineNumber: 176,
								columnNumber: 19
							}, this),
							/* @__PURE__ */ _jsxDEV("p", {
								className: "material-meta",
								children: [
									material.original_filename,
									" · ",
									formatFileSize(material.file_size),
									" · ",
									new Date(material.created_at).toLocaleDateString()
								]
							}, void 0, true, {
								fileName: _jsxFileName,
								lineNumber: 179,
								columnNumber: 17
							}, this)
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 172,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						type: "button",
						disabled: downloadingId !== null,
						onClick: () => void downloadMaterial(material),
						children: downloadingId === material.id ? "Downloading..." : "Download"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 190,
						columnNumber: 15
					}, this)]
				}, material.id, true, {
					fileName: _jsxFileName,
					lineNumber: 168,
					columnNumber: 13
				}, this))
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 166,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 145,
		columnNumber: 5
	}, this);
}
_s(CourseMaterials, "sIqAsuzJyE6BpJqwgFYWoIsqc88=");
_c = CourseMaterials;
var _c;
$RefreshReg$(_c, "CourseMaterials");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/CourseMaterials.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CourseMaterials.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CourseMaterials.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/CourseMaterials.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQ0EsU0FBUyxXQUFXLGdCQUFnQjs7OztBQWlCcEMsU0FBUyxlQUFlLE9BQXVCO0NBQzdDLElBQUksUUFBUSxNQUFNO0VBQ2hCLE9BQU8sR0FBRyxNQUFNO0NBQ2xCO0NBRUEsSUFBSSxRQUFRLE9BQU8sTUFBTTtFQUN2QixPQUFPLElBQUksUUFBUSxLQUFJLENBQUUsUUFBUSxDQUFDLEVBQUU7Q0FDdEM7Q0FFQSxPQUFPLElBQUksU0FBUyxPQUFPLE1BQUssQ0FBRSxRQUFRLENBQUMsRUFBRTtBQUMvQztBQUVBLGVBQWUsU0FBUyxnQkFBZ0IsRUFDdEMsVUFDQSxTQUNROztDQUNSLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFxQixDQUFDLENBQUM7Q0FDekQsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLGVBQWUsb0JBQ3BCLFNBQXdCLElBQUk7Q0FFOUIsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FFckMsZ0JBQWdCO0VBQ2QsTUFBTSxhQUFhLElBQUksZ0JBQWdCO0VBRXZDLGVBQWUsZ0JBQWdCO0dBQzdCLFdBQVcsSUFBSTtHQUNmLFNBQVMsRUFBRTtHQUNYLGFBQWEsQ0FBQyxDQUFDO0dBRWYsSUFBSTtJQUNGLE1BQU0sV0FBVyxNQUFNLE1BQ3JCLDBCQUEwQixZQUMxQjtLQUNFLFNBQVMsRUFDUCxlQUFlLFVBQVUsUUFDM0I7S0FDQSxRQUFRLFdBQVc7SUFDckIsQ0FDRjtJQUVBLElBQUksQ0FBQyxTQUFTLElBQUk7S0FDaEIsSUFBSSxTQUFTLFdBQVcsS0FBSztNQUMzQixNQUFNLElBQUksTUFDUiw4REFDRjtLQUNGO0tBRUEsTUFBTSxJQUFJLE1BQ1Isb0NBQW9DLFNBQVMsT0FBTyxHQUN0RDtJQUNGO0lBRUEsTUFBTSxPQUFtQixNQUFNLFNBQVMsS0FBSztJQUU3QyxJQUFJLENBQUMsV0FBVyxPQUFPLFNBQVM7S0FDOUIsYUFBYSxJQUFJO0lBQ25CO0dBQ0YsU0FBUyxLQUFLO0lBQ1osSUFBSSxDQUFDLFdBQVcsT0FBTyxTQUFTO0tBQzlCLFNBQ0UsZUFBZSxRQUNYLElBQUksVUFDSixrQ0FDTjtJQUNGO0dBQ0YsVUFBVTtJQUNSLElBQUksQ0FBQyxXQUFXLE9BQU8sU0FBUztLQUM5QixXQUFXLEtBQUs7SUFDbEI7R0FDRjtFQUNGO0VBRUEsS0FBSyxjQUFjO0VBRW5CLGFBQWEsV0FBVyxNQUFNO0NBQ2hDLEdBQUcsQ0FBQyxVQUFVLEtBQUssQ0FBQztDQUVwQixlQUFlLGlCQUFpQixVQUFvQjtFQUNsRCxpQkFBaUIsU0FBUyxFQUFFO0VBQzVCLFNBQVMsRUFBRTtFQUVYLElBQUk7R0FDRixNQUFNLFdBQVcsTUFBTSxNQUNyQixrQkFBa0IsU0FBUyxHQUFHLFlBQzlCLEVBQ0UsU0FBUyxFQUNQLGVBQWUsVUFBVSxRQUMzQixFQUNGLENBQ0Y7R0FFQSxJQUFJLENBQUMsU0FBUyxJQUFJO0lBQ2hCLE1BQU0sSUFBSSxNQUNSLG9CQUFvQixTQUFTLE9BQU8sR0FDdEM7R0FDRjtHQUVBLE1BQU0sT0FBTyxNQUFNLFNBQVMsS0FBSztHQUNqQyxNQUFNLGNBQWMsSUFBSSxnQkFBZ0IsSUFBSTtHQUU1QyxNQUFNLE9BQU8sU0FBUyxjQUFjLEdBQUc7R0FDdkMsS0FBSyxPQUFPO0dBQ1osS0FBSyxXQUNILFNBQVMscUJBQXFCO0dBRWhDLFNBQVMsS0FBSyxZQUFZLElBQUk7R0FDOUIsS0FBSyxNQUFNO0dBQ1gsS0FBSyxPQUFPO0dBRVosaUJBQWlCO0lBQ2YsSUFBSSxnQkFBZ0IsV0FBVztHQUNqQyxHQUFHLEdBQUk7RUFDVCxTQUFTLEtBQUs7R0FDWixTQUNFLGVBQWUsUUFDWCxJQUFJLFVBQ0osa0NBQ047RUFDRixVQUFVO0dBQ1IsaUJBQWlCLElBQUk7RUFDdkI7Q0FDRjtDQUVBLE9BQ0Usd0JBQUMsV0FBRDtFQUFTLFdBQVU7WUFBbkI7R0FDRSx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNiLHdCQUFDLE9BQUQsYUFDRSx3QkFBQyxNQUFELFlBQUksbUJBQW9COzs7O2NBQ3hCLHdCQUFDLEtBQUQsWUFBRyxxREFFQTs7OztZQUNBOzs7OztHQUNGOzs7OztHQUVKLFNBQ0Msd0JBQUMsS0FBRDtJQUFHLFdBQVU7SUFBUSxNQUFLO2NBQ3ZCO0dBQ0E7Ozs7O0dBR0osVUFDQyx3QkFBQyxLQUFELFlBQUcsOEJBQThCOzs7O2NBQy9CLFVBQVUsV0FBVyxJQUN2QixDQUFDLFNBQVMsd0JBQUMsS0FBRCxZQUFHLHVDQUF1Qzs7OztjQUVwRCx3QkFBQyxPQUFEO0lBQUssV0FBVTtjQUNaLFVBQVUsS0FBSyxhQUNkLHdCQUFDLFdBQUQ7S0FFRSxXQUFVO2VBRlosQ0FJRSx3QkFBQyxPQUFEO01BQUssV0FBVTtnQkFBZjtPQUNFLHdCQUFDLE1BQUQsWUFBSyxTQUFTLE1BQVU7Ozs7O09BRXZCLFNBQVMsZUFDUix3QkFBQyxLQUFELFlBQUksU0FBUyxZQUFlOzs7OztPQUc5Qix3QkFBQyxLQUFEO1FBQUcsV0FBVTtrQkFBYjtTQUNHLFNBQVM7U0FDVDtTQUNBLGVBQWUsU0FBUyxTQUFTO1NBQ2pDO1NBQ0EsSUFBSSxLQUNILFNBQVMsVUFDWCxDQUFDLENBQUMsbUJBQW1CO1FBQ3BCOzs7Ozs7TUFDQTs7Ozs7ZUFFTCx3QkFBQyxVQUFEO01BQ0UsTUFBSztNQUNMLFVBQVUsa0JBQWtCO01BQzVCLGVBQ0UsS0FBSyxpQkFBaUIsUUFBUTtnQkFHL0Isa0JBQWtCLFNBQVMsS0FDeEIsbUJBQ0E7S0FDRTs7OzthQUNEO09BaENGLFNBQVM7Ozs7V0FnQ1AsQ0FDVjtHQUNFOzs7OztFQUVBOzs7Ozs7QUFFYiIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJDb3Vyc2VNYXRlcmlhbHMudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbIlxyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcblxyXG50eXBlIE1hdGVyaWFsID0ge1xyXG4gIGlkOiBudW1iZXJcclxuICB0aXRsZTogc3RyaW5nXHJcbiAgZGVzY3JpcHRpb246IHN0cmluZyB8IG51bGxcclxuICBvcmlnaW5hbF9maWxlbmFtZTogc3RyaW5nXHJcbiAgZmlsZV9zaXplOiBudW1iZXJcclxuICBjcmVhdGVkX2F0OiBzdHJpbmdcclxuICBjb3Vyc2VfaWQ6IG51bWJlclxyXG59XHJcblxyXG50eXBlIFByb3BzID0ge1xyXG4gIGNvdXJzZUlkOiBudW1iZXJcclxuICB0b2tlbjogc3RyaW5nXHJcbn1cclxuXHJcbmZ1bmN0aW9uIGZvcm1hdEZpbGVTaXplKGJ5dGVzOiBudW1iZXIpOiBzdHJpbmcge1xyXG4gIGlmIChieXRlcyA8IDEwMjQpIHtcclxuICAgIHJldHVybiBgJHtieXRlc30gQmBcclxuICB9XHJcblxyXG4gIGlmIChieXRlcyA8IDEwMjQgKiAxMDI0KSB7XHJcbiAgICByZXR1cm4gYCR7KGJ5dGVzIC8gMTAyNCkudG9GaXhlZCgxKX0gS0JgXHJcbiAgfVxyXG5cclxuICByZXR1cm4gYCR7KGJ5dGVzIC8gKDEwMjQgKiAxMDI0KSkudG9GaXhlZCgxKX0gTUJgXHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIENvdXJzZU1hdGVyaWFscyh7XHJcbiAgY291cnNlSWQsXHJcbiAgdG9rZW4sXHJcbn06IFByb3BzKSB7XHJcbiAgY29uc3QgW21hdGVyaWFscywgc2V0TWF0ZXJpYWxzXSA9IHVzZVN0YXRlPE1hdGVyaWFsW10+KFtdKVxyXG4gIGNvbnN0IFtsb2FkaW5nLCBzZXRMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXHJcbiAgY29uc3QgW2Rvd25sb2FkaW5nSWQsIHNldERvd25sb2FkaW5nSWRdID1cclxuICAgIHVzZVN0YXRlPG51bWJlciB8IG51bGw+KG51bGwpXHJcblxyXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUoJycpXHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpXHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gbG9hZE1hdGVyaWFscygpIHtcclxuICAgICAgc2V0TG9hZGluZyh0cnVlKVxyXG4gICAgICBzZXRFcnJvcignJylcclxuICAgICAgc2V0TWF0ZXJpYWxzKFtdKVxyXG5cclxuICAgICAgdHJ5IHtcclxuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICAgYC9hcGkvbWF0ZXJpYWxzL2NvdXJzZXMvJHtjb3Vyc2VJZH1gLFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHNpZ25hbDogY29udHJvbGxlci5zaWduYWwsXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XHJcbiAgICAgICAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MDMpIHtcclxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxyXG4gICAgICAgICAgICAgICdZb3UgbXVzdCBiZSBlbnJvbGxlZCBpbiB0aGlzIGNvdXJzZSB0byBhY2Nlc3MgaXRzIG1hdGVyaWFscy4nXHJcbiAgICAgICAgICAgIClcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXHJcbiAgICAgICAgICAgIGBVbmFibGUgdG8gbG9hZCBjb3Vyc2UgbWF0ZXJpYWxzICgke3Jlc3BvbnNlLnN0YXR1c30pLmBcclxuICAgICAgICAgIClcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IGRhdGE6IE1hdGVyaWFsW10gPSBhd2FpdCByZXNwb25zZS5qc29uKClcclxuXHJcbiAgICAgICAgaWYgKCFjb250cm9sbGVyLnNpZ25hbC5hYm9ydGVkKSB7XHJcbiAgICAgICAgICBzZXRNYXRlcmlhbHMoZGF0YSlcclxuICAgICAgICB9XHJcbiAgICAgIH0gY2F0Y2ggKGVycikge1xyXG4gICAgICAgIGlmICghY29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkge1xyXG4gICAgICAgICAgc2V0RXJyb3IoXHJcbiAgICAgICAgICAgIGVyciBpbnN0YW5jZW9mIEVycm9yXHJcbiAgICAgICAgICAgICAgPyBlcnIubWVzc2FnZVxyXG4gICAgICAgICAgICAgIDogJ1VuYWJsZSB0byBsb2FkIGNvdXJzZSBtYXRlcmlhbHMuJ1xyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICBpZiAoIWNvbnRyb2xsZXIuc2lnbmFsLmFib3J0ZWQpIHtcclxuICAgICAgICAgIHNldExvYWRpbmcoZmFsc2UpXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgdm9pZCBsb2FkTWF0ZXJpYWxzKClcclxuXHJcbiAgICByZXR1cm4gKCkgPT4gY29udHJvbGxlci5hYm9ydCgpXHJcbiAgfSwgW2NvdXJzZUlkLCB0b2tlbl0pXHJcblxyXG4gIGFzeW5jIGZ1bmN0aW9uIGRvd25sb2FkTWF0ZXJpYWwobWF0ZXJpYWw6IE1hdGVyaWFsKSB7XHJcbiAgICBzZXREb3dubG9hZGluZ0lkKG1hdGVyaWFsLmlkKVxyXG4gICAgc2V0RXJyb3IoJycpXHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICBgL2FwaS9tYXRlcmlhbHMvJHttYXRlcmlhbC5pZH0vZG93bmxvYWRgLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgQXV0aG9yaXphdGlvbjogYEJlYXJlciAke3Rva2VufWAsXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG5cclxuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcclxuICAgICAgICAgIGBEb3dubG9hZCBmYWlsZWQgKCR7cmVzcG9uc2Uuc3RhdHVzfSkuYFxyXG4gICAgICAgIClcclxuICAgICAgfVxyXG5cclxuICAgICAgY29uc3QgYmxvYiA9IGF3YWl0IHJlc3BvbnNlLmJsb2IoKVxyXG4gICAgICBjb25zdCBkb3dubG9hZFVybCA9IFVSTC5jcmVhdGVPYmplY3RVUkwoYmxvYilcclxuXHJcbiAgICAgIGNvbnN0IGxpbmsgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJylcclxuICAgICAgbGluay5ocmVmID0gZG93bmxvYWRVcmxcclxuICAgICAgbGluay5kb3dubG9hZCA9XHJcbiAgICAgICAgbWF0ZXJpYWwub3JpZ2luYWxfZmlsZW5hbWUgfHwgJ2NvdXJzZS1tYXRlcmlhbCdcclxuXHJcbiAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobGluaylcclxuICAgICAgbGluay5jbGljaygpXHJcbiAgICAgIGxpbmsucmVtb3ZlKClcclxuXHJcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xyXG4gICAgICAgIFVSTC5yZXZva2VPYmplY3RVUkwoZG93bmxvYWRVcmwpXHJcbiAgICAgIH0sIDEwMDApXHJcbiAgICB9IGNhdGNoIChlcnIpIHtcclxuICAgICAgc2V0RXJyb3IoXHJcbiAgICAgICAgZXJyIGluc3RhbmNlb2YgRXJyb3JcclxuICAgICAgICAgID8gZXJyLm1lc3NhZ2VcclxuICAgICAgICAgIDogJ1VuYWJsZSB0byBkb3dubG9hZCB0aGUgbWF0ZXJpYWwuJ1xyXG4gICAgICApXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBzZXREb3dubG9hZGluZ0lkKG51bGwpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwicGFuZWxcIj5cclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXRlcmlhbHMtaGVhZGVyXCI+XHJcbiAgICAgICAgPGRpdj5cclxuICAgICAgICAgIDxoMj5Db3Vyc2UgTWF0ZXJpYWxzPC9oMj5cclxuICAgICAgICAgIDxwPlxyXG4gICAgICAgICAgICBMZWN0dXJlIHNsaWRlcywgZG9jdW1lbnRzLCBhbmQgbGVhcm5pbmcgcmVzb3VyY2VzLlxyXG4gICAgICAgICAgPC9wPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuXHJcbiAgICAgIHtlcnJvciAmJiAoXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwiZXJyb3JcIiByb2xlPVwiYWxlcnRcIj5cclxuICAgICAgICAgIHtlcnJvcn1cclxuICAgICAgICA8L3A+XHJcbiAgICAgICl9XHJcblxyXG4gICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICA8cD5Mb2FkaW5nIGNvdXJzZSBtYXRlcmlhbHMuLi48L3A+XHJcbiAgICAgICkgOiBtYXRlcmlhbHMubGVuZ3RoID09PSAwID8gKFxyXG4gICAgICAgICFlcnJvciAmJiA8cD5ObyBtYXRlcmlhbHMgaGF2ZSBiZWVuIHVwbG9hZGVkIHlldC48L3A+XHJcbiAgICAgICkgOiAoXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXRlcmlhbHMtbGlzdFwiPlxyXG4gICAgICAgICAge21hdGVyaWFscy5tYXAoKG1hdGVyaWFsKSA9PiAoXHJcbiAgICAgICAgICAgIDxhcnRpY2xlXHJcbiAgICAgICAgICAgICAga2V5PXttYXRlcmlhbC5pZH1cclxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJtYXRlcmlhbC1pdGVtXCJcclxuICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWF0ZXJpYWwtaW5mb1wiPlxyXG4gICAgICAgICAgICAgICAgPGgzPnttYXRlcmlhbC50aXRsZX08L2gzPlxyXG5cclxuICAgICAgICAgICAgICAgIHttYXRlcmlhbC5kZXNjcmlwdGlvbiAmJiAoXHJcbiAgICAgICAgICAgICAgICAgIDxwPnttYXRlcmlhbC5kZXNjcmlwdGlvbn08L3A+XHJcbiAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm1hdGVyaWFsLW1ldGFcIj5cclxuICAgICAgICAgICAgICAgICAge21hdGVyaWFsLm9yaWdpbmFsX2ZpbGVuYW1lfVxyXG4gICAgICAgICAgICAgICAgICB7JyDCtyAnfVxyXG4gICAgICAgICAgICAgICAgICB7Zm9ybWF0RmlsZVNpemUobWF0ZXJpYWwuZmlsZV9zaXplKX1cclxuICAgICAgICAgICAgICAgICAgeycgwrcgJ31cclxuICAgICAgICAgICAgICAgICAge25ldyBEYXRlKFxyXG4gICAgICAgICAgICAgICAgICAgIG1hdGVyaWFsLmNyZWF0ZWRfYXRcclxuICAgICAgICAgICAgICAgICAgKS50b0xvY2FsZURhdGVTdHJpbmcoKX1cclxuICAgICAgICAgICAgICAgIDwvcD5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgPGJ1dHRvblxyXG4gICAgICAgICAgICAgICAgdHlwZT1cImJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBkaXNhYmxlZD17ZG93bmxvYWRpbmdJZCAhPT0gbnVsbH1cclxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgIHZvaWQgZG93bmxvYWRNYXRlcmlhbChtYXRlcmlhbClcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7ZG93bmxvYWRpbmdJZCA9PT0gbWF0ZXJpYWwuaWRcclxuICAgICAgICAgICAgICAgICAgPyAnRG93bmxvYWRpbmcuLi4nXHJcbiAgICAgICAgICAgICAgICAgIDogJ0Rvd25sb2FkJ31cclxuICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9hcnRpY2xlPlxyXG4gICAgICAgICAgKSl9XHJcbiAgICAgICAgPC9kaXY+XHJcbiAgICAgICl9XHJcbiAgICA8L3NlY3Rpb24+XHJcbiAgKVxyXG59XHJcbiJdfQ==