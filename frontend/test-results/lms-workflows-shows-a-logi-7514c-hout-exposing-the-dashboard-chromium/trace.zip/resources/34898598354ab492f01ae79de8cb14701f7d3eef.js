import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AssignmentProgress.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import "/src/components/AssignmentProgress.css";
var _jsxFileName = "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentProgress.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fcfa67a2";
/**
* Derive a student's assignment status from the deadline and CURRENT
* submission record. The backend remains the authority for all actions.
* "Under review" means closed to submissions and awaiting final grading;
* it does NOT assert that a professor has started reviewing the work.
*/
export function getAssignmentProgress(dueAt, submission, now = Date.now()) {
	const deadline = Date.parse(dueAt);
	const isClosed = Number.isFinite(deadline) && now >= deadline;
	if (!submission) {
		return isClosed ? "missing" : "not-submitted";
	}
	// A valid score of zero is still a grade.
	if (submission.score !== null && submission.score !== undefined) {
		return "graded";
	}
	return isClosed ? "under-review" : "submitted";
}
const STATUS_DETAILS = {
	"not-submitted": {
		label: "Not submitted",
		explanation: "No submission has been received yet."
	},
	missing: {
		label: "Missing",
		explanation: "The deadline has passed and no submission was received."
	},
	submitted: {
		label: "Submitted",
		explanation: "A submission has been received. The deadline is still open."
	},
	"under-review": {
		label: "Awaiting grading",
		explanation: "The deadline has passed. Final grading is pending."
	},
	graded: {
		label: "Graded",
		explanation: "A final score has been recorded."
	}
};
export default function AssignmentProgressBadge({ status }) {
	const { label, explanation } = STATUS_DETAILS[status];
	return /* @__PURE__ */ _jsxDEV("span", {
		className: `assignment-progress assignment-progress--${status}`,
		title: explanation,
		"aria-label": `Assignment status: ${label}`,
		children: label
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 74,
		columnNumber: 5
	}, this);
}
_c = AssignmentProgressBadge;
var _c;
$RefreshReg$(_c, "AssignmentProgressBadge");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/AssignmentProgress.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentProgress.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentProgress.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/Mico/Desktop/bolzano/Agile/university-lms/frontend/src/components/AssignmentProgress.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTzs7Ozs7Ozs7O0FBb0JQLE9BQU8sU0FBUyxzQkFDZCxPQUNBLFlBQ0EsTUFBTSxLQUFLLElBQUksR0FDVztDQUMxQixNQUFNLFdBQVcsS0FBSyxNQUFNLEtBQUs7Q0FDakMsTUFBTSxXQUFXLE9BQU8sU0FBUyxRQUFRLEtBQUssT0FBTztDQUVyRCxJQUFJLENBQUMsWUFBWTtFQUNmLE9BQU8sV0FBVyxZQUFZO0NBQ2hDOztDQUdBLElBQUksV0FBVyxVQUFVLFFBQVEsV0FBVyxVQUFVLFdBQVc7RUFDL0QsT0FBTztDQUNUO0NBRUEsT0FBTyxXQUFXLGlCQUFpQjtBQUNyQztBQUVBLE1BQU0saUJBR0Y7Q0FDRixpQkFBaUI7RUFDZixPQUFPO0VBQ1AsYUFBYTtDQUNmO0NBQ0EsU0FBUztFQUNQLE9BQU87RUFDUCxhQUFhO0NBQ2Y7Q0FDQSxXQUFXO0VBQ1QsT0FBTztFQUNQLGFBQWE7Q0FDZjtDQUNBLGdCQUFnQjtFQUNkLE9BQU87RUFDUCxhQUFhO0NBQ2Y7Q0FDQSxRQUFRO0VBQ04sT0FBTztFQUNQLGFBQWE7Q0FDZjtBQUNGO0FBTUEsZUFBZSxTQUFTLHdCQUF3QixFQUFFLFVBQWlCO0NBQ2pFLE1BQU0sRUFBRSxPQUFPLGdCQUFnQixlQUFlO0NBQzlDLE9BQ0Usd0JBQUMsUUFBRDtFQUNFLFdBQVcsNENBQTRDO0VBQ3ZELE9BQU87RUFDUCxjQUFZLHNCQUFzQjtZQUVqQztDQUNHOzs7OztBQUVWIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFzc2lnbm1lbnRQcm9ncmVzcy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuL0Fzc2lnbm1lbnRQcm9ncmVzcy5jc3MnXG5cbmV4cG9ydCB0eXBlIEFzc2lnbm1lbnRQcm9ncmVzc1N0YXR1cyA9XG4gIHwgJ25vdC1zdWJtaXR0ZWQnXG4gIHwgJ21pc3NpbmcnXG4gIHwgJ3N1Ym1pdHRlZCdcbiAgfCAndW5kZXItcmV2aWV3J1xuICB8ICdncmFkZWQnXG5cbmV4cG9ydCB0eXBlIEdyYWRlU25hcHNob3QgPSB7XG4gIHNjb3JlPzogbnVtYmVyIHwgc3RyaW5nIHwgbnVsbFxuICBncmFkZWRfYXQ/OiBzdHJpbmcgfCBudWxsXG59XG5cbi8qKlxuICogRGVyaXZlIGEgc3R1ZGVudCdzIGFzc2lnbm1lbnQgc3RhdHVzIGZyb20gdGhlIGRlYWRsaW5lIGFuZCBDVVJSRU5UXG4gKiBzdWJtaXNzaW9uIHJlY29yZC4gVGhlIGJhY2tlbmQgcmVtYWlucyB0aGUgYXV0aG9yaXR5IGZvciBhbGwgYWN0aW9ucy5cbiAqIFwiVW5kZXIgcmV2aWV3XCIgbWVhbnMgY2xvc2VkIHRvIHN1Ym1pc3Npb25zIGFuZCBhd2FpdGluZyBmaW5hbCBncmFkaW5nO1xuICogaXQgZG9lcyBOT1QgYXNzZXJ0IHRoYXQgYSBwcm9mZXNzb3IgaGFzIHN0YXJ0ZWQgcmV2aWV3aW5nIHRoZSB3b3JrLlxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0QXNzaWdubWVudFByb2dyZXNzKFxuICBkdWVBdDogc3RyaW5nLFxuICBzdWJtaXNzaW9uOiBHcmFkZVNuYXBzaG90IHwgbnVsbCB8IHVuZGVmaW5lZCxcbiAgbm93ID0gRGF0ZS5ub3coKSxcbik6IEFzc2lnbm1lbnRQcm9ncmVzc1N0YXR1cyB7XG4gIGNvbnN0IGRlYWRsaW5lID0gRGF0ZS5wYXJzZShkdWVBdClcbiAgY29uc3QgaXNDbG9zZWQgPSBOdW1iZXIuaXNGaW5pdGUoZGVhZGxpbmUpICYmIG5vdyA+PSBkZWFkbGluZVxuXG4gIGlmICghc3VibWlzc2lvbikge1xuICAgIHJldHVybiBpc0Nsb3NlZCA/ICdtaXNzaW5nJyA6ICdub3Qtc3VibWl0dGVkJ1xuICB9XG5cbiAgLy8gQSB2YWxpZCBzY29yZSBvZiB6ZXJvIGlzIHN0aWxsIGEgZ3JhZGUuXG4gIGlmIChzdWJtaXNzaW9uLnNjb3JlICE9PSBudWxsICYmIHN1Ym1pc3Npb24uc2NvcmUgIT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiAnZ3JhZGVkJ1xuICB9XG5cbiAgcmV0dXJuIGlzQ2xvc2VkID8gJ3VuZGVyLXJldmlldycgOiAnc3VibWl0dGVkJ1xufVxuXG5jb25zdCBTVEFUVVNfREVUQUlMUzogUmVjb3JkPFxuICBBc3NpZ25tZW50UHJvZ3Jlc3NTdGF0dXMsXG4gIHsgbGFiZWw6IHN0cmluZzsgZXhwbGFuYXRpb246IHN0cmluZyB9XG4+ID0ge1xuICAnbm90LXN1Ym1pdHRlZCc6IHtcbiAgICBsYWJlbDogJ05vdCBzdWJtaXR0ZWQnLFxuICAgIGV4cGxhbmF0aW9uOiAnTm8gc3VibWlzc2lvbiBoYXMgYmVlbiByZWNlaXZlZCB5ZXQuJyxcbiAgfSxcbiAgbWlzc2luZzoge1xuICAgIGxhYmVsOiAnTWlzc2luZycsXG4gICAgZXhwbGFuYXRpb246ICdUaGUgZGVhZGxpbmUgaGFzIHBhc3NlZCBhbmQgbm8gc3VibWlzc2lvbiB3YXMgcmVjZWl2ZWQuJyxcbiAgfSxcbiAgc3VibWl0dGVkOiB7XG4gICAgbGFiZWw6ICdTdWJtaXR0ZWQnLFxuICAgIGV4cGxhbmF0aW9uOiAnQSBzdWJtaXNzaW9uIGhhcyBiZWVuIHJlY2VpdmVkLiBUaGUgZGVhZGxpbmUgaXMgc3RpbGwgb3Blbi4nLFxuICB9LFxuICAndW5kZXItcmV2aWV3Jzoge1xuICAgIGxhYmVsOiAnQXdhaXRpbmcgZ3JhZGluZycsXG4gICAgZXhwbGFuYXRpb246ICdUaGUgZGVhZGxpbmUgaGFzIHBhc3NlZC4gRmluYWwgZ3JhZGluZyBpcyBwZW5kaW5nLicsXG4gIH0sXG4gIGdyYWRlZDoge1xuICAgIGxhYmVsOiAnR3JhZGVkJyxcbiAgICBleHBsYW5hdGlvbjogJ0EgZmluYWwgc2NvcmUgaGFzIGJlZW4gcmVjb3JkZWQuJyxcbiAgfSxcbn1cblxudHlwZSBQcm9wcyA9IHtcbiAgc3RhdHVzOiBBc3NpZ25tZW50UHJvZ3Jlc3NTdGF0dXNcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXNzaWdubWVudFByb2dyZXNzQmFkZ2UoeyBzdGF0dXMgfTogUHJvcHMpIHtcbiAgY29uc3QgeyBsYWJlbCwgZXhwbGFuYXRpb24gfSA9IFNUQVRVU19ERVRBSUxTW3N0YXR1c11cbiAgcmV0dXJuIChcbiAgICA8c3BhblxuICAgICAgY2xhc3NOYW1lPXtgYXNzaWdubWVudC1wcm9ncmVzcyBhc3NpZ25tZW50LXByb2dyZXNzLS0ke3N0YXR1c31gfVxuICAgICAgdGl0bGU9e2V4cGxhbmF0aW9ufVxuICAgICAgYXJpYS1sYWJlbD17YEFzc2lnbm1lbnQgc3RhdHVzOiAke2xhYmVsfWB9XG4gICAgPlxuICAgICAge2xhYmVsfVxuICAgIDwvc3Bhbj5cbiAgKVxufVxuIl19